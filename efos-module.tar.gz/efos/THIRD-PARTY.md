# Third-party code, fonts and ideas

## Code and fonts used

| What | Where in EFOS Terminal | Author | License |
|---|---|---|---|
| Mutable Instruments Clouds (all four playback modes, diffuser, reverb, pitch shifter, phase vocoder) and stmlib (FFT, atan table) | `core/efs_clouds.h`, `core/efs_clouds_modes.h` (GRAIN, NEBULA; the notice is kept in the file) | Émilie Gillet | MIT |
| Mutable Instruments Plaits: AnalogSnareDrum (808) and SyntheticSnareDrum (909), with stmlib's Svf, OnePole and SoftClip | `core/efs_snare.h` (the SNARE engine; changes listed and the notice kept in the file) | Émilie Gillet | MIT |
| Mutable Instruments Plaits: SyntheticBassDrum (the THUMP 909) | `core/thump/sbd.c` (changes listed and the notice kept in the file) | Émilie Gillet | MIT |
| Omega kick models (FM2, FM4, WTR, PHY, HRD, DIG, TRS, ANA) and their DSP primitives and tables | `core/thump/` (the THUMP engine; changes listed in `core/thump/LICENSE`) | James Fish | MIT (stated in the Omega README) |
| NoSleep.js (the idea: a hidden looping video keeps the phone awake; no code copied) | `move/web/mirror.html` | Rich Tibbett | MIT |
| QR Code generator library (byte mode, ECC, masks) | `move/src/mirror.js` (MIRROR SCREEN; versions 1-6, ECC L only) | Project Nayuki | MIT |
| gin WTOscillator warps (bend, formant, asym, fold; hard-sync range) via TinyHouse `ported/wt_oscillator.h`; TinyHouse multiband compressor (OTT) | `core/efs_wt.h` (WARP page), `core/efs_fx.h` (GRID FX OTT) | Roland Rabien (gin); Mathew Taylor (TinyHouse) | BSD-3-Clause |
| Airwindows Channel9 | `core/efs_strip.h` (SAT on the CHANNEL page; the notice is kept in the file) | Chris Johnson (Airwindows) | MIT |
| jsSID 0.9.1 (Hermit) | `core/efs_sid.h` (the SID engine: oscillator, waveforms, combined waveforms, noise, ADSR, 6581/8580 filter) | Mihaly Horvath "Hermit", https://github.com/og2t/jsSID | WTF license ("do what you want with this code") |
| minimp3 | `move/dsp/minimp3.h` (MP3 decoding for RADIO on the Move, unchanged) | lieff | CC0 (public domain) |
| Open303 | `core/efs_acid.h` (the ACID engine follows it; the notice is kept in the file) | Robin Schmidt | MIT |
| font4x5 from Schwung | `fonts/font4x5.json`: every letter on the screen and the device | Charles Vestal (Schwung), via Movy by megadake | MIT, see `fonts/LICENSE-font4x5.txt` |
| Elektron Pixel Font, modified as EFS Pixel | `fonts/EFSPixel-Regular.*`: manual headings | savingaurora | CC BY-SA 3.0, see `fonts/LICENSE-EFS-Pixel.txt` |

## Services

| What | Used for |
|---|---|
| Radio Browser (radio-browser.info), a free, open directory of internet radio stations | RADIO: picks a random MP3 station |

## Ideas we built on (own code)

| Idea | Used for | Author |
|---|---|---|
| Cytomic state-variable filter | filters | Andrew Simper |
| Plate reverb | REVERB send | Jon Dattorro |
| Digital dynamic range compressor design | master compressor | Giannoulis, Massberg and Reiss |
| Devil Fish | ACID decay | Robin Whittle |
| OTT | SMASH compression | Steve Duda |

Thank you ♡
