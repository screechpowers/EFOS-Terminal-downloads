import * as _std from 'std';
import * as _os from 'os';
/* EFOS Terminal on Ableton Move: the web app's own code runs here unchanged where it can.
 * This prelude gives it what a browser would: a small stand-in for the page (elements that only remember
 * their classes, styles and listeners), timers, storage in files, and a 128 x 64 screen buffer.
 * The Move layer at the end (postlude) reads those elements to set the LEDs and turns the Move's pads,
 * knobs and buttons into the same events the web app's controls get. */
const EFOS_DIR = '/data/UserData/schwung/efos';
const performance = { now: () => Date.now() };

/* ---------- timers, run from tick() ---------- */
let _tid = 1;
const _timers = new Map();
function setTimeout(fn, ms) { const id = _tid++; _timers.set(id, { at: Date.now() + (+ms || 0), fn, every: 0 }); return id; }
function setInterval(fn, ms) { const id = _tid++; _timers.set(id, { at: Date.now() + (+ms || 0), fn, every: Math.max(1, +ms || 1) }); return id; }
function clearTimeout(id) { _timers.delete(id); }
const clearInterval = clearTimeout;
let _raf = [];
function requestAnimationFrame(fn) { _raf.push(fn); return _raf.length; }
function _runTimers() {
  const now = Date.now();
  for (const [id, t] of _timers) {
    if (t.at > now) continue;
    if (t.every) t.at = now + t.every; else _timers.delete(id);
    try { t.fn(); } catch (e) { console.log('EFOS timer: ' + e + '\n' + (e && e.stack)); }
  }
  if (_raf.length) { const l = _raf; _raf = []; for (const f of l) try { f(now); } catch (e) { console.log('EFOS frame: ' + e + '\n' + (e && e.stack)); } }
}

/* ---------- storage: one file per key in EFOS_DIR ---------- */
function _store(lazy) {
  const mem = {}, dirty = new Set();
  const file = k => EFOS_DIR + '/' + k.replace(/[^a-zA-Z0-9._-]/g, '_') + '.json';
  const write = k => { try { host_ensure_dir(EFOS_DIR); host_write_file(file(k), mem[k]); } catch (e) { console.log('EFOS save: ' + e); } };
  return {
    getItem(k) { if (!(k in mem)) { let s = null; try { s = host_file_exists(file(k)) ? host_read_file(file(k)) : null; } catch (e) {} mem[k] = s; } return mem[k]; },
    setItem(k, v) { v = String(v); if (mem[k] === v) return; mem[k] = v; if (lazy) dirty.add(k); else write(k); },
    removeItem(k) { mem[k] = null; try { host_write_file(file(k), ''); } catch (e) {} },
    flush() { for (const k of dirty) write(k); dirty.clear(); },
  };
}
const localStorage = _store(false);
const sessionStorage = _store(true);       /* the autosave: written every few seconds, not every change */

/* ---------- 128 x 64 1-bit screen buffer with the 2D-context calls the web app uses ---------- */
const _fb = new Uint8Array(128 * 64);
let _fbDirty = true;
const _ctx = {
  fillStyle: '#fff', globalCompositeOperation: 'source-over',
  fillRect(x, y, w, h) {
    x = Math.round(x); y = Math.round(y); w = Math.round(w); h = Math.round(h);
    if (w < 0) { x += w; w = -w; } if (h < 0) { y += h; h = -h; }
    const x0 = Math.max(0, x), y0 = Math.max(0, y), x1 = Math.min(128, x + w), y1 = Math.min(64, y + h);
    if (x1 <= x0 || y1 <= y0) return;
    const s = String(this.fillStyle).toLowerCase(), on = !(s === '#000' || s === '#000000' || s === 'black' || s === 'rgb(0,0,0)');
    const xor = this.globalCompositeOperation === 'xor';
    for (let r = y0; r < y1; r++) { const o = r * 128; for (let c = x0; c < x1; c++) _fb[o + c] = xor ? (on ? _fb[o + c] ^ 1 : _fb[o + c]) : (on ? 1 : 0); }
    _fbDirty = true;
  },
  clearRect(x, y, w, h) { const f = this.fillStyle, g = this.globalCompositeOperation; this.fillStyle = '#000'; this.globalCompositeOperation = 'source-over'; this.fillRect(x, y, w, h); this.fillStyle = f; this.globalCompositeOperation = g; },
  save() {}, restore() {}, beginPath() {}, fill() {}, stroke() {}, drawImage() {}, setTransform() {}, scale() {}, translate() {},
};
function _flushScreen() {
  if (!_fbDirty) return; _fbDirty = false;
  clear_screen();
  for (let r = 0; r < 64; r++) {
    const o = r * 128; let c = 0;
    while (c < 128) { if (!_fb[o + c]) { c++; continue; } let e = c; while (e < 128 && _fb[o + e]) e++; fill_rect(c, r, e - c, 1, 1); c = e; }
  }
}

/* ---------- a page that only remembers ---------- */
const _evt = (o) => Object.assign({ preventDefault() {}, stopPropagation() {}, pointerId: 1, pointerType: 'touch', clientX: 0, clientY: 0, buttons: 1, repeat: false, key: '', code: '', shiftKey: false,
  target: { tagName: 'DIV', closest: () => null } }, o || {});
class _El {
  constructor(tag) {
    this.tagName = String(tag || 'div').toUpperCase(); this.children = []; this.ls = {}; this.cls = new Set(); this.attrs = {}; this.dataset = {};
    this.className = ''; this.textContent = ''; this.value = ''; this.files = []; this.tabIndex = -1;
    this.offsetWidth = 0; this.offsetHeight = 0; this.offsetLeft = 0; this.offsetTop = 0; this.clientWidth = 1079; this.clientHeight = 600;
    const st = {}; st.setProperty = (k, v) => { st[k] = v; }; st.removeProperty = k => { delete st[k]; }; st.getPropertyValue = k => st[k] || ''; this.style = st;
    const self = this;
    this.classList = {
      add: (...a) => a.forEach(c => self.cls.add(c)), remove: (...a) => a.forEach(c => self.cls.delete(c)),
      toggle: (c, f) => { const on = f === undefined ? !self.cls.has(c) : !!f; if (on) self.cls.add(c); else self.cls.delete(c); return on; },
      contains: c => self.cls.has(c),
    };
  }
  appendChild(c) { this.children.push(c); return c; }
  append(...c) { c.forEach(x => this.children.push(x)); }
  prepend(c) { this.children.unshift(c); }
  remove() {}
  removeChild(c) { const i = this.children.indexOf(c); if (i >= 0) this.children.splice(i, 1); return c; }
  setAttribute(k, v) { this.attrs[k] = String(v); }
  getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
  removeAttribute(k) { delete this.attrs[k]; }
  addEventListener(t, f) { (this.ls[t] = this.ls[t] || []).push(f); }
  removeEventListener(t, f) { const l = this.ls[t]; if (l) { const i = l.indexOf(f); if (i >= 0) l.splice(i, 1); } }
  fire(t, o) { const e = _evt(o); (this.ls[t] || []).slice().forEach(f => f.call(this, e)); if (t === 'click' && this.onclick) this.onclick(e); }
  click() { this.fire('click'); }
  querySelector(q) { return this.children.find(c => c instanceof _El) || null; }
  querySelectorAll() { return []; }
  closest() { return null; }
  contains() { return false; }
  focus() {} blur() {}
  setPointerCapture() {} releasePointerCapture() {}
  getBoundingClientRect() { return { left: 0, top: 0, right: 1, bottom: 1, width: 1, height: 1 }; }
  getContext() { return _ctx; }
  toDataURL() { return ''; }
}
const _ids = {};
const document = {
  body: new _El('body'), documentElement: new _El('html'),
  createElement: t => new _El(t),
  getElementById: id => _ids[id] || (_ids[id] = new _El('div')),
  querySelector: () => null, querySelectorAll: () => [],
  addEventListener() {}, removeEventListener() {},
  hidden: false, visibilityState: 'visible',
};
const window = { addEventListener() {}, removeEventListener() {}, innerWidth: 1079, innerHeight: 600, devicePixelRatio: 1 };
const navigator = {};
class ResizeObserver { constructor() {} observe() {} disconnect() {} }
const URL = { createObjectURL: () => '', revokeObjectURL() {} };
class Blob { constructor() {} }
const PALL = a => a;    /* Promise.all on values that are already there (this runtime runs no promise jobs) */
let _syncDirty = true;   /* set by sync(), see the Move layer */
const EFOS_VERSION = "0.118.172";

"use strict";
/* ---------- font4x5 (Schwung, MIT): one renderer for screen and device ---------- */
const G={" ":[3,0,0,5],"!":[2,0,1,5,1,1,1,0,1],"\"":[4,0,3,5,5,5,0,0,0],"'":[2,0,1,5,1,1,0,0,0],"(":[3,0,2,5,2,1,1,1,2],")":[3,0,2,5,1,2,2,2,1],"+":[4,0,3,5,0,2,7,2,0],",":[3,0,2,5,0,0,0,2,1],"-":[4,0,3,5,0,0,7,0,0],".":[2,0,1,5,0,0,0,0,1],"/":[5,0,4,5,8,8,6,1,1],":":[2,0,1,5,0,1,0,1,0],"0":[5,0,4,5,6,9,9,9,6],"1":[5,0,4,5,2,3,2,2,7],"2":[5,0,4,5,7,8,6,1,15],"3":[5,0,4,5,7,8,6,8,7],"4":[5,0,4,5,9,9,15,8,8],"5":[5,0,4,5,15,1,7,8,7],"6":[5,0,4,5,14,1,7,9,6],"7":[5,0,4,5,15,8,4,2,1],"8":[5,0,4,5,6,9,6,9,6],"9":[5,0,4,5,6,9,14,8,7],"A":[5,0,4,5,6,9,15,9,9],"B":[5,0,4,5,7,9,7,9,7],"C":[5,0,4,5,14,1,1,1,14],"D":[5,0,4,5,7,9,9,9,7],"E":[5,0,4,5,15,1,7,1,15],"F":[5,0,4,5,15,1,7,1,1],"G":[5,0,4,5,14,1,13,9,14],"H":[5,0,4,5,9,9,15,9,9],"I":[2,0,1,5,1,1,1,1,1],"J":[5,0,4,5,12,8,8,9,6],"K":[5,0,4,5,9,5,3,5,9],"L":[5,0,4,5,1,1,1,1,15],"M":[6,0,5,5,17,27,21,17,17],"N":[5,0,4,5,9,11,13,9,9],"O":[5,0,4,5,6,9,9,9,6],"P":[5,0,4,5,7,9,7,1,1],"Q":[5,0,4,5,6,9,9,5,10],"R":[5,0,4,5,7,9,7,5,9],"S":[5,0,4,5,14,1,6,8,7],"T":[4,0,3,5,7,2,2,2,2],"U":[5,0,4,5,9,9,9,9,6],"V":[6,0,5,5,17,17,17,10,4],"W":[6,0,5,5,17,17,21,21,10],"X":[5,0,4,5,9,9,6,9,9],"Y":[4,0,3,5,5,5,2,2,2],"Z":[5,0,4,5,15,8,6,1,15],"%":[5,0,4,5,9,8,6,1,9],"<":[4,0,3,5,4,2,1,2,4],">":[4,0,3,5,1,2,4,2,1],"=":[4,0,3,5,0,7,0,7,0],"?":[5,0,4,5,7,8,6,0,2],"*":[4,0,3,5,5,2,5,0,0],"#":[5,0,4,5,10,15,10,15,10],"&":[5,0,4,5,6,9,6,5,10],"_":[5,0,4,5,0,0,0,0,15],"\\":[5,0,4,5,1,1,6,8,8],"^":[4,0,3,5,2,5,0,0,0],";":[3,0,2,5,0,2,0,2,1],"$":[5,0,4,5,14,5,6,10,7],"@":[5,0,4,5,6,9,13,1,14],"[":[3,0,2,5,3,1,1,1,3],"]":[3,0,2,5,3,2,2,2,3],"{":[4,0,3,5,6,2,1,2,6],"}":[4,0,3,5,3,2,4,2,3],"|":[2,0,1,5,1,1,1,1,1],"~":[5,0,4,5,0,6,9,0,0],"`":[3,0,2,5,1,2,0,0,0]};
const glyph=c=>G[c]||G[c.toUpperCase()]||G[' '];
function tw(s,k=1){let w=0;for(const c of s)w+=glyph(c)[0];return Math.max(0,w-1)*k;}
function glyphs(ctx,s,X,Y,k=1){for(const c of s){const g=glyph(c);
  for(let r=0;r<g[3];r++){const row=g[4+r];for(let b=0;b<g[2];b++)if(row>>b&1)ctx.fillRect(X+b*k,Y+(g[1]+r)*k,k,k);}X+=g[0]*k;}}
const pxCache=new Map();
function pxURL(s,k){const key=k+'|'+s;if(!pxCache.has(key)){const c=document.createElement('canvas');c.width=Math.max(1,tw(s,k));c.height=5*k;
  const g=c.getContext('2d');g.fillStyle='#fff';glyphs(g,s,0,0,k);pxCache.set(key,c.toDataURL());}return pxCache.get(key);}
/* set the text of a device label: a span whose mask is the pixel text at scale k */
function pix(e,s,k){return e;let p=e.querySelector(':scope>.px');if(!p){p=document.createElement('span');p.className='px';e.appendChild(p);}
  if(p.dataset.t===s+k)return p;p.dataset.t=s+k;const u=`url(${pxURL(s,k)})`;
  p.style.width=tw(s,k)+'px';p.style.height=5*k+'px';p.style.webkitMaskImage=u;p.style.maskImage=u;p.style.visibility=s.trim()?'':'hidden';return p;}
/* ---------- layout: Move photo coordinates -> stage px ---------- */
const S=0.7,OX=228,OY=382;
const P=(x,y)=>[Math.round((x-OX)*S),Math.round((y-OY)*S)];
const stage=document.getElementById('stage'),box=document.getElementById('box');
function fit(){stage.style.transform=`scale(${box.clientWidth/1079})`;}
new ResizeObserver(fit).observe(box);fit();
function el(tag,cls,x,y,w,h,parent=stage){const e=document.createElement(tag);e.className=cls;
  e.style.left=x+'px';e.style.top=y+'px';if(w!=null){e.style.width=w+'px';e.style.height=h+'px';}parent.appendChild(e);return e;}
function roundBtn(cx,cy,d,cls,label){const[x,y]=P(cx,cy),r=Math.round(d*S);
  const b=el('button','rb '+cls,x-(r>>1),y-(r>>1),r,r);if(label!=null)pix(b,label,label.length===1?3:2);
  b.setAttribute('aria-label',label||cls);return b;}

/* ---------- model ---------- */
const MAXS=128;   /* steps per track and per pitch lane (Lef 25 nov) */
let core=null; /* main-thread copy of the C core, used for the generators */
const TC=i=>`var(--track-${i+1})`;
/* sound engines, chosen per track with MENU + jog; all share the same 8 macros */
const TEX_M=['FM','RING','SYNC','SWARM'];
const ENGINES=['FM-PERC','TEX','TEX','TEX','TEX','ACID','DUST','J60','MATTER','HANDS','SHARK','HIVE','NEBULA','THUMP','SOPHIE','SNARE','SAMPLE','WAVETABLE','WT DRUM','TANK','SID'];
/* the order on screen: kicks, percussion, synths, noise and experimental (the numbers above stay: saved states keep their engine) */
/* the ENGINE menu in groups (Lef 17 nov): a heading row per group, the jog skips the headings */
const ENG_GRP=[['DRUMS',[13,15,0,14,9,18]],['BASS',[5,10,20]],['SYNTH',[7,11,17]],['TEXTURE',[1,6,8]],['FX',[19,12]],['SAMPLE',[16]]];   /* SAMPLE last (Lef 22 nov) */   /* FX: TANK (Lef 20 nov) */
const texE=e=>e>=1&&e<=4?1:e;   /* TEX (Lef 25 nov): one engine in the list; FM RING SYNC SWARM are its MODE (core engines 1-4) */
const ENG_ORD=ENG_GRP.flatMap(g=>g[1]),engPos=e=>ENG_ORD.indexOf(texE(e)),engGrp=e=>ENG_GRP.find(g=>g[1].includes(texE(e)))[0];
const ENG_ROWS=ENG_GRP.flatMap(g=>[{h:g[0]},...g[1].map(e=>({e}))]),engRow=e=>ENG_ROWS.findIndex(r=>r.e===texE(e));
const DUST=6;
const HANDS=9; /* claps: TONE, tail, HANDS = how many (1 snap .. 4 flam .. 40 applause), SPREAD, DRIVE, ROOM; Shift + FILTER = COLOR */
const MATTER=8; /* BLACK MATTER: whisper, crackle, drift, rumble, comb scrape, dropouts, broken grains; Shift + TIMBRE / SWEEP / DRIVE = RUMBLE / DROP / BREAK (t.v.cv, cc, chp) */
const X3=t=>t.eng===MATTER; /* engines with three Shift extras on TIMBRE / SWEEP / DRIVE */
const CHORD=7;  /* Juno-style triads in the scale */
const SHARK=10; /* Moog-style bass: ladder filter, saw > sharktooth > square > pulse, sub, drive */
const HIVE=11;  /* a swarm of 8 VCOs after the Quadrantid Swarm: SPREAD, CHAR, ALGO (8 models), PERC, two filters; SPRING in slot 1 */
const HIVE_ALGO=['ORGAN','STRING','DRONE','REED','METAL','CHIP','GRAIN','NOISE'];
const NEBULA=12;  /* Clouds on another track's sound (or a PING): the hits gate it, the envelope is its VCA; ALGO = the four Clouds modes */
const NEB_ALGO=['GRAIN','STRET.','LOOP.D','SPEC.'];
/* SOURCE: the other seven tracks, then PING; the core takes 0..7 = a track, 8 = PING */
const nebSrcs=t=>{const me=tracks.indexOf(t),a=[];for(let i=0;i<8;i++)if(i!==me)a.push(i);a.push(8);return a;};
const nebSrc=t=>nebSrcs(t)[fromV(t.v.macros[6],8)];   /* the core reads SOURCE the same way, modulated */
const THUMP=13;  /* kicks: the eight kick models of Omega (MIT) and 909 = Plaits' synthetic bass drum (MIT), with their own envelopes; ALGO picks the model */
const TH_ALGO=['PURE','STACK','WAVE','SKIN','SLAM','BITS','TRANS','808','909']   /* Lef 25 nov: names swapped to match the sound (Plaits' synthetic bass drum = 808, Omega's ANA = 909) */
,TH_NA=TH_ALGO.length;
/* per algorithm: knob 5, knob 6, Shift + 5, Shift + 6 as [label, long name, choices or null], and their start values (Omega's defaults) */
const TH_K=[[['RATIO','FM RATIO'],['INDEX','FM INDEX'],['WAVE','MODULATOR WAVE',['SINE','FOLD','TRI']],['----','']],
  [['RATIO','OPERATOR RATIOS'],['INDEX','FM INDEX'],['FDBK','OPERATOR FEEDBACK'],['ROUTE','FM ROUTING',['CHAIN','STACKS','BRIGHT','HOLLOW']]],
  [['WAVE','BODY WAVETABLE'],['BODY.P','BODY PITCH'],['T.DEC','TRANSIENT DECAY'],['T.COL','TRANSIENT COLOR']],
  [['TENSN','HEAD TENSION'],['TONE','TONE: DULL < > BRIGHT'],['BEATER','BEATER HARDNESS'],['SHELL','SHELL SIZE']],
  [['LAYER','PUNCH LAYER'],['GRIT','BODY DRIVE'],['CRUSH','BITCRUSH'],['L.WAVE','LAYER WAVE',['SAW','SQUARE','DIGI']]],
  [['LAYER','THUMP LAYER'],['BITS','BIT DEPTH'],['P.ENV','PITCH ENVELOPE'],['WAVE','BODY WAVE',['SAW','SQUARE','DIGI']]],
  [['SNAP','CLICK < > SNAP'],['T.DEC','TRANSIENT DECAY'],['BODY','BODY WAVE MORPH'],['BEND','SWEEP CURVE']],
  [['TONE','TONE: DARK < > BRIGHT'],['DIRT','DIRT: CLEAN < > GRITTY SINE'],['DEC.P','PITCH SWEEP DECAY'],['----','']],
  [['MORPH','WARM SINE < > ANALOG'],['SUB','SUB LEVEL'],['SUB.D','SUB DECAY'],['LAYER','THUMP LAYER']]];
const TH_DEF=[[13,6,0,0],[6,6,13,0],[76,32,64,64],[64,112,64,64],[64,90,50,64],[64,127,64,127],[64,64,64,64],[64,43,0,0],[64,89,76,64]];   /* SLAM hard, BITS 6-bit DIGI (Lef 18 nov); 909 = Plaits' defaults */
const TH_LONG={SWEEP:'PITCH SWEEP: 808 < > 909',CLICK:'CLICK: TRANSIENT LEVEL','C.DEC':'CLICK DECAY','C.TONE':'CLICK TONE',SUSTN:'SUSTAIN: BODY TAIL',
  DRIVE:'DRIVE',ALGO:'KICK ALGORITHM',DECAY:'DECAY: KICK LENGTH',PITCH:'PITCH 30 .. 200 HZ'};
const thAlgo=t=>fromV(t.v.cv[0],TH_NA);
/* SOPHIE: metallic FM percussion (mestela/schwung-sophie, MIT): ALGO = six models; FDBK (SHIFT MODE), DEC.M, CRUSH, TYPE.F of its own filter */
const SOPHIE=14,SO_ALGO=['FUSE','STACK','SPLIT','SHARD','PIPE','BOOM'],SO_TYPEF=['LP','HP','NOTCH','DJ','BP'];
/* SNARE: a snare in three layers, BODY (the head), RING (the shell), NOISE (the wires); 808 and 909 parts after Mutable Instruments Plaits (MIT).
   ALGO (Lef 19 nov): 808 and 909 = Plaits' own body, XXX = FM body with X.MOD (the wires bend it too), 000 = the free mix (TYPE.B);
   ENGINE 2 = BODY and RING, WIRES (an extra ENGINE page, SNARE only) = the snare wires: 808 909 WHITE PINK CLAP BLACK */
const SNARE=15,SN_ALGO=['808','909','XXX','000'],SN_TB=['808','909','FM','SUB'],SN_TN=['808','909','WHITE','PINK','CLAP','BLACK'],snA=t=>fromV(t.v.cv[0],4);   /* SNARE ALGO and WIRES types (Lef 19 nov) */
const SN_PRE=[ /* TYPE.B TYPE.W DEC.B TUNE.R DEC.R MIX.R COLOR RESO.W DEC.W SNAP X.MOD ENV.P DRIVE MIX.W BAL/INDEX */
  [0,0,64,64,64,64,64,64,70,0,0,0,0,105,64],     /* 808: Plaits' 808 body; more white noise, a shorter noise tail (Lef 26 nov) */
  [1,1,64,64,64,0,64,64,64,92,0,64,0,64,64],     /* 909: Plaits' 909 */
  [2,4,55,80,45,40,70,64,50,60,50,40,20,72,70],  /* XXX: FM body, cross-modulated, CLAP wires */
  [0,3,50,70,50,90,80,60,55,30,20,20,10,80,64]]; /* 000: 808 body, full shell, PINK wires */
/* SAMPLE (Lef 18 nov): records the Move's input (MIC) into one buffer per track, each REC overwrites it; plays slices.
   Values in t.v.sm (0..127), in the core's order EFS_SM_ALGO .. EFS_SM_ING */
const SAMPLE=16,SM_ALGO=['MIC','RADIO','FILE'],SM_TIMES=[.5,1,2,4,8,16,32,64],SM_BITS=['16 BIT','12 BIT','8 BIT'],SM_RATES=['44 KHZ','22 KHZ','11 KHZ'],SM_DIVS=[1,2,4],SM_SYNC=['OFF','1 BAR','2 BARS','4 BARS'],SM_DIRS=['FWD','REV','PING','L.FWD','L.REV','L.PING'];   /* L. = LOOP (Lef 18 nov) */
const ACX0=()=>[58,64];   /* ACID: TIME.S (58 = 60 ms, the 303), AMT.A (64 = the 303) */
const SM0=()=>[0,0,127,127,0,toV(24,49),64,0,toV(3,8),0,0,0,0,64,0,64],smv=t=>t.v.sm||(t.v.sm=SM0());
const SM_L=[['PITCH','DECAY','FILTER','----','ENV.P','----','----','LEVEL'],['PITCH','ATTACK','----','----','----','----','----','PAN']];
/* WAVETABLE and WT DRUM (Lef 20 nov, core efs_wt.h): two layers A / B. Tables: 4 built in, then the WAV files of the Move's
   Wavetables folder (the Move layer fills wtFiles and loads a file into a core slot when it is picked; until then wtSlotFor gives 0) */
const WAVE=17,WDRUM=18,WT_BUILT=['SIN>SAW','PWM','SYNC','FORMNT'],WT_SLOTS=20;
let wtFiles=[];
const WT_BUF='BUFFER';   /* the newest recording (Sample button, REC, OVERDUB), the core cuts it into frames (slot 19) */
let wtSlotFor=n=>n===WT_BUF?WT_SLOTS-1:Math.max(0,WT_BUILT.indexOf(n));
const wtList=()=>WT_BUILT.concat([WT_BUF],wtFiles),wtE=t=>t.eng===WAVE||t.eng===WDRUM;
/* t.v.wt: TBL.A(name in wtn) POS.A TBL.B(name) POS.B TUNE.B FM/X.MOD RING MIX.B FB.A POS.M FB.B X.FB FINE.B SCAN TUNE.A -, as the core's EFS_WT_* */
const WT0=()=>[0,64,0,64,64,20,0,40,0,64,0,0,64,40,64,0],wtv=t=>t.v.wt||(t.v.wt=WT0()),wtn=t=>t.v.wtn||(t.v.wtn=['SIN>SAW','PWM']);
const WT_OSC=['WT.OTUNE','WT.OFINE','WT.TUNE','----','WT.VOIC','WT.DET','----','----'],
  WT_WARP=['WT.SYNA','WT.BNDA','WT.FRMA',['WT.FLDA','WT.ASYA'],'WT.SYNB','WT.BNDB','WT.FRMB',['WT.FLDB','WT.ASYB']];   /* top row layer A, bottom row B (Lef 22 nov) */
const WT_L=[['PITCH','DECAY','FILTER','----','----','DRIVE','----','LEVEL'],['PITCH','ATTACK','----','----','----','----','----','PAN']];
const WD_L=[['PITCH','DECAY','FILTER','----','ENV.P','----','----','LEVEL'],['PITCH','ATTACK','----','----','----','----','----','PAN']];
const wtPush=t=>{const v=wtv(t),n=wtn(t);return v.map((x,k)=>k===0?(wtSlotFor(n[0])+.5)/WT_SLOTS:k===2?(wtSlotFor(n[1])+.5)/WT_SLOTS:x/127);};
/* TANK (Lef 20 nov, core efs_tank.h): t.v.tk = EXCITE RESO.1 HARM RESO.2 PAR>SER MODE GRIT FDBK VOICES DETUNE FM AM CORR FB.HZ, as EFS_TK_* */
const SID=20,SID0=()=>[76,0,0,0,0,0,0,0,64,64],sidv=t=>{const a=t.v.sid||(t.v.sid=SID0());while(a.length<10)a.push(SID0()[a.length]);return a;},SID_N=[0,0,3,4,2,2,5,4,7,0],
  sidPush=t=>sidv(t).map((v,i)=>SID_N[i]?(fromV(v,SID_N[i])+.5)/SID_N[i]:v/127),
  SID_WAVE=['TRI','SAW','PULSE','NOISE','T+S','P+T','P+S','P+T+S'],SID_ATK=['2MS','8MS','16MS','24MS','38MS','56MS','68MS','80MS','100MS','250MS','500MS','800MS','1S','3S','5S','8S'],SID_DEC=['6MS','24MS','48MS','72MS','114MS','168MS','204MS','240MS','300MS','750MS','1.5S','2.4S','3S','9S','15S','24S'],
  J6_0=()=>[toV(2,3),0,0,0,64,0,0,0],j6v=t=>t.v.j6||(t.v.j6=J6_0()),J6_N=[3,0,4,0,0,0,0,0],   /* J60 DCO page (Lef 26 nov): WAVE NOISE HPF VIB VIB.R VIB.D DRIFT F.KEY */
  j6Push=t=>j6v(t).map((v,i)=>J6_N[i]?(fromV(v,J6_N[i])+.5)/J6_N[i]:v/127),
  j6K=(i,lab,long,opts)=>Object.assign({lab:t=>t.eng===CHORD?lab:'----',long,shAll:1},J6_N[i]?{n:()=>J6_N[i],idx:t=>fromV(j6v(t)[i],J6_N[i]),setIdx:(t,j)=>{j6v(t)[i]=toV(j,J6_N[i]);},show:t=>opts[fromV(j6v(t)[i],J6_N[i])]}:{get:t=>j6v(t)[i],set:(t,v)=>j6v(t)[i]=v,show:opts}),
  sidK=(i,lab,long,opts)=>Object.assign({lab:t=>t.eng===SID?lab:'----',long,shAll:1},SID_N[i]?{n:()=>SID_N[i],idx:t=>fromV(sidv(t)[i],SID_N[i]),setIdx:(t,j)=>{sidv(t)[i]=toV(j,SID_N[i]);},show:t=>opts[fromV(sidv(t)[i],SID_N[i])]}:{get:t=>sidv(t)[i],set:(t,v)=>sidv(t)[i]=v,show:opts});
const TANK=19,TK0=()=>[40,115,14,115,0,40,70,40,36,30,25,0,64,64,96],tkv=t=>{const a=t.v.tk||(t.v.tk=TK0());while(a.length<15)a.push(TK0()[a.length]);return a;},tkPush=t=>tkv(t).map(v=>v/127);
/* WARP, UNISON, OSC (Lef 22 nov; core efs_wt.h after gin WTOscillator, BSD-3): t.v.ww = SYNC.A BEND.A FORM.A FOLD.A ASYM.A, the same for B,
   VOICES (index 0..3), DETUNE, TUNE.O (0..127, 76 = 0 ST, stepless: may hold halves), FINE.O, as EFS_WT_SYNA .. EFS_WT_OFINE */
const WW0=()=>[0,64,0,0,0,0,64,0,0,0,0,40,76,64],wwv=t=>{const a=t.v.ww||(t.v.ww=WW0());while(a.length<14)a.push(WW0()[a.length]);return a;};
const WT_O0=76,wtOst=v=>v<=WT_O0?(v-WT_O0)/WT_O0*36:(v-WT_O0)/(127-WT_O0)*24;   /* TUNE.O: -36 .. +24 semitones (Lef: 3 octaves down, 2 up) */
const wwPush=t=>wwv(t).map((x,k)=>k===10?(x+.5)/4:k===12?(x<=WT_O0?.6*x/WT_O0:.6+.4*(x-WT_O0)/(127-WT_O0)):x/127);
/* LFO 3 (Lef 22 nov, MOD 2 knobs 1-4, per track): t.v.l3 = SPEED, AMOUNT, FREE HZ, HZ ON (0/1), WAVE, PHASE (0..7 x 45), OFFSET; core EFS_L3RT .. EFS_L3OF */
const L30=()=>[40,0,0,0,0,0,64],l3v=t=>{const a=t.v.l3||(t.v.l3=L30());while(a.length<7)a.push(L30()[a.length]);return a;};
const l3Push=t=>{const a=l3v(t);return[a[0]/127,a[1]/127,(a[4]+.5)/7,a[3]?Math.max(.001,a[2]/127):0,a[5]/8,lofN(a[6])];};
/* P-LOCK (Lef 22 nov): t.v.plk = PLOCK.G (0 OFF .. 127 = glide over the whole step), PLOCK.H (0 OFF, 127 ON); core EFS_LK_GLIDE, EFS_LK_HOLD */
const plkv=t=>t.v.plk||(t.v.plk=[0,0]),lmv=t=>t.v.lm||(t.v.lm=[0]);   /* LIST.M: 0 POST, 127 PRE */
const TK_DIV=['1','1.5','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16'];
const tkHz=f=>f<1000?Math.round(f)+'HZ':(f/1000).toFixed(1)+'K';
const tkHarm=v=>{const h=v/127;return h<.85?'/'+TK_DIV[Math.floor(h/.85*16.99)]:'X '+Math.round((h-.85)/.15*100)+'%';};   /* filter 2 = filter 1 / the ratio; X = filter 1 moves filter 2 */
const smRadio=t=>t.eng===SAMPLE&&fromV(smv(t)[0],3)===1,smFile=t=>t.eng===SAMPLE&&fromV(smv(t)[0],3)===2;   /* FILE: a WAV from the Move's sample folder (LOAD pad) */
const SM_SLC=['1/128','1/64','1/32','1/16','1/8','1/4','1/2','1 BAR','ALL'];
/* the part (LENGTH from START) and the slices, as the core plays them (efs_sample.h), in ms; null while the buffer is unknown */
function smPart(t){const w=ui.smw,v=smv(t);if(!w||w.t!==tracks.indexOf(t)||!w.ms)return null;const L=w.ms,s0=v[1]/127*L,p=v[2]/127;
  let len=p>=.996?L:Math.pow(2,p*Math.log2(Math.max(1,L)));len=Math.max(.4,Math.min(len,L-s0));
  const si=fromV(v[3],9);let n=1,sl=len;if(si<8){const q=(1<<si)/128*240000/bpm;if(q<len){n=Math.min(1024,Math.floor(len/q));sl=q;}}
  return{L,s0,len,n,sl};}
const smSlices=t=>{const P=smPart(t);return P?P.n:1;};
const msShow=ms=>ms>=1000?(ms/1000).toFixed(ms>=10000?0:1)+'S':ms>=10?Math.round(ms)+'MS':ms.toFixed(1)+'MS';
const semShow=(v,r)=>{const s=Math.round((v-64)/63*r);return(s>0?'+':'')+s+' ST';};
const tkK=(i,lab,long,show,x)=>Object.assign({lab:t=>t.eng===TANK?lab:'----',long,get:t=>tkv(t)[i],set:(t,v)=>tkv(t)[i]=v,show,shAll:1},x||{});
const wtK=(i,lab,long,show,x)=>Object.assign({lab:t=>wtE(t)?(typeof lab==='function'?lab(t):lab):'----',long,get:t=>wtv(t)[i],set:(t,v)=>wtv(t)[i]=v,show,shAll:1},x||{});
const wwK=(i,lab,long,show,x)=>Object.assign({lab:t=>wtE(t)?lab:'----',long,get:t=>wwv(t)[i],set:(t,v)=>wwv(t)[i]=v,show,shAll:1},x||{});
const wwOff=(t,v)=>v?pct(v):'OFF',wwBip=(t,v)=>{const c=Math.round((v-64)/63*100);return c?(c>0?'+':'')+c+'%':'OFF';};
const wtT=(L,lab,long)=>({lab:t=>wtE(t)?lab:'----',long,n:()=>wtList().length,idx:t=>Math.max(0,wtList().indexOf(wtn(t)[L])),setIdx:(t,k)=>{const l=wtList();wtn(t)[L]=l[Math.max(0,Math.min(l.length-1,k))];},show:t=>wtn(t)[L].slice(0,8),shAll:1});
const smK=(i,lab,long,show,x)=>Object.assign({lab:t=>t.eng===SAMPLE?lab:'----',long,get:t=>smv(t)[i],set:(t,v)=>smv(t)[i]=v,show,shAll:1},x||{});
const smD=(i,lab,long,L,x)=>Object.assign({lab:t=>t.eng===SAMPLE?lab:'----',long,n:t=>typeof L==='function'?L(t).length:L.length,idx:t=>fromV(smv(t)[i],typeof L==='function'?L(t).length:L.length),
  setIdx:(t,k)=>smv(t)[i]=toV(k,typeof L==='function'?L(t).length:L.length),show:t=>{const a=typeof L==='function'?L(t):L;return a[fromV(smv(t)[i],a.length)];},shAll:1},x||{});
const smTime=t=>{const d=SM_DIVS[fromV(smv(t)[10],3)];return SM_TIMES.map(x=>x>16*d?'MAX '+16*d+'S':x<1?'0.5S':x+'S');};
const SN_L=[['PITCH','DECAY','FILTER','X.MOD','ENV.P','DRIVE','MIX.W','LEVEL'],['TUNE','ATTACK','----','----','----','----','----','PAN']];
const SO_L=[['PITCH','DECAY','CUTOFF','RESO','ENV.P','DRIVE','METAL','LEVEL'],['TUNE','ATTACK','ALGO','FDBK','COLOR','MODE','CURVE','PAN']];
const thumpL=(t,sh)=>{const K=TH_K[thAlgo(t)].map(x=>x[0]);
  return sh?[hasTune(t)&&!pRange(t)?'TUNE':'PITCH','SUSTN','ALGO','C.DEC',K[2],K[3],'C.TONE','PAN']:['PITCH','DECAY','SWEEP','CLICK',K[0],K[1],'DRIVE','LEVEL'];};
/* knobs 5 and 6 (and their Shift) with the model's name for them */
const thLong=(t,l)=>{const k=TH_K[thAlgo(t)].find(x=>x[0]===l);return k?k[1]:TH_LONG[l];};
/* the synths (J60, SHARK) share one layout: CUTOFF / F.AMT, RESO / PWM or WAVE, F.ENV / F.ATK (the filter envelope), SUB / CURVE,
   CHORUS or DRIVE / VOICE or NOISE; the Shift values live in t.v.col, pw, fa, crv, cv */
const isSyn=t=>t.eng===CHORD||t.eng===SHARK||t.eng===SID||t.eng===HIVE||t.eng===NEBULA||t.eng===THUMP||t.eng===SOPHIE,SYN_X=['col','pw','fa','crv','cv'],NEB_X=['cv','pw','col','fa','crv'];
const SYN_L=[['PITCH','DECAY','CUTOFF','RESO','F.ENV','SUB','CHORUS','LEVEL'],['PITCH','ATTACK','F.AMT','PWM','F.ATK','CURVE','VOICE','PAN']];
/* SID (Lef 24 nov, core efs_sid.h): the macros = CUTOFF RESO F.DEC SUB.L WAVE; SHIFT: F.AMT PW F.ATK - CHORD; t.v.sid = SUSTN PWM SUB FILT.M CHIP HOLD ARP RATE OCT REL */
const SID_L=[['PITCH','DECAY','CUTOFF','RESO','F.DEC','SUB.L','WAVE','LEVEL'],['TUNE','ATTACK','F.AMT','PW','F.ATK','CURVE','CHORD','PAN']];
const SHARK_L=[['PITCH','DECAY','CUTOFF','RESO','F.ENV','SUB','DRIVE','LEVEL'],['TUNE','ATTACK','F.AMT','WAVE','F.ATK','CURVE','NOISE','PAN']];
const HIVE_L=[['PITCH','DECAY','CUTOFF','RESO','F.ENV','SPREAD','CHAR','LEVEL'],['TUNE','ATTACK','F.AMT','PERC','F.ATK','CURVE','ALGO','PAN']];
const NEB_L=[['PITCH','DECAY','POS','SIZE','DENS','FEEDBK','SOURCE','LEVEL'],['TUNE','ATTACK','ALGO','RESO','TEX','REVERB','CURVE','PAN']];
const CH_VOICE=['SINGLE','TRIAD','SPREAD','DEEP'],CH_CHOR=['OFF','I','II','I+II']; /* crackles, pops and chaos into resonators: TIMBRE = CHAOS, SWEEP = DENS, DRIVE = FDBK, Shift + FILTER = SPREAD */
const ACID=5; /* 303 voice: knob 3 = CUTOFF, Shift = F.AMT (env mod), TIMBRE = RESO, Shift = WAVE (t.v.pw), SWEEP = F.ENV, DRIVE = RAT */
const MACROS=['PITCH','DECAY','FILTER','TIMBRE','SWEEP','DRIVE','NOISE','LEVEL'];
const PATTERN=['VAR.R','VAR.P','VAR.S','RND.V','PROB','DENS','LENGTH','CLOCK'],PAT_ORD=[0,1,2,5,3,4,6,7]; /* knob order on screen; PAT_ORD = the value each knob drives */
const pdi=(p,i)=>p.ord&&typeof i==='number'?p.ord[i]:i;
/* ALL ENGINE: row 4 pad 2 = VAR.D as the value (ui.param 8, Lef 20 nov); it lives in t.v.vd[0], not in the macros */
const ALL_VD=8,allVD=p=>p.key==='macros'&&ui.param===ALL_VD,allPar=()=>Math.min(ui.param,7),allLab=p=>allVD(p)?'VAR.D':p.labels[allPar()],allArr=(t,p)=>allVD(p)?[t.v.vd,0]:[t.v[p.key],pdi(p,allPar())];
/* the PERF values in core order; COMP pushes the master compressor, PROB (Shift + DENS) is the master chance */
const PERF=['CHAOS','DENS','FILTER','SWING','DELAY','COMP','WASH','PROB'];
/* SWING: every second 16th later, 50 % (straight, OFF) .. 75 % */
const swingShow=v=>v?Math.round(50+v/127*25)+'%':'OFF';
/* GRAIN (Clouds): PITCH knob: left half (0..64) = -12..+12 semitones, 32 = 0; right half = random pitch per grain, up to +-12 semitones;
   DENS: left = even grains, middle = none, right = random grains */
const grSemi=v=>v<=64?-12+24*v/64:0;
const grPitchShow=v=>{if(v>64)return'RND +-'+Math.max(1,Math.round(12*(v-64)/63));const st=Math.round(grSemi(v));return(st>0?'+':'')+st+' ST';};
const grDensShow=v=>{const d=v/127;return d>=.53?'RND '+Math.round((d-.53)/.47*100):d<=.47?'EVN '+Math.round((.47-d)/.47*100):'NONE';};
/* GRAIN from before v83 (own engine): old DENS (grains per second) becomes random grains, old PITCH keeps its semitones */
const grOldDens=v=>Math.round(64+v/127*63),grOldPitch=v=>{const st=Math.round((v/127-.5)*24);let best=64,e=99;for(let q=0;q<128;q++){const d=Math.abs(grSemi(q)-st)+Math.abs(q-v)*1e-4;if(d<e){e=d;best=q;}}return best;};
/* send slots A and B: one effect each, TYPE and the four knobs and RETURN shared, SEND and PRE per track */
/* send TYPE, in knob order (the core maps it with SD_ORDER): the reverbs first. ROOM = Freeverb, HALL = Airwindows Galactic,
   PLATE = Dattorro's plate, SHIMMER = PLATE with the Clouds pitch shifter an octave up in the loop, CLOUDSEED = the Schwung CloudSeed */
const SEND_TYPES=[['ROOM',['SIZE','DAMP','TONE','WIDTH']],['HALL',['SIZE','DECAY','TONE','MOD']],['PLATE',['SIZE','DECAY','TONE','MOD']],['SPRING',['SIZE','INTENS','TONE','DRIVE']],
  ['SHIMMER',['SIZE','DECAY','SHIMMER','TONE']],['CLOUDSEED',['SIZE','DECAY','MOD','TONE']],
  ['DELAY',['TIME','FDBK','TONE','WIDTH']],['TAPE',['TIME','FDBK','WOW','SAT']],
  ['BBD',['TIME','FDBK','TONE','MOD']],['PHASER',['RATE','DEPTH','FDBK','CENTER']],['FLANGE',['RATE','DEPTH','FDBK','DELAY']],
  ['CHORUS',['RATE','DEPTH','WIDTH','TONE']],['LOOP',['AMOUNT','TONE','DRIVE','TIME']],['GRAIN',['SIZE','DENS','PITCH','TEX']]];
const sName=sl=>SEND_TYPES[sType(sl)][0],isRev=sl=>['ROOM','PLATE'].includes(sName(sl)),isShim=sl=>sName(sl)==='SHIMMER';
/* saved send TYPE values from before GRAIN (8 types) are moved to the same type in the list of 9; a GRAIN send from before v83 gets Clouds values */
/* states from before v88: GLOBAL scale OFF meant a scale per track; now the scale is GLOBAL only, so take the first melody track's */
const globMig=d=>{if(d&&d.glob&&!d.keyV&&fromV(d.glob[0],SCALES.length+1)===0){const x=(d.tracks||[]).find(x=>x&&x.v&&x.v.pitch&&x.v.pitch[2]>0)||(d.tracks||[])[5];
  d.glob[0]=x&&x.v&&x.v.pitch?toV(1+fromV(x.v.pitch[1],SCALES.length),SCALES.length+1):toV(3,SCALES.length+1);if(x&&x.v&&x.v.pitch)d.glob[1]=x.v.pitch[0];}return d;};
const SEND_V=6,sendMig=d=>{if(d&&d.sendShared&&!(d.sendV>=2))d.sendShared.forEach(a=>{if(a)a[1]=toV(fromV(a[1],8),9);});
  if(d&&d.sendShared&&!(d.sendV>=3))d.sendShared.forEach(a=>{if(a&&fromV(a[1],9)===8){a[3]=grOldDens(a[3]);a[4]=grOldPitch(a[4]);a[5]=64;}});
  if(d&&d.sendShared&&!(d.sendV>=4))d.sendShared.forEach(a=>{if(a)a[1]=toV(fromV(a[1],9),10);});   /* SPRING joined the send types */
  if(d&&d.sendShared&&!(d.sendV>=5))d.sendShared.forEach(a=>{if(a)a[1]=toV([1,3,4,5,6,7,8,9,10,2][fromV(a[1],10)],11);});   /* v118: ROOM joined, the reverbs first */
  if(d&&d.sendShared&&!(d.sendV>=6))d.sendShared.forEach(a=>{if(a)a[1]=toV([0,2,3,6,7,8,9,10,11,12,13][fromV(a[1],11)],14);});   /* v118: HALL, SHIMMER, CLOUDSEED joined */
  if(d&&d.sendShared)d.sendShared.forEach(a=>{if(a&&a.length<9)a[8]=64;});return d;};               /* TAPE FILTER came later: open */
/* STUTTER per track (t.v.stu) and the master repeat's (stutShared); the track's AUTO is t.v.sauto.
   SHIFT + turn sets all tracks and the master repeat */
const ST_LENS=['1/128','1/64','1/32','1/16','1/8T','1/8','3/16','1/4','1/2','1 BAR'];
const ST_DESTS=[['LP OPN','LP OPEN'],['LP CLS','LP CLOSE'],['HP OPN','HP OPEN'],['BP SWP','BP SWEEP'],['PIT DN','PITCH DOWN'],['PIT UP','PITCH UP'],['VOLUME','VOLUME'],['PAN','PAN']];
const REP_PADS=['1/32','1/16','1/8','3/16','1/4','1/2','1 BAR','REV'];
/* since v107: LENGTH RAMP, ENV DEST, ENV DEPTH, GLITCH, SNAP, MIX, LFO DEPTH, LFO SPEED, LFO DEST (the core's order) */
const STU0=[44,0,8,64,0,89,127,0,0,8],stutShared=[...STU0,0,0];   /* + [10] RISE, [11] SWEEP (TRIGGERS row 3), 0 = off, 1..4 */
const RISE_L=['1/4','1/2','1 BAR','2 BARS'],SWEEP_L=['1/2','1 BAR','2 BARS','4 BARS'];
const ST_SPEEDS=['REPEAT','1 BAR','1/2','1/4','1/8','1/16','1/32','1/64'];
/* the STUTTER page, knob by knob: PROB (was AUTO) LENGTH RAMP BREAK SHAPE (were GLITCH SNAP, Lef 13 nov) VAR.C (in the old ENV depth slot) LFO MIX; SHIFT: LFO = its SPEED; the stu index each knob drives */
const STK=[-1,0,1,4,5,3,7,6],STK_SH={};   /* no knob has its own SHIFT job: SHIFT = all tracks + the master repeat; LFO SPEED / DEST are on STUT.LFO (Lef 22 nov) */   /* knob 6 = VAR.C in stu[3] (the old ENV depth slot, Lef 13 nov) */
/* v102-v106 STUTTER (LENGTH SHAPE DEST DEPTH BREAK SNAP MIX) to v107: BREAK splits into RAMP and GLITCH, the SHAPE becomes ENV (PLUCK, SWELL, SWEEP) or the LFO (WOBBLE) */
const stu107=o=>{const sh=fromV(o[1],5),br=o[4],wob=sh===4;return[o[0],br<64?Math.min(127,br*2):127,o[2],wob?0:o[3],br>64?Math.min(127,(br-64)*2):0,o[5],o[6],wob?o[3]:0,0,o[2]];};
/* older STUTTER values (v101 knob order LENGTH DEPTH MODE ATTACK DECAY DEST RAMP GLITCH, MIX shared) to the new ones:
   ENV A > PLUCK, ENV B > SWEEP, A+B > PLUCK + SWEEP, LFO > WOBBLE; RAMP or GLITCH > BREAK; a short DECAY > a high SNAP */
const SHP_OLD=[0,2,3,4,4],stuOf=s=>[s[0],s[1],s[2],s[3],s[4],s[5],s[8]||0,s[7]];
const stuNew=(o,mix)=>[o[0],toV(SHP_OLD[fromV(o[2],5)],5),o[5],o[1],o[7]>0?Math.round(64+o[7]/2):Math.round((o[6]||0)/2),127-o[4],mix];
const sendShared=[[0,22,70,70,64,32,0,76,64],[0,59,86,51,76,102,0,76,64]];   /* TYPE 22 = PLATE, 59 = DELAY (of 14); [8] = TAPE FILTER (Shift + FDBK) */
const tapeF=sl=>ui.shift&&SEND_TYPES[sType(sl)][0]==='TAPE';
const sType=k=>fromV(sendShared[k][1],SEND_TYPES.length);
const DIVS=['1/32','1/16T','1/16','1/8T','1/16D','1/8','1/4T','1/8D','1/4','1/4D','1/2'];
const COMP_TYPES=['GLUE','PUNCH','SMASH'];
const NOISES=['WHITE','PINK','BROWN','BLACK'];
const CDIVS=['/8','/4','/3','/2','1','X2','X3','X4'];
const cdiv=v=>CDIVS[Math.min(7,Math.floor(v/128*8))];
/* full names for the bottom line of the screen */
const LONG={'ENV.P':'PITCH ENVELOPE: EACH HIT STARTS HIGHER AND FALLS','DEC.P':'PITCH ENVELOPE DECAY: HOW FAST IT FALLS','TYPE.N':'NOISE TYPE','ENV.F':'FILTER ENVELOPE DECAY','AMT.F':'FILTER ENVELOPE AMOUNT','ATK.F':'FILTER ENVELOPE ATTACK','DEC.C':'CLICK DECAY','TONE.C':'CLICK TONE','T1.SND':'SEND AMOUNT OF THIS TRACK','T1.PRE':'SEND PRE / POST FADER, THIS TRACK',XMOD:'CROSS MODULATION',PWM:'PULSE WIDTH',SUB:'SUB OSCILLATOR LEVEL',CLOCK:'CLOCK DIVIDER OF THIS TRACK',ROTATE:'ROTATE: SHIFT THE PATTERN',MORPH:'MORPH: BETWEEN THE WAVETABLES',WARP:'WARP: BEND THE WAVE',DETUNE:'DETUNE: SPREAD THE VOICES',DELAY:'DELAY SEND, ALL TRACKS','SLC.L':'SLICE LENGTH','TUNE.S':'TUNE SAMPLE','MON.L':'MONITOR LEVEL','TIME.M':'MAX RECORDING TIME','VAR.I':'VARIATION INDEX','VAR.D':'VARIATION DECAY','X.MOD':'X.MOD: BODY AND RING MODULATE EACH OTHER','MIX.N':'NOISE LEVEL: BODY < > WIRES (SNAPPY)','SCL.M':'MAIN SCALE: ALL TRACKS, LEFT = OFF (EACH TRACK ITS OWN)','ROOT.M':'MAIN ROOT: ALL TRACKS','EQ.F':'BELL EQ AFTER THE DRIVE: FREQUENCY, SHIFT: DB','EQ.G':'BELL EQ GAIN: -12 TO +12 DB',SIDECH:'SIDECHAIN AMOUNT, SHIFT: WHICH TRACK','SC.SRC':'SIDECHAIN: THE TRACK THAT DUCKS THIS ONE',INTENS:'INTENSITY: DECAY, AT THE TOP IT RUNS AWAY','VAR.T':'VARIATION TRIGGERS','VAR.V':'VARIATION VELOCITY','VAR.M':'VARIATION MELODY',FOLLOW:'FOLLOW: NOTES OF TRACK','LIST.N':'LISTEN NOTES: PLAY THE NOTES OF ANOTHER TRACK','LIST.T':'LISTEN TRIGGERS: ALSO PLAY ON THE HITS OF ANOTHER TRACK',PORTA:'PORTAMENTO: GLIDE',TEX:'TEXTURE: GRAIN SHAPE, DIFFUSION',TURING:'TURING: 0 = LOCKED','L.NOTE':'FOLLOW: NOTES OF TRACK',HARM:'HARMONY ON THE LISTENED NOTE',GATE:'GATE: NOTE LENGTH (303)',TUNE:'TUNE',CURVE:'ENV CURVE',CLAPS:'CLAPS: 1 SNAP .. 40 APPLAUSE','P.ENV':'PITCH ENVELOPE','S.TIME':'SWEEP TIME',FOLD:'WAVEFOLDER',PROB:'MASTER PROB: ALL HITS',SIZE:'GRAIN SIZE',FREEZE:'FREEZE: HOLD THE BUFFER',POS:'POSITION: HOW FAR BACK',FEEDBK:'FEEDBACK, RIGHT END = FREEZE',SPREAD:'SPREAD: HARMONIC > METAL',CUTOFF:'FILTER CUTOFF',RESO:'RESONANCE',CHAR:'CHARACTER',ALGO:'VCO MODEL / CLOUDS MODE',SOURCE:'SOURCE: A TRACK OR PING',PERC:'PERCUSSION DECAY','F.AMT':'FILTER ENVELOPE AMOUNT','F.ENV':'FILTER ENVELOPE DECAY','F.ATK':'FILTER ENVELOPE ATTACK',TIMBRE:'TIMBRE',WAVE:'WAVEFORM',ENV:'ENV MOD (303)',RAT:'RAT DISTORTION',SLIDE:'SLIDE: STEPS THAT GLIDE',ACCENT:'ACCENT: STEPS WITH ACCENT',FILTER:'FILTER LOW < OPEN > HIGH',COLOR:'COLOR (SHIFT + FILTER)',ATK:'COMP ATTACK',REL:'COMP RELEASE',THRESH:'COMP THRESHOLD',RATIO:'COMP RATIO',SAT:'SATURATION',MIX:'MIX',COMP:'COMPRESSOR PUSH',PRE:'PRE / POST LEVEL',ATTACK:'ATTACK',PAN:'PAN',RAMP:'RAMP: REPEATS GET SHORTER',GLITCH:'GLITCH: REVERSE, HALVE, SKIP',DEPTH:'STUTTER DEPTH',DEST:'STUTTER DESTINATION',LENGTH:'STUTTER LENGTH','L.TRIG':'LISTEN: HITS OF TRACK','L.PROB':'LISTEN PROB','RND.V':'VARIATION VELOCITY',ROOT:'ROOT NOTE',MODE:'LANE MODE','VAR.R':'VARIATION TRIGGERS','VAR.P':'VARIATION PITCH','VAR.S':'VARIATION SOUND',DENS:'DENSITY',
  'RATE.1':'LFO 1 RATE','DEPTH.1':'LFO 1 DEPTH','RATE.2':'LFO 2 RATE','DEPTH.2':'LFO 2 DEPTH',
  FDBK:'FEEDBACK','RATE.A':'RANDOM A RATE','DEPTH.A':'RANDOM A DEPTH','RATE.B':'RANDOM B RATE','DEPTH.B':'RANDOM B DEPTH',CHAOS:'CHAOS',REV:'REVERSE',WASH:'WASH: OPEN AND PUSH SEND A',SWING:'SWING: EVERY SECOND 16TH LATER'};
/* ---------- pitch lane ---------- */
/* scales: [short, long, cents in one period, period in cents]; HARMONIC uses the overtone series instead */
const CH=[...Array(12)].map((_,i)=>i*100);
const SCALES=[['CHROM','CHROMATIC',CH,1200],['FREE','FREE (ATONAL)',CH,1200],['MAJOR','MAJOR',[0,200,400,500,700,900,1100],1200],
  ['MINOR','MINOR',[0,200,300,500,700,800,1000],1200],['DORIAN','DORIAN',[0,200,300,500,700,900,1000],1200],
  ['PHRYG','PHRYGIAN',[0,100,300,500,700,800,1000],1200],['LYDIAN','LYDIAN',[0,200,400,600,700,900,1100],1200],
  ['MIXO','MIXOLYDIAN',[0,200,400,500,700,900,1000],1200],['LOCRI','LOCRIAN',[0,100,300,500,600,800,1000],1200],
  ['PMAJ','PENTATONIC MAJOR',[0,200,400,700,900],1200],['PMIN','PENTATONIC MINOR',[0,300,500,700,1000],1200],
  ['WHOLE','WHOLE TONE',[0,200,400,600,800,1000],1200],['OCTA','OCTATONIC',[0,200,300,500,600,800,900,1100],1200],
  ['HIRA','HIRAJOSHI',[0,200,300,700,800],1200],['PELOG','PELOG (APPROX)',[0,120,270,540,670,800,950],1200],
  ['SLEND','SLENDRO (APPROX)',[0,240,480,720,960],1200],['HARM','HARMONIC SERIES',null,1200],
  ['19EDO','19-EDO',[...Array(19)].map((_,i)=>i*1200/19),1200],['24EDO','24-EDO',[...Array(24)].map((_,i)=>i*50),1200],
  ['BP','BOHLEN-PIERCE',[...Array(13)].map((_,i)=>i*1902/13),1902],
  ['BLUES','BLUES',[0,300,500,600,700,1000],1200],['HMIN','HARMONIC MINOR',[0,200,300,500,700,800,1100],1200],
  ['MMIN','MELODIC MINOR',[0,200,300,500,700,900,1100],1200],['HUNG','HUNGARIAN MINOR',[0,200,300,600,700,800,1100],1200],
  ['DHARM','DOUBLE HARMONIC',[0,100,400,500,700,800,1100],1200],['PERS','PERSIAN',[0,100,400,500,600,800,1100],1200],
  ['NEAP','NEAPOLITAN MINOR',[0,100,300,500,700,800,1100],1200],['ENIGM','ENIGMATIC',[0,100,400,600,800,1000,1100],1200],
  ['PROM','PROMETHEUS',[0,200,400,600,900,1000],1200],['IWATO','IWATO',[0,100,500,600,1000],1200],
  ['INSEN','IN SEN',[0,100,500,700,1000],1200],['KUMOI','KUMOI',[0,200,300,700,900],1200],
  ['TODI','RAGA TODI',[0,100,300,600,700,800,1100],1200],['HIJAZ','MAQAM HIJAZ',[0,100,400,500,700,800,1000],1200],
  ['RAST','MAQAM RAST (1/4 TONES)',[0,200,350,500,700,900,1050],1200],['BAYAT','MAQAM BAYATI (1/4 TONES)',[0,150,300,500,700,800,1000],1200],
  ['17EDO','17-EDO',[...Array(17)].map((_,i)=>i*1200/17),1200],['31EDO','31-EDO',[...Array(31)].map((_,i)=>i*1200/31),1200],
  ['ALPHA','CARLOS ALPHA (NO OCTAVE)',[0],78],['GAMMA','CARLOS GAMMA (NO OCTAVE)',[0],35.1]];
/* GLOBAL page (PERF layer, page 2): knob 1 SCALE = OFF (each track its own scale) or one scale for all tracks, knob 2 its ROOT */
const glob=[0,0,21,64,41,25,19,127,38,0],GLOB_START=glob.slice(); /* SCALE ROOT, compressor TYPE THRESH RATIO ATK SAT MIX, [8] = REL, [9] = MAKE-UP (0 = AUTO) */
const gScale=()=>Math.max(0,fromV(glob[0],SCALES.length+1)-1),mainOn=()=>fromV(glob[0],SCALES.length+1)>0;   /* MAIN SCALE OFF: each track plays its own SCALE / ROOT (Lef 15 nov) */
const KEY0=()=>[toV(gScale(),SCALES.length),glob[1]];  /* a track's own SCALE / ROOT starts at the MAIN key; tracks with RANGE 0 are free */
const NOTES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const HARMS=['UNI','3RD','4TH','5TH','6TH','OCT','-3RD','-5TH','-OCT','ANSWER'];   /* HARM (Shift + SCALE): scale steps above the followed note; ANSWER = its note before, a third up */
const PVARS=['DOWN','UP','INVERT','REVERSE','SHUFFLE','OCTAVE','SIMPLE','ANSWER']; /* PITCH row 4 */
const toV=(i,n)=>Math.min(127,Math.floor((i+.5)*128/n));
const SC0=()=>[toV(1,9),0,64,64],CS0=()=>[64,64,64,64,0,0,32,0,0];   /* CHANNEL: EQ.L EQ.M EQ.F EQ.H COMP MONO.B MONO.F SAT, TYPE.S (console 0..4) */
const CONSOLES=['NEVE','API','SSL','TEAC','MACKIE'];
const dbShow=v=>{const d=Math.round((v-64)/63*12);return d===0?'0DB':(d>0?'+':'')+d+'DB';},fqShow=f=>f<1000?Math.round(f)+'HZ':(f/1000).toFixed(1)+'K';   /* SIDECHAIN start: source T1, amount 0 */
const fromV=(v,n)=>Math.min(n-1,Math.floor(v/128*n));
/* how a STUTTER knob reads, in knob order */
const pct=v=>Math.round(v/127*100)+'%';
function stutShow(k,v){const sh=ui.shift&&STK_SH[k]!=null;
  if(k===1)return ST_LENS[fromV(v,10)];
  if(k===9)return ST_DESTS[fromV(v,8)][0];
  if(k===2){const n=Math.round(v/127*3);return n?n+' STEP':'OFF';}   /* RAMP: 0..3 steps over the stutter */
  if(k===5)return Math.abs(v-64)<=1?'OFF':(v<64?'/ ':'X ')+Math.round(Math.abs(v-64)/(v<64?64:63)*100)+'%';   /* VAR.C: bipolar, / = slower, X = faster */
  if(k===6&&sh)return ST_SPEEDS[fromV(v,8)];
  if((k===2||k===3||k===5||k===6)&&v<2)return'OFF';
  return pct(v);}
/* the PITCH knobs: ROOT SCALE RANGE MODE LENGTH GEN GLIDE OCTAVE */
const pMode=t=>t.v.pitch[3]>=64?1:0,
  pRange=t=>t.v.pitch[2]===0?0:1+Math.round((t.v.pitch[2]-1)/126*35),pLen=t=>1+t.v.pitch[4],turP=t=>Math.pow(t.v.pitch[5]/127,2),pOct=t=>fromV(t.v.pitch[7],5)-2;
const scaleOf=t=>mainOn()?gScale():fromV(t.v.key[0],SCALES.length),rootOf=t=>fromV(mainOn()?glob[1]:t.v.key[1],12);
/* with a melody (RANGE on) the PITCH macro picks the octave, C1..C7 with C4 in the middle, so the lane stays in the scale */
const P_OCTS=7,pitchOct=t=>fromV(t.v.macros[0],P_OCTS),octP=t=>Math.log2(32.7032*Math.pow(2,pitchOct(t))/20)/8;
/* L.TRIG (Shift + DENS): OFF or one of the other 7 tracks; its own pattern hits also play this track */
const lisOpts=t=>[-1,...tracks.map((_,i)=>i).filter(i=>tracks[i]!==t)];
const lisSrc=t=>lisOpts(t)[fromV(t.v.lis[0],8)];
/* pan reads C in the middle, L/R with an amount to the sides */
/* FILTER: LP 1..100 < OPEN > HP 1..100, the open zone matches the core (0.47..0.53) */
const FILT_MID=[60,67],filtOpen=v=>v>=FILT_MID[0]&&v<=FILT_MID[1];
const filtShow=v=>filtOpen(v)?'OPEN':v<60?'LP'+Math.max(1,Math.round((0.47-v/127)/0.47*100)):'HP'+Math.max(1,Math.round((v/127-0.53)/0.47*100));
const panShow=v=>Math.abs(v-64)<1?'C':(v<64?'L'+Math.round((64-v)/64*50):'R'+Math.round((v-64)/63*50));
const lisShow=t=>lisSrc(t)<0?'OFF':'T'+(lisSrc(t)+1);
/* L.NOTE (PITCH knob 1): the track this one takes its notes from, harmonised by HARM in its own scale */
const folSrc=t=>t.v.fol?lisOpts(t)[fromV(t.v.fol[0],8)]:-1,folShow=t=>folSrc(t)<0?'OFF':'T'+(folSrc(t)+1),hrmOf=t=>fromV(t.v.hrm[0],HARMS.length),pMel=t=>pRange(t)>0||folSrc(t)>=0;
/* with FOLLOW on, RANGE: left = OFF (the very note of the followed track, no HARM), then +-1..12 semitones of the root, right = FULL (no limit) */
const folOff=t=>folSrc(t)>=0&&t.v.pitch[2]===0;
const folRange=t=>folSrc(t)>=0&&t.v.pitch[2]>0&&t.v.pitch[2]<127?1+Math.round((t.v.pitch[2]-1)/125*11):0;
/* scale notes (semitones above the root) from degree a to degree b */
function sclDeg(t,a,b){const sc=SCALES[scaleOf(t)],out=[];for(let d=a;d<=b;d++){if(!sc[2]){if(d>=0)out.push(12*Math.log2(d+1));continue;}
  const n=sc[2].length;out.push(Math.floor(d/n)*sc[3]/100+sc[2][((d%n)+n)%n]/100);}return out;}
function folFit(t,c){const N=folRange(t);if(!N)return c;let o=c-rootOf(t);
  while(o>N&&o-12>=-N)o-=12;while(o<-N&&o+12<=N)o+=12;
  if(o>N||o<-N){const w=sclDeg(t,-40,40).filter(x=>Math.abs(x)<=N+1e-6);if(w.length)o=w.reduce((a,x)=>Math.abs(x-o)<Math.abs(a-o)?x:a);else o=Math.max(-N,Math.min(N,o));}  /* the edge, but on a note of the scale */
  return rootOf(t)+o;}
/* RANGE on: the notes random pitch and pitch modulation may land on (the range in the scale); RANGE off: none, pitch is free */
function sclNotes(t){const b=12*pOct(t)+rootOf(t);
  if(folSrc(t)>=0){const N=folRange(t)||12;return sclDeg(t,-40,40).filter(x=>Math.abs(x)<=N+1e-6).map(x=>b+x);}
  const R=pRange(t);return R?sclDeg(t,0,R).map(x=>b+x):[];}
const rangeV=R=>R===0?0:1+Math.round((R-1)/35*126);
/* fill the lane with scale degrees 0..RANGE from the chosen generator */
function pitchGen(t,from=0){if(!from)acidRoll(t);const R=pRange(t),g=Math.floor(rnd()*3);let w=Math.round(R/2),reg=Math.floor(rnd()*256);
  for(let s=from;s<MAXS;s++){let d;
    if(g===0)d=Math.round(rnd()*R);
    else if(g===1){w=Math.max(0,Math.min(R,w+Math.round((rnd()*2-1)*2)));d=w;}
    else if(g===2){const top=reg>>7&1;reg=((reg<<1)&255)|(rnd()<.1?1-top:top);d=Math.round(reg/255*R);}
    else{const top=reg>>7&1;reg=((reg<<1)&255)|(rnd()<.1?1-top:top);d=Math.round(reg/255*R);}
    t.pdeg[s]=d;t.pcent[s]=(rnd()*2-1)*50;}}
/* semitones above the PITCH macro for lane step s; RANGE 0 = no melody, OCTAVE always counts */
function semis(t,s){return 12*pOct(t)+laneSemis(t,s);}
function laneSemis(t,s){const R=pRange(t);if(!R)return 0;const d=Math.min(R,playDeg(t)[s]),sc=SCALES[scaleOf(t)];
  if(!sc[2])return rootOf(t)+12*Math.log2(d+1);
  const n=sc[2].length,c=Math.floor(d/n)*sc[3]+sc[2][d%n]+(sc[0]==='FREE'?t.pcent[s]:0);return rootOf(t)+c/100;}
function harmSemis(t,src,s){const L=pLen(src),h=hrmOf(t),sc=SCALES[scaleOf(t)],n=sc[2]?sc[2].length:7,Rs=pRange(src);
  const off=folOff(t),q=h===9&&!off&&t.eng!==CHORD?(s+L-1)%L:s,d0=Rs?Math.min(Rs,playDeg(src)[q]):0,k=off||t.eng===CHORD?0:[0,2,3,4,5,n,-2,-4,-n,2][h],d=d0+k,fit=off?x=>x:x=>folFit(t,x);
  if(!sc[2])return 12*pOct(t)+fit(rootOf(t)+12*Math.log2(Math.max(0,d)+1));
  const c=Math.floor(d/n)*sc[3]+sc[2][((d%n)+n)%n];return 12*pOct(t)+fit(rootOf(t)+c/100);}
/* J60: the two notes above the root of each step. HARM picks the chord, with or without FOLLOW (Lef 14 / 15 nov); UNI = one note (see jMono) */
function chordIv(t,s){const R=pRange(t),sc=SCALES[scaleOf(t)],n=sc[2]?sc[2].length:0,MAJ=[0,2,4,5,7,9,11];
  const d=R&&n&&n<9?Math.min(R,playDeg(t)[s]||0):0,c=k=>n&&n<9?(Math.floor(k/n)*sc[3]+sc[2][k%n])/100:Math.floor(k/7)*12+MAJ[k%7],iv=k=>c(d+k)-c(d);
  const h=hrmOf(t);return h===2?[iv(3),iv(4)]:h===3?[iv(4),12]:h===4?[iv(2),iv(5)]:h===5?[12,12]:h===6?[iv(2)-12,iv(4)]:h===7?[iv(2),iv(4)-12]:h===8?[iv(2),-12]:h===9?[iv(2),iv(6)]:[iv(2),iv(4)];}
const jMono=t=>t.eng===CHORD&&hrmOf(t)===0;   /* HARM UNI on J60: one note, also when it FOLLOWs a track (Lef 15 nov) */
function noteName(t,s){const st=semis(t,s),k=Math.round(st);return NOTES[((k%12)+12)%12]+(Math.floor(k/12)+(pRange(t)?pitchOct(t)+1:3))+(Math.abs(st-k)>.05?'~':'');}
/* VAR.P: each loop a part of the melody changes, within the scale */
function pitchVar(i){const t=tracks[i],a=t.v.pat[1]/127,R=pRange(t);if(a<=0||!R){t.pvd=null;return;}const d=t.pdeg.slice();  /* VAR.P: like VAR.R, your notes stay */
  const n=Math.max(1,Math.round(a*a*pLen(t)*.5));for(let k=0;k<n;k++){const s=Math.floor(rnd()*pLen(t));d[s]=Math.round(rnd()*R);}t.pvd=d;t.psig=t.pdeg.join();}
const playDeg=t=>t.v.pat[1]>0&&t.pvd&&t.psig===t.pdeg.join()?t.pvd:t.pdeg;
/* track effects: max 4 knobs each, main parameter first, mix last */
const FX=[['FILTER',['FREQ','RESO','TYPE','MIX']],['DRIVE',['DRIVE','FOLD','EQ.F','MIX']],['CRUSH',['FILTER','BITS','RATE','----']],
  ['RING',['FREQ','SHAPE','----','MIX']],['RESO',['FREQ','DECAY','TONE','MIX']],['DELAY',['TIME','FDBK','TONE','MIX']],
  ['GRAIN',['SIZE','DENS','PITCH','MIX']],['OFF',['----','----','----','----']],['SPRING',['SIZE','DECAY','TONE','MIX']],
  /* GRID FX LIBRARY (Lef 20 nov): Airwindows MAXIM=ADClip8 DENSE=Density2 TUBE=Tube2 SPIRAL=Spiral2 FOLD=Fracture2 TAPE=ToTape8 PRESS=Pressure5 HUGE=Huge,
     PHASER and FLANGE from the send code, WIDE and ENSMBL stereo (own code) */
  ['MAXIM',['BOOST','CEIL','MODE','MIX']],['DENSE',['DENS','HPF','OUT','MIX']],['TUBE',['INPUT','TUBE','----','MIX']],['SPIRAL',['INPUT','HPF','PRES','MIX']],
  ['FOLD',['DRIVE','FRACT','THRESH','MIX']],['TAPE',['INPUT','TILT','FLUTR','MIX']],['PRESS',['PRESS','SPEED','MEWI','MIX']],['HUGE',['HUGE','NASTY','----','MIX']],
  ['PHASER',['RATE','DEPTH','FDBK','MIX']],['FLANGE',['RATE','DEPTH','FDBK','MIX']],['WIDE',['WIDTH','TIME','LOW.C','----']],['ENSMBL',['RATE','DEPTH','WIDTH','MIX']],
  ['TANK',['DRIVE','FREQ','HARM','MIX']],['OTT',['DEPTH','TIME','UP','MIX']],['NEBULA',['POS','SIZE','DENS','MIX']],['TP.DLY',['TIME','FDBK','FILTER','MIX']]];   /* ECHO (Lef 24 nov): tape delay on the clock; Shift + FDBK = WOW, Shift + FILTER = SAT */   /* NEBULA (Lef 24 nov): the GRAIN Clouds with the NEBULA engine's ALGO; Shift: ALGO TEX REVERB FDBK */   /* OTT (Lef 22 nov): 3-band up + down compressor after TinyHouse (BSD) */   /* TANK (Lef 20 nov, efs_tank.h): Shift + FREQ = GRIT, Shift + MIX = FDBK */
const GRAIN=6,FX_OFF=7,SPRING=8,MAXIM=9,TANKFX=21,NEBFX=23,ECHOFX=24,ECHO_T=['1/32','1/16','1/16D','1/8','1/8D','1/4','1/4D','1/2'],EC_SHIFT=['TIME','WOW','SAT','MIX'],AD_MODES=['NORMAL','GAIN.M','CLIP.O','AFTERB','EXPLOD','NUKE','APOCAL','APOTH'];
/* the library: every effect but OFF, in this order on knob 1 while a grid pad is held (1 s) */
const FX_LIB=[1,0,2,3,4,5,24,6,8,21,23,22,9,10,11,12,13,14,15,16,17,18,19,20],FXLIB0=()=>[1,0,2,3,4,5,6,8,9,11,13,14,17,18,19,21];   /* row 2 and row 3 of the grid each their own 8 (Lef 22 nov): row 3 MAXIM TUBE FOLD TAPE PHASER FLANGE WIDE TANK */
const fxLibOf=a=>Array.isArray(a)&&(a.length===8||a.length===16)?a.concat(FXLIB0().slice(a.length)):FXLIB0();   /* an older preset has 8: row 3 gets its defaults */
let fxLib=FXLIB0();   /* the effect on each of the 8 grid pads (rows 2 and 3), stored with the preset */  /* OFF: the slot passes the sound through untouched */
/* the 8 pads of rows 2 / 3 pick a slot type: pad 8 = SPRING; the lit pad again = OFF */
const padFx=k=>fxLib[k]!=null&&FX[fxLib[k]]?fxLib[k]:FXLIB0()[k];   /* k = grid pad 0..15: row 2 = 0..7, row 3 = 8..15 */   /* default pads: DRIVE FILTER CRUSH RING RESO DELAY GRAIN SPRING (Lef 19 nov: the filter comes after the drive); held 1 s = pick from the library */
/* ACID GATE (Shift + DECAY): note length 10 % .. 50 % (middle) .. 100 % of a step, as the core maps it */
const gateShow=v=>{const g=v/127;return Math.round((g<.5?.1+.8*g:g)*100)+'%';};
const CPU_SPIKE=.85;   /* above this the bottom line says CPU HIGH */
const CPU_WARN=.6;  /* placing a GRAIN above this CPU load shows a warning (it is placed anyway) */
/* how an FX slot value reads: GRAIN PITCH in semitones, DENS as even / none / random, REVERB in %, FEEDBK in % with FREEZE at the top */
function fxShow(t,k,v){if(eqK(t,k)&&t.slot[k>>2]===2){return ui.shift?Math.round(t.v.eq[k>>2]/127*100)+'%':String(v).padStart(3,'0');}if(eqK(t,k)){if(ui.shift){const d=Math.round((t.v.eq[k>>2]-64)/63*12);return d===0?'0DB':(d>0?'+':'')+d+'DB';}const f=60*Math.pow(2,v/127*7.64);return f<1000?Math.round(f)+'HZ':(f/1000).toFixed(1)+'K';}if(k===scK(t)){if(!ui.shift)return Math.round(t.v.sc[1]/127*100)+'%';const n=fromV(t.v.sc[0],9);return n?'T'+n:'OFF';}if(t.slot[k>>2]===2&&k%4===0&&!ui.shift)return filtShow(v);if(t.slot[k>>2]===0&&k%4===2&&!ui.shift)return['LP','BP','HP'][v/127<.34?0:v/127<.67?1:2];if((t.slot[k>>2]===SPRING||t.slot[k>>2]===TANKFX)&&isGrainShift(t,k))return Math.round(v/127*100)+'%';if(t.slot[k>>2]===TANKFX&&k%4===1)return tkHz(30*Math.pow(2,v/127*8.6));if(t.slot[k>>2]===TANKFX&&k%4===2)return tkHarm(v);if(t.slot[k>>2]===ECHOFX){if(isGrainShift(t,k))return Math.round(v/127*100)+'%';if(k%4===0)return ECHO_T[Math.min(7,Math.floor(v/127*8))];if(k%4===2)return filtShow(v);}if(t.slot[k>>2]===MAXIM&&k%4===2)return AD_MODES[Math.min(7,Math.floor(v/127*7.999))];if(t.slot[k>>2]===NEBFX&&isGrainShift(t,k)&&k%4===0)return NEB_ALGO[Math.min(3,Math.floor(v/127*4))];if(t.slot[k>>2]!==GRAIN&&!(t.slot[k>>2]===NEBFX&&isGrainShift(t,k)))return String(v).padStart(3,'0');
  if(isGrainShift(t,k)&&t.slot[k>>2]===TANKFX){const j=k%4;return j===2?(Math.abs(v-64)<2?'OFF':(v<64?'DOWN ':'UP ')+Math.round(Math.abs(v-64)/63*100)+'%'):j===1?String(v).padStart(3,'0'):Math.round(v/127*100)+'%';}
  if(isGrainShift(t,k)){if(k%4===3)return v>=GR_FRZ?'FREEZE':Math.round(v/GR_FRZ*100)+'%';if(k%4===2)return Math.round(v/127*100)+'%';return String(v).padStart(3,'0');}
  if(k%4===2)return grPitchShow(v);if(k%4===1)return grDensShow(v);return String(v).padStart(3,'0');}
/* GRAIN with Shift: SIZE -> POSITION, DENS -> TEXTURE, PITCH -> REVERB, MIX -> FEEDBK (FREEZE at the top);
   kept in t.v.gx: texture 1, feedback 1, texture 2, feedback 2, position 1, reverb 1, position 2, reverb 2 */
const GR_FRZ=124,GX0=()=>[64,0,64,0,0,0,0,0],GR_SHIFT=['POS','TEX','REVERB','FEEDBK'],NB_SHIFT=['ALGO','TEX','REVERB','FDBK'],TK_SHIFT=['RESO','GRIT','ENV','FDBK'];
/* a new effect in slot r (0, 1): its knobs from the middle of their safe range, the hidden SHIFT knobs back; TANK: RESO 86 %, ENV +50 % */
function fxFresh(t,r,c){FX_RANGE[c].forEach(([lo,hi],j)=>t.v.fx[r*4+j]=Math.round((lo+hi)/2));t.v.gx[r*2]=c===ECHOFX?32:64;t.v.gx[r*2+1]=0;t.v.gx[4+r*2]=c===TANKFX?110:0;t.v.gx[5+r*2]=c===TANKFX?96:0;t.v.eq[r]=c===2?0:64;}
const isGrainShift=(t,k)=>ui.shift&&(t.slot[k>>2]===GRAIN||t.slot[k>>2]===SPRING&&k%4===3||t.slot[k>>2]===TANKFX||t.slot[k>>2]===NEBFX||t.slot[k>>2]===ECHOFX&&(k%4===1||k%4===2));   /* ECHO: Shift + FDBK = WOW, Shift + FILTER = SAT */   /* NEBULA: Shift = ALGO TEX REVERB FDBK */   /* TANK: Shift = RESO GRIT ENV FDBK (Lef 22 nov) */  /* SPRING: Shift + MIX = FEEDBK too */
const gxIdx=k=>{const s=k>>2,j=k%4;return j===1?s*2:j===3?s*2+1:4+s*2+(j===2?1:0);};
/* layers (left keys) and their encoder pages (+ / -), max 4 pages per layer */
const LAYERS={
  track:{name:'TRACK',pages:[{name:'MACRO',key:'macros',labels:MACROS},{name:'PATTERN',key:'pat',labels:PATTERN,ord:PAT_ORD},
    {name:'MOD',key:'mod',labels:['RATE.1','DEPTH.1','RATE.2','DEPTH.2','RATE.A','DEPTH.A','RATE.B','DEPTH.B']},
    {name:'PITCH',key:'pitch',labels:['L.NOTE','HARM','RANGE','MODE','LENGTH','TURING','GLIDE','OCTAVE']}]},
  param:{name:'GLOBAL',pages:[{name:'ALL ENGINE',key:'macros',labels:MACROS},{name:'ALL TRIGGERS',key:'pat',labels:PATTERN,ord:PAT_ORD}]},  /* one value for all 8 tracks, the pages after GLOBAL */
  perf:{name:'PERF',pages:[{name:'PERFORM',key:'perf',labels:PERF},{name:'STUTTER',key:'stut',labels:['PROB','LENGTH','RAMP','BREAK','SHAPE','VAR.C','LFO','MIX']}]},
  glob:{name:'GLOBAL',pages:[{name:'GLOBAL',key:'glob',labels:['SCALE','ROOT','TYPE','THRESH','RATIO','ATK','SAT','MIX']}]},
  fx:{name:'FX',pages:[{name:'SLOTS',key:'fx'},{name:'SEND A',key:'sA'},{name:'SEND B',key:'sB'},
]}};
/* reverb pre-delay in steps (the core's PRE_STEPS) and how the REVERB knobs read */
/* how a SEND page value reads: TYPE by name, delay times as note values, PRE on / off */
function sendFmt(slot,k,v){const ty=sType(slot);if(k===1)return SEND_TYPES[ty][0];if(k===3&&tapeF(slot))return filtShow(v);if(SEND_TYPES[ty][0]==='GRAIN'&&k===4)return grPitchShow(v);if(SEND_TYPES[ty][0]==='GRAIN'&&k===3)return grDensShow(v);if(k===6)return v>=64?'PRE':'POST';
  const nm=SEND_TYPES[ty][0];if(k===4&&(nm==='PLATE'||nm==='ROOM')||k===5&&nm==='SHIMMER')return filtShow(v);
  if(k===2&&(nm==='DELAY'||nm==='TAPE'))return DIVS[Math.min(10,Math.floor(v/128*11))];
  if(k===2&&nm==='BBD')return Math.round(5*Math.pow(2,v/127*6.3))+'MS';return num(v);}
/* modulation */
const RATES=['PAT','8BAR','4BAR','2BAR','1/1','1/2','1/4','1/8','1/16','1/32','1/64','1/128','1/256'];   /* the core's EFS_RATES */
const rate=v=>RATES[fromV(v,RATES.length)];
/* a free LFO: 0 = SYNC (on the clock), else 0.05..20 Hz, as in the core */
const hzShow=v=>{const h=0.05*Math.pow(2,Math.max(v,.13)/127*10.97);   /* free: 0.05..100 Hz, also fully left */return(h<1?h.toFixed(2):h<10?h.toFixed(1):String(Math.round(h)))+'HZ';};
const WAVES=['SINE','TRI','SAW UP','SAW DN','SQUARE','S&H','RANDOM'];
/* link sources in step/key order, the same as their bit in the core's route mask */
const SOURCES=['LFO1','LFO2','ENV','RND A','RND B','LFO3'];
/* ---------- the four categories (left keys) and their pages (+ / -) ----------
   The pages above stay as the engine room. A category page either shows one of them as it is (src: [layer, page])
   or picks its knobs from them: {src: [layer, page, knob]}, with
   lab = own label, shift: 0 / 1 = SHIFT forced off / on, sh = another knob while SHIFT is held, all = SHIFT sets all tracks;
   {own: name} = a knob of its own (OWN), null = empty */
/* TRIGGERS page 1 with ALGO OTOMAT (Lef 26 nov): knobs 2-4 follow the ALGO, as K2 does for the others: CELL (SHIFT: RND.F), COL, ROW; 5-8 stay */
const OTO_K=[null,{own:'OTO.CELL',sh:{own:'OTO.RND'}},{own:'OTO.COL'},{own:'OTO.ROW'}];
const kT=(k,o)=>Object.assign({src:['track',1,k]},o),kP=(k,o)=>Object.assign({src:['track',3,k]},o),kM=(k,o)=>Object.assign({src:['track',0,k]},o),
  kF=(k,o)=>Object.assign({src:['perf',0,k]},o),kG=(k,o)=>Object.assign({src:['glob',0,k]},o);
const CATS=[
  {name:'TRIGGERS',pages:[
    {name:'TRIGGERS',base:['track',1],knobs:[{own:'ALGO'},{own:'K2'},{own:'DENS'},{own:'ROTATE'},kT(4),kT(0,{lab:'VAR.T'}),kT(3,{lab:'VAR.V'}),kT(6)]},
    {name:'TRIGGERS 2',base:['track',1],knobs:[kT(7),{own:'LIST.M'},{own:'L.TRIG'},{own:'RPT.T'},null,null,null,null]},   /* CLOCK, LIST.M (Lef 24 nov), LIST.T on 3 as LIST.N on PITCH, RPT.T on 4 (Lef 24 nov) */
    {name:'STUTTER',base:['perf',1],knobs:[0,1,2,3,4,5,6,7].map(k=>({src:['perf',1,k]}))},
    {name:'STUT.LFO',base:['perf',1],knobs:[{own:'LFO.S'},{own:'LFO.D'},null,null,null,null,null,null]},
    ]},
   /* the STUTTER LFO's SPEED and DEST (Lef 22 nov) */   /* knob 6 = VAR.C */
  {name:'PITCH',pages:[
    {name:'PITCH',base:['track',3],knobs:[kM(0,{sh:kP(7,{shift:0})}),kP(2),kP(0,{lab:'LIST.N',sh:kP(3,{shift:0})}),kP(1),kP(6,{lab:'PORTA',shift:0,all:1}),{own:'VAR.P'},kT(1,{lab:'VAR.M'}),kP(4)]},
    {name:'PITCH 2',base:['track',3],knobs:[{own:'SCALE'},{own:'ROOT'},{own:'TUNE'},kP(5,{shift:0,sh:{own:'LINK'}}),kP(5,{shift:1,off:t=>t.eng!==ACID,sh:{own:'AMT.A'}}),kP(6,{shift:1,off:t=>t.eng!==ACID,sh:{own:'TIME.S'}}),kP(3,{shift:0,all:1}),kP(7,{shift:0,all:1})]}]},   /* MODE, OCTAVE own knobs, also SHIFT on PITCH 1 (Lef 22 nov) */
  {name:'ENGINE',pages:[
    {name:'ENGINE',base:['track',0],eng:0},
    {name:'ENGINE 2',base:['track',0],eng:1},
    {name:'WIRES',base:['track',0],eng:2,only:t=>t.eng===SNARE},
    {name:'TANK ENV',base:['track',0],eng:2,only:t=>t.eng===TANK},
    {name:'CHIP',base:['track',0],eng:2,only:t=>t.eng===SID},
    {name:'VIB/FX',base:['track',0],eng:2,only:t=>t.eng===CHORD},   /* J60 (Lef 26 nov): vibrato, drift, drive, VAR.S, chorus */
    {name:'SAMPLE 2',base:['track',0],eng:2,only:t=>t.eng===SAMPLE},
    {name:'OSC',base:['track',0],eng:2,only:t=>wtE(t)},   /* WAVETABLE, WT DRUM: TUNE.O FINE.O TUNE.B, UNISON (Lef 22 nov) */
    {name:'WARP',base:['track',0],eng:3,only:t=>wtE(t)},  /* WAVETABLE, WT DRUM: SYNC BEND FORM FOLD (SHIFT ASYM), A on 1-4, B on 5-8 (Lef 22 nov) */   /* SAMPLE only: TIME.M SYNC DIR VAR.I BITS RATE GAIN off SHIFT, on a page of their own (Lef 22 nov) */   /* TANK only: the filter envelope on a knob of its own (Lef 22 nov) */   /* SNARE only: the snare wires off SHIFT, on a page of their own (Lef 19 nov) */
    {name:'MOD 1',base:['track',0],knobs:['LFO1.S','LFO1.W','LFO1.A','LFO1.D','LFO2.S','LFO2.W','LFO2.A','LFO2.D'].map(n=>({own:n}))},
    {name:'MOD 2',base:['track',0],knobs:[{own:'LFO3.S'},{own:'LFO3.W'},{own:'LFO3.A'},{own:'LFO3.D'},{own:'ENV.AT'},{own:'ENV.DC'},{own:'ENV.A'},{own:'ENV.D'}]},   /* LFO 3 right after LFO 1 and 2, then ENV (Lef 22 nov) */
    {name:'MOD 3',base:['track',0],knobs:[{own:'RNDA.S'},{own:'RNDA.A',sh:{own:'RNDA.SM'}},{own:'RNDA.D'},null,{own:'RNDB.S'},{own:'RNDB.A',sh:{own:'RNDB.SM'}},{own:'RNDB.D'},null]},
    {name:'P-LOCK',base:['track',0],knobs:[{own:'PLOCK.G'},{own:'PLOCK.H'},null,null,null,null,null,null]},   /* P-lock options, for every knob (Lef 22 nov) */
    {name:'FX SLOTS',src:['fx',0]},
    {name:'SIDECHAIN',base:['track',0],knobs:[{own:'SIDECH'},{own:'SC.TIME',sh:{own:'FILT.S'}},{own:'SC.SRC'},null,null,null,null,null]},   /* own page (Lef 19 nov): 1 amount, 2 duck time (SHIFT detector filter), 3 source */
    {name:'CHANNEL',base:['track',0],knobs:[{own:'EQ.L'},{own:'EQ.M'},{own:'EQ.F'},{own:'EQ.H'},null,{own:'MONO.B',sh:{own:'MONO.F'}},{own:'SAT',sh:{own:'TYPE.S'}},{own:'COMP'}]}]},   /* CHANNEL STRIP per track, the same for every engine (Lef 17 nov) */
  {name:'PERF',pages:[
    {name:'PERFORM',base:['perf',0],knobs:[kF(1,{shift:0}),kF(1,{shift:1}),kF(0,{all:1}),kF(2),kF(4),kF(6),kF(5),{own:'C.MKUP'}]},   /* knob 8 = master MAKE-UP, with COMP on 7 (Lef 19 nov) */
    {name:'PERFORM 2',base:['perf',0],knobs:[kF(3,{shift:0}),null,null,null,kG(0,{shift:0,lab:'SCL.M'}),kG(1,{shift:0,lab:'ROOT.M'}),null,null]},   /* MAIN SCALE / ROOT: over every track, far left = OFF (Lef 15 nov) */
    {name:'SEND A',src:['fx',1]},{name:'SEND B',src:['fx',2]},
    {name:'COMP',base:['glob',0],knobs:[kG(2),kG(3),kG(4),kG(5,{shift:0}),kG(6),{own:'C.REL'},{own:'C.MKUP'},kG(7)]},   /* MIX on knob 8, like every MIX/LEVEL (Lef 13 nov); RELEASE, MAKE-UP on 6, 7 (Lef 18 nov) */
    {name:'ALL ENGINE',src:['param',0]},{name:'ALL TRIGGERS',src:['param',1]}]}];
/* a page with only() shows only for the selected track's engine; cpage() falls back to the page before it */
const pgOk=(c,i)=>{const p=CATS[c].pages[i];return!!p&&(!p.only||p.only(tracks[ui.sel]));};
const pgVis=c=>CATS[c].pages.map((_,i)=>i).filter(i=>pgOk(c,i));
const cpage=()=>{while(ui.cp[ui.cat]>0&&!pgOk(ui.cat,ui.cp[ui.cat]))ui.cp[ui.cat]--;return CATS[ui.cat].pages[ui.cp[ui.cat]];};
const FXPG=CATS[2].pages.findIndex(p=>p.name==='FX SLOTS');
const catName=()=>CATS[ui.cat].name;
/* ENGINE: page 1 = the shape of the sound and the knobs played most, page 2 = the algorithm and the nature of the sound.
   Per engine 8 knobs a page: K = engine knob K, 'sK' = the SHIFT job of engine knob K, 'VS' = VAR.S, a name = an own knob (OWN),
   [a, b] = a, SHIFT: b; null = empty. Page 1: SHIFT = all tracks; page 2: SHIFT = all tracks with the same engine */
const E1=(f,six)=>['s1',1,'CURVE','VAR.D',f,six,'VS',7],TEX_P=[E1(2,'s4'),['s2',3,4,5,'s5',6,'s6','TEX.MODE']];   /* TEX: MODE on ENGINE 2 knob 8 (Lef 25 nov) */
const ENG_PG=[
  [E1(2,[4,'s4']),[3,'s2','s5',5,6,'s6',null,null]],          /* FM-PERC */
  TEX_P,TEX_P,TEX_P,TEX_P,                                      /* TEX FM, RING, SYNC, SWARM */
  [['s1',1,'CURVE','VAR.D',[2,3],4,'VS',7],['s3',5,'s2',6,'s6',null,[{spec:kP(6,{shift:1})},'TIME.S'],[{spec:kP(5,{shift:1})},'AMT.A']]],   /* ACID: F.ENV next to CUTOFF, RAT on page 2 (Lef 15 nov); SLIDE, ACCENT also on 7-8, not LEVEL on 8 here (Lef 22 nov) */
  [E1(2,'GDRV'),[3,4,5,'s2',6,'s6',null,null]],                 /* DUST */
  [['s1',1,'CURVE','VAR.D',2,3,['s2',4],7],['s6','J6.WAVE','s3',5,'J6.NOIS','J6.HPF','J6.FKEY','s4'],['J6.VIB','J6.VIBR','J6.VIBD','J6.DRFT','GDRV','VS',6,'CHOR.A']],   /* J60 (Lef 26 nov, in signal order): ENGINE 2 = the source (VOICE WAVE PWM SUB NOISE) and the filter extras; VIB/FX = movement and colour, the chorus mix on 8 */      /* J60: CUTOFF RESO F.AMT (SHIFT F.DEC) on page 1, DRIVE F.ATK VAR.S on page 2 (Lef 24 nov) */
  [['s1',1,'CURVE','VAR.D',2,'GDRV','VS',7],[3,4,5,'s3','s2','s4','s5',[6,'s6']]],   /* MATTER */
  [['s1',1,null,'VAR.D',2,5,'VS',7],[{k:3,lab:'CLAPS'},4,6,null,null,null,null,null]],   /* HANDS: no CURVE, the claps keep their own envelope (Lef 19 nov);  (v118: TONE and COLOR gone, the clap band stays at its default; FILTER on page 1 is its one LP / HP filter) */
  [['s1',1,'CURVE','VAR.D',2,3,['s2',4],7],['s3',5,'s6',6,'s4','VS','SCHOR','CHOR.A']],      /* SHARK: knob 7, 8 = the J60 chorus (Lef 17 nov); filter on page 1 as J60 (Lef 24 nov) */
  [['s1',1,'CURVE','VAR.D',2,3,['s2',4],7],['s6',5,6,'s3','GDRV','s4','VS',null]],          /* HIVE: as J60 (Lef 24 nov) */
  [E1('NFILT','GDRV'),['s2',6,2,[3,'s4'],4,5,'s3','s5']],       /* NEBULA */
  [['TATK',1,'s1','VAR.D',6,[2,'DEC.P'],'VS',7],['s2',4,5,'s4','s5',3,'s3','s6']],   /* THUMP */
  [['s1',1,'CURVE','VAR.D',[2,3],[4,'DEC.P'],'VS',7],['s2','s4',6,['s3','s5'],'DEC.M','CRUSH',5,'TYPE.F']],   /* SOPHIE */
  [['s1',1,'CURVE','VAR.D',2,[4,'DEC.P'],'VS',7],['SN.ALGO',t=>snA(t)?['----','BAL','INDEX','TYPE.B'][snA(t)]:'NOISE.8',t=>snA(t)?'DEC.B':'DEC.N',t=>snA(t)?'TUNE.R':'DEC.B',t=>snA(t)?'DEC.R':'TUNE.R',t=>!snA(t)?'DEC.R':snA(t)>=2?3:null,5,'MIX.R'],['TYPE.W','COL.W','RESO.W',t=>snA(t)?'DEC.W':null,'SNAP',null,null,t=>snA(t)?6:null]],   /* SNARE: ENGINE 2 = BODY and RING (knob 2 = the ALGO's own, X.MOD only XXX and 000), WIRES = the snare wires (Lef 19 nov) */
  [['s1',1,'CURVE','VAR.D',2,4,'VS',7],['SM.ALGO','SM.START','SM.END','SM.SLICE','SM.INDEX',0,'SM.STRETCH','SM.TUNE'],['SM.TIME','SM.SYNC','SM.DIR','SM.VARI','SM.BITS','SM.RATE','SM.MON','SM.ING']],   /* ENGINE 2: PITCH STRETCH TUNE.S side by side; SAMPLE 2: the knobs that were on SHIFT, MON.L and GAIN (Lef 22 nov) */
  [E1(2,'GDRV'),[['WT.TA','WT.FBA'],['WT.PA','WT.POSM'],['WT.TB','WT.FBB'],['WT.PB','WT.XFB'],['WT.TUNE','WT.FINE'],'WT.FM','WT.RING','WT.MIX'],WT_OSC,WT_WARP],   /* WAVETABLE (Lef 20 nov); OSC, WARP (Lef 22 nov) */
  [['s1',1,'CURVE','VAR.D',2,[4,'DEC.P'],'VS',7],['WT.TA','WT.TB','WT.SCAN','WT.PA','WT.FM','WT.MIX','WT.TUNEA','WT.TUNE'],WT_OSC,WT_WARP],   /* WT DRUM (Lef 20 nov) */
  [E1(2,'GDRV'),[['TK.EXC','TK.VOICES'],['TK.RES1','TK.DET'],['TK.HARM','TK.FM'],['TK.RES2','TK.AM'],'TK.PAR',['TK.MODE','TK.CORR'],'TK.GRIT',['TK.FB','TK.FBHZ']],['TK.ENV',null,null,null,null,null,null,null]],
  [['s2','s4',4,'SID.FM',2,3,'VS',7],['s1',1,'SID.SUS','SID.REL',['SID.ARP','SID.HOLD'],'SID.RATE','SID.OCT','s6'],[6,['s3','SID.PWM'],'SID.SUB',5,'SID.CHIP',null,null,null]]];   /* ENGINE 2 (Lef 25 nov): ATTACK DECAY SUSTN REL, then the ARP (SHIFT: HOLD) RATE OCT CHORD; no VAR.D on SID */   /* SID (Lef 25 nov): ENGINE = the whole filter: CUTOFF RESO VAR.S F.AMT F.ATK F.DEC FILT.M LEVEL; ENGINE 2 = ATTACK DECAY SUSTN VAR.D on 4-7 as on the other engines' page 1; CHIP; ARP with HOLD */   /* TANK (Lef 20 nov) */   /* WT DRUM (Lef 20 nov) */   /* SAMPLE (Lef 18 nov) */   /* SNARE: page 2 = BODY and RING, SHIFT = the NOISE layer (MIX.N under MIX.R) */
/* ENGINE page 1 (Lef 24 nov): the knobs you reach for first on 1-3: FILTER / CUTOFF, the old knob 6 (F.ENV, P.ENV, DRIVE ...), VAR.S;
   then the envelope ATTACK (ACID GATE), DECAY, CURVE, VAR.D on 7, LEVEL stays on 8. The rows above keep the old order, this turns them */
{const seen=new Set();ENG_PG.forEach(e=>{const r=e[0];if(seen.has(e))return;seen.add(e);e[0]=[r[4],r[5],r[6],r[0],r[1],r[2],r[3],r[7]];});}
function engSpec(r,pg){if(typeof r==='function')r=r(tracks[ui.sel]);if(r==='----')r=null;if(Array.isArray(r))r=ui.shift?r[1]:r[0];else if(r!=null&&ui.shift&&r!==7)r={all:r};
  const all=r&&r.all!=null?1:0;if(all)r=r.all;if(r==null)return null;
  let s=r&&r.spec?r.spec:r==='VS'?kT(2,{shift:0}):typeof r==='string'&&r[0]==='s'&&r.length===2?kM(+r[1],{shift:1}):typeof r==='string'?{own:r}:r===7?kM(7):typeof r==='object'?kM(r.k,{shift:0,lab:r.lab}):kM(r,{shift:0});
  if(all&&!s.own)s=Object.assign({},s,{all:1,eng:pg});return s;}
/* the spec of knob i on the page on screen (null = empty) */
function kSpec(i){const p=cpage();if(p.src)return{src:[p.src[0],p.src[1],i]};if(p.eng!=null)return engSpec(ENG_PG[tracks[ui.sel].eng][p.eng][i],p.eng);let s=p.knobs[i];if(p.name==='TRIGGERS'&&tracks[ui.sel].gen===8&&OTO_K[i])s=OTO_K[i];if(!s)return null;
  if(ui.shift&&s.sh){const o=s.sh.own&&OWN[s.sh.own];s=o&&o.lab(tracks[ui.sel])==='----'?Object.assign({},s,{all:1}):s.sh;}   /* a SHIFT job that is not there for this track: SHIFT = all tracks */
  else if(ui.shift&&!s.all&&s.shift==null&&!s.own&&s.src&&s.src[0]==='track')s=Object.assign({},s,{all:1});   /* a track knob without a SHIFT job: SHIFT = all tracks (Lef 13 nov) */
  return s;}
/* is knob i a knob that SHIFT sets on all tracks (the screen then says ALL TRACKS) */
function allKnob(i){if(!ui.shift||typeof i!=='number')return false;const s=kSpec(i);return!!s&&(s.all||s.own&&OWN[s.own].shAll);}
/* run f with the v106 layer and page of a spec in place (and SHIFT as the spec wants it), then put everything back */
function withCtx(c,f){const L=ui.layer,E=ui.enc[c.layer],S=ui.shift;ui.layer=c.layer;ui.enc[c.layer]=c.enc;if(c.shift!=null)ui.shift=!!c.shift;holdRender++;
  try{return f();}finally{holdRender--;ui.layer=L;ui.enc[c.layer]=E;ui.shift=S;}}
const ctxOf=s=>({layer:s.src[0],enc:s.src[1],shift:s.shift});
/* go to a category page: the v106 layer of its base (pads, steps, the screen's own pages) comes with it */
/* a category button: another category = its page 1; the same one again = its next page, after the last back to 1 (Lef 13 nov) */
function catPress(c){if(ui.menu){menuToggle(false);goPage(c,0);return;}if(ui.cat!==c){goPage(c,0);return;}const v=pgVis(c);goPage(c,v[(v.indexOf(ui.cp[c])+1)%v.length]);}
function goPage(cat,pg){ui.cat=cat;ui.cp[cat]=pg;const p=cpage(),b=p.src||p.base;ui.layer=b[0];ui.enc[b[0]]=b[1];ui.toast=null;ui.touched=null;}
/* ALGO on TRIGGERS: EUCL, TURING, GROOVES; generator numbers 0 = EUCL, 2 = TURING, 4 = GROOVES (was FIXD: loaded steps stay until GROOVE or DENS is turned) */
const ALGOS=[0,2,4,6,8],ALGO_N=['EUCL','TURING','ALG.G','ROLL','OTOMAT'];   /* OTOMAT (Lef 26 nov): the track plays on the hits of the shared OTOMAT field */   /* ROLL (Lef 22 nov): now and then a run of 16ths in a row, otherwise empty */
/* GROOVES: one voice, 16 steps, x = hit, o = ghost note. DENS middle = the groove as written, left = only the heaviest hits, right = ghosts added, 0 = silent */
const GROOVES=[['FOUR','x.o.x.o.x.o.x.o.'],['BACK','..o.x..o.o..x.o.'],['OFF','..xo..xo..xo..xo'],['8THS','x.x.x.xox.x.x.xo'],
  ['16THS','xxxxxxxxxxxxxxxx'],['TRESIL','x..x..xox..x..xo'],['CLAVE','x..x..x.o.x.x.o.'],['RUMBA','x..x...xo.x.x.o.'],
  ['BOSSA','x..x..x.o.x..x.o'],['CINQ','x.xx.xx.x.xx.xx.'],['DEMBOW','o..x..x.o..x..x.'],['BREAK','x.xo......x..o..'],
  ['2STEP','x..o...x..x...o.'],['SHUFFL','x.oxx.oxx.oxx.ox'],['GALLOP','x.xxx.xxx.xxx.xx'],['AFRO','x..x.x.x.x..x..x']];
/* weight of a step in the bar: the downbeat heaviest, then the half, quarters, eighths, sixteenths */
const metW=i=>i%16===0?5:i%8===0?4:i%4===0?3:i%2===0?2:1;
function groove(t,n){const g=GROOVES[t.grv??0][1],q=Math.round(t.dens/7*16),by=c=>[...Array(16).keys()].filter(i=>g[i]===c).sort((a,b)=>metW(b)-metW(a)||a-b);
  const x=by('x'),o=by('o'),k=q<=0?0:q<=8?Math.max(1,Math.round(q/8*x.length)):x.length+Math.round((q-8)/8*o.length),on=new Set([...x,...o].slice(0,k));
  return[...Array(n)].map((_,i)=>on.has(i%16));}
const algoOf=t=>Math.max(0,ALGOS.indexOf(t.gen));
/* OTOMAT (Lef 26 nov), after Otomata by Batuhan Bozkurt (2011), built from its rules (core efs_core.c oto_step): an 8 x 8 field,
   each cell moves one square per 16th (0 up, 1 right, 2 down, 3 left); at the edge it turns back and fires the track of its
   column (up / down) or of its row (left / right); cells on the same square turn a quarter clockwise.
   The field is kept with track 1 (tracks[0].oto, [x, y, dir] per cell), so presets and undo carry it */
const OTO_D=['----','UP','RIGHT','DOWN','LEFT'],OTO_START=[[0,1,2],[2,6,0],[5,3,1],[7,0,2],[3,4,3]];
const otoCells=()=>tracks[0].oto||[];
function otoField(){if(!tracks[0].oto||!tracks[0].oto.length)tracks[0].oto=OTO_START.map(c=>c.slice());ui.otoSim=null;}
const otoMask=()=>tracks.reduce((m,t,i)=>t.gen===8?m|1<<i:m,0);
/* a track that turns OTOMAT gets a cell of its own when no cell plays it yet: moving UP in its column (Lef 26 nov: no silent track) */
function otoFor(k){const F=otoCells();if(k<0||F.some(c=>c[2]&1?c[1]===k:c[0]===k))return;const free=[...Array(8).keys()].filter(y=>otoAt(k,y)<0);if(free.length&&F.length<64){F.push([k,free[Math.floor(rnd()*free.length)],0]);ui.otoSim=null;}}
function otoAt(cx,cy){return otoCells().findIndex(c=>c[0]===cx&&c[1]===cy);}
function otoSet(cx,cy,d){const a=(tracks[0].oto||[]).slice(),i=otoAt(cx,cy);if(i>=0)a.splice(i,1);if(d>0&&a.length<64)a.push([cx,cy,d-1]);tracks[0].oto=a;ui.otoSim=null;}
function otoRnd(n){const a=[],used=new Set();while(a.length<n){const cx=Math.floor(rnd()*8),cy=Math.floor(rnd()*8);if(used.has(cx+cy*8))continue;used.add(cx+cy*8);a.push([cx,cy,Math.floor(rnd()*4)]);}tracks[0].oto=a;ui.otoSim=null;}
/* the screen's copy of the field, stepped with the play position (the core plays it; this only draws it) */
function otoStep(F){const DX=[0,1,0,-1],DY=[-1,0,1,0];for(const c of F){const nx=c[0]+DX[c[2]],ny=c[1]+DY[c[2]];if(nx<0||nx>7||ny<0||ny>7)c[2]=(c[2]+2)&3;else{c[0]=nx;c[1]=ny;}}
  const n={};F.forEach(c=>n[c[0]+c[1]*8]=(n[c[0]+c[1]*8]||0)+1);F.forEach(c=>{if(n[c[0]+c[1]*8]>1)c[2]=(c[2]+1)&3;});}
function otoTick(g){if(!otoMask())return;if(!ui.otoSim||g<ui.otoSim.g){ui.otoSim={g:-1,F:otoCells().map(c=>c.slice())};}
  let k=0;while(ui.otoSim.g<g&&k++<64){ui.otoSim.g++;otoStep(ui.otoSim.F);}if(cpage().name==='TRIGGERS'&&tracks[ui.sel].gen===8&&ui.touched>=1&&ui.touched<=3&&!ui.menu&&!ui.saver)draw();}
const ROLL_N=15,rlenOf=t=>Math.max(2,Math.min(16,t.roln||4));   /* LEN.R: 2..16 sixteenths in a row */
const rdOf=t=>Math.max(0,Math.min(16,t.rold??8));   /* DENS.R (SHIFT + DENS on ROLL): 0..16, how often a roll comes */
/* ROLL: an even (EUCL) base rhythm, DENS = its hits; on top runs of LEN.R 16ths in a row now and then,
   DENS.R = how often (at least one run when DENS.R is not 0) (Lef 22 nov) */
function roll(t,n){const b=euclid(Math.round(t.dens/7*n),n,0),L=Math.min(rlenOf(t),n),p=rdOf(t)/16*.1;if(rdOf(t)<=0)return b;let runs=0;
  for(let s=0;s<n;){if(s+L<=n&&rnd()<p){for(let k=0;k<L;k++)b[s+k]=true;runs++;s+=L+1;}else s++;}
  if(!runs){const s=Math.floor(rnd()*Math.max(1,n-L+1));for(let k=0;k<L;k++)b[s+k]=true;}return b;}
/* ROTATE on TURING, ALG.G and ROLL: the steps there are move d steps right within the length (drawn steps move along) */
function rotSteps(t,d){const n=Math.max(1,t.len),a=t.steps.slice(0,n);for(let i=0;i<n;i++)t.steps[((i+d)%n+n)%n]=a[i];}
const VDC_L=['1/64','1/32','1/16','1/8','1/4','1 BAR'],vdcI=t=>fromV((t.v.vdc||[toV(2,6)])[0],6);   /* CLK.D: a new random decay every ... (default 1/16) */
/* knobs of their own: label, and either a value 0..127 (get / set) or steps (n, idx, setIdx); shAll = SHIFT sets all tracks */
const OWN={
  ALGO:{lab:()=>'ALGO',long:'ALGORITHM: EUCL TURING ALG.G (GROOVES) ROLL OTOMAT',n:()=>ALGOS.length,idx:algoOf,
    setIdx:(t,i)=>{if(ALGOS[i]!==t.gen){pickGen(t,ALGOS[i]);if(ALGOS[i]===8){otoField();otoFor(tracks.indexOf(t));}}},show:t=>ALGO_N[algoOf(t)],shAll:1},
  K2:{lab:t=>t.gen===0||t.gen===8?'----':t.gen===2?'TURING':t.gen===6?'LEN.R':'GROOVE',long:'TURING: 0 = LOCKED / GROOVE / LEN.R: 16THS IN A ROLL',shAll:1,   /* EUCL: ROTATE has its own knob now (Lef 22 nov) */
    n:t=>t.gen===4?GROOVES.length:t.gen===6?ROLL_N:0,idx:t=>t.gen===4?t.grv??0:rlenOf(t)-2,
    setIdx:(t,i)=>{if(t.gen===4){if(i!==t.grv){t.grv=i;t.steps=gen(t);}}else if(t.gen===6){if(i+2!==rlenOf(t)){t.roln=i+2;t.steps=gen(t);}}},
    get:t=>t.v.rtu[0],set:(t,v)=>{t.v.rtu[0]=v;if(t.tlink)t.v.pitch[5]=v;},
    show:(t,v)=>t.gen===6?rlenOf(t)+' ST':t.gen===4?(t.grv==null?'----':GROOVES[t.grv][0]):v?pct(v):'LOCK'},
  /* ROTATE: its own knob for every ALGO (Lef 22 nov); EUCL makes the pattern again, the others turn the steps there are */
  ROTATE:{lab:()=>'ROTATE',long:'ROTATE: THE PATTERN MOVES RIGHT',shAll:1,n:t=>Math.max(1,t.len),idx:t=>(t.rot||0)%Math.max(1,t.len),
    setIdx:(t,i)=>{const o=(t.rot||0)%Math.max(1,t.len);if(i===o)return;t.rot=i;if(t.gen===0){t.steps=gen(t);return;}rotSteps(t,i-o);},show:t=>String((t.rot||0)%Math.max(1,t.len))},
  /* L.TRIG: its own knob (was SHIFT + DENS, Lef 22 nov); SHIFT = every track hears the same track (that track itself OFF) */
  'L.TRIG':{lab:()=>'LIST.T',long:'LISTEN TRIGGERS: ALSO PLAY ON THE HITS OF ANOTHER TRACK',shAll:1,n:()=>8,idx:t=>fromV(t.v.lis[0],8),
    setIdx:(t,i)=>{const src=lisOpts(tracks[ui.sel])[i],j=lisOpts(t).indexOf(src);t.v.lis=[toV(Math.max(0,j),8)];},show:t=>lisShow(t)},
  /* LIST.M (Lef 24 nov): POST = only the source hits that pass its DENS and PROB (also when the source is muted); PRE = every pattern step of the source */
  'SID.SUS':sidK(0,'SUSTN','SUSTAIN: THE LEVEL THE SID HOLDS WHILE THE GATE IS OPEN (16 STEPS)',(t,v)=>String(Math.min(15,Math.floor(v/128*16)))),
  'SID.PWM':sidK(1,'PWM','PWM: A SLOW SWEEP OF THE PULSE WIDTH, AS A C64 PLAYER DOES IT',(t,v)=>v?pct(v):'OFF'),
  'SID.SUB':sidK(2,'SUB','SUB OSCILLATOR: OFF, ONE OR TWO OCTAVES DOWN (LEVEL = SUB.L)',['OFF','-1 OCT','-2 OCT']),
  'SID.FM':sidK(3,'FILT.M','FILTER MODE OF THE CHIP: LOW, BAND, HIGH PASS OR NOTCH',['LP','BP','HP','NOTCH']),
  'SID.CHIP':sidK(4,'CHIP','CHIP: 6581 (THE ROUGH, DIRTY FILTER) OR 8580 (CLEANER)',['6581','8580']),
  'SID.HOLD':sidK(5,'HOLD','HOLD: THE NOTE SOUNDS ON UNTIL THE NEXT NOTE (LEGATO); WITH THE ARP ON, EVERY ARP NOTE STARTS ATTACK, DECAY, SUSTN AGAIN',['OFF','ON']),
  'SID.ARP':sidK(6,'ARP','ARPEGGIATOR OVER THE CHORD (HARM ON PITCH, CHORD = VOICING)',['OFF','UP','DOWN','UP/DN','RND']),
  'SID.RATE':sidK(7,'RATE','ARP RATE: 1/16 1/32 1/64 OF THE TRACK CLOCK, OR 50 HZ (THE C64 FRAME)',['1/16','1/32','1/64','50 HZ']),
  'SID.OCT':sidK(8,'OCT','ARP OCTAVES: UP TO 3 UP OR DOWN',['-3','-2','-1','0','+1','+2','+3']),
  'TEX.MODE':{lab:t=>isTex(t)?'MODE':'----',long:'TEX MODE: HOW OSCILLATOR B WORKS ON A (WITH XMOD): FM, RING, SYNC, SWARM',shAll:1,n:()=>4,idx:t=>Math.max(0,t.eng-1),setIdx:(t,i)=>{if(isTex(t))t.eng=1+i;},show:t=>TEX_M[Math.max(0,t.eng-1)]},
  'OTO.COL':{lab:()=>'COL',long:'OTOMAT: THE COLUMN OF THE SQUARE (= THE TRACK AN UP / DOWN CELL PLAYS)',n:()=>8,idx:()=>(ui.otoC||[0,0])[0],setIdx:(t,i)=>{ui.otoC=[i,(ui.otoC||[0,0])[1]];},show:()=>'T'+((ui.otoC||[0,0])[0]+1)},
  'OTO.ROW':{lab:()=>'ROW',long:'OTOMAT: THE ROW OF THE SQUARE (= THE TRACK A LEFT / RIGHT CELL PLAYS)',n:()=>8,idx:()=>(ui.otoC||[0,0])[1],setIdx:(t,i)=>{ui.otoC=[(ui.otoC||[0,0])[0],i];},show:()=>'T'+((ui.otoC||[0,0])[1]+1)},
  'OTO.CELL':{lab:()=>'CELL',long:'OTOMAT: THE CELL ON THIS SQUARE: NONE, UP, RIGHT, DOWN, LEFT',n:()=>5,idx:()=>{const C=ui.otoC||[0,0],i=otoAt(C[0],C[1]);return i<0?0:otoCells()[i][2]+1;},
    setIdx:(t,i)=>{const C=ui.otoC||[0,0];pushUndo('oto');otoSet(C[0],C[1],i);},show:()=>{const C=ui.otoC||[0,0],i=otoAt(C[0],C[1]);return OTO_D[i<0?0:otoCells()[i][2]+1];}},
  'OTO.RND':{lab:()=>'RND.F',long:'OTOMAT: A NEW RANDOM FIELD WITH THIS MANY CELLS (0 = EMPTY)',n:()=>17,idx:()=>Math.min(16,otoCells().length),setIdx:(t,i)=>{pushUndo('oto');otoRnd(i);},show:()=>String(otoCells().length)},
  'J6.WAVE':j6K(0,'WAVE','DCO WAVE: SAW, PULSE (PWM ON KNOB 3) OR BOTH, AS THE JUNO-60 SWITCHES',['SAW','PULSE','SAW+PU']),
  'J6.NOIS':j6K(1,'NOISE','NOISE: WHITE NOISE INTO THE FILTER, AS THE JUNO\'S NOISE SLIDER',(t,v)=>v?pct(v):'OFF'),
  'J6.HPF':j6K(2,'HPF','HIGH-PASS FILTER: 4 STEPS AS ON THE JUNO-60, 0 = FLAT',['0','1','2','3']),
  'J6.VIB':j6K(3,'VIB','VIBRATO: THE LFO ON THE PITCH, UP TO A SEMITONE',(t,v)=>v?pct(v):'OFF'),
  'J6.VIBR':j6K(4,'VIB.R','VIBRATO RATE: 0.3 TO 19 HZ',(t,v)=>(0.3*Math.pow(2,v/127*6)).toFixed(1)+'HZ'),
  'J6.VIBD':j6K(5,'VIB.D','VIBRATO DELAY: THE VIBRATO FADES IN AFTER EACH NOTE, UP TO 3 S',(t,v)=>v?(v/127*3).toFixed(1)+'S':'0'),
  'J6.DRFT':j6K(6,'DRIFT','ANALOG DRIFT: EACH VOICE WANDERS SLOWLY OUT OF TUNE, UP TO 20 CENTS',(t,v)=>v?pct(v):'OFF'),
  'J6.FKEY':j6K(7,'F.KEY','FILTER KEY FOLLOW: THE CUTOFF FOLLOWS THE NOTE, FULL = AN OCTAVE PER OCTAVE',(t,v)=>pct(v)),
  'SID.REL':sidK(9,'REL','RELEASE: HOW LONG THE SID FADES WHEN THE GATE CLOSES (16 STEPS)',(t,v)=>SID_DEC[Math.min(15,Math.floor(v/128*16))]),   /* Lef 25 nov */
  'LIST.M':{lab:()=>'LIST.M',long:'LISTEN MODE: POST = ONLY THE HITS THAT PASS THE SOURCE PROB, PRE = EVERY STEP',shAll:1,n:()=>2,idx:t=>(lmv(t)[0]>=64?1:0),
    setIdx:(t,i)=>{t.v.lm=[i?127:0];},show:t=>lmv(t)[0]>=64?'PRE':'POST'},
  LINK:{lab:t=>t.gen===2?'LINK':'----',long:'LINK: TRIGGERS AND PITCH TURING ARE ONE MACHINE',n:()=>2,idx:t=>t.tlink?1:0,
    setIdx:(t,i)=>{t.tlink=!!i;if(i)t.v.pitch[5]=t.v.rtu[0];},show:t=>t.tlink?'ON':'OFF'},
  CURVE:{lab:t=>hasCurve(t)||t.eng===HANDS||t.eng===ACID||t.eng===MATTER||isSyn(t)&&t.eng!==THUMP?'CURVE':'----',long:'ENV CURVE',get:t=>t.v.crv[0],set:(t,v)=>t.v.crv[0]=v,show:(t,v)=>curveShow(v),shAll:1},
  TONE:{lab:t=>t.eng===HANDS?'TONE':'----',long:'TONE',get:t=>t.v.macros[0],set:(t,v)=>{t.v.macros[0]=v;if(t.home)t.home[0]=v;},show:(t,v)=>toneShow(v)+'HZ',shAll:1},
  /* the fixed jobs of ENGINE page 1 on the engines that had no knob for them */
  TATK:{lab:t=>t.eng===THUMP?'ATTACK':'----',long:'ATTACK: THE KICK FADES IN',get:t=>t.v.tat[0],set:(t,v)=>t.v.tat[0]=v,show:(t,v)=>timeShow(decSec(v)),shAll:1},
  'DEC.M':{lab:t=>t.eng===SOPHIE?'DEC.M':'----',long:'METAL DECAY: 0 = WITH THE PITCH SWEEP',get:t=>t.v.tat[0],set:(t,v)=>t.v.tat[0]=v,show:(t,v)=>v?Math.round(Math.max(5,2000*(v/127)**2))+'MS':'AUTO',shAll:1},
  CRUSH:{lab:t=>t.eng===SOPHIE?'CRUSH':'----',long:'CRUSH: SAMPLE RATE AND BITS',get:t=>t.v.gdr[0],set:(t,v)=>t.v.gdr[0]=v,show:(t,v)=>pct(v),shAll:1},
  'TYPE.F':{lab:t=>t.eng===SOPHIE?'TYPE.F':'----',long:'FILTER TYPE: LP HP NOTCH DJ BP',n:()=>5,idx:t=>fromV(t.v.nf[0],5),setIdx:(t,i)=>t.v.nf[0]=toV(i,5),show:t=>SO_TYPEF[fromV(t.v.nf[0],5)],shAll:1},
  /* SNARE: the layers' own knobs */
  /* ACID (PITCH 2, SHIFT + ACCENT / SLIDE): accent strength, slide time (Lef 18 nov) */
  'AMT.A':{lab:t=>t.eng===ACID?'AMT.A':'----',long:'ACCENT STRENGTH: HOW HARD AN ACCENT HITS (MIDDLE = 303)',get:t=>(t.v.acx||(t.v.acx=ACX0()))[1],set:(t,v)=>(t.v.acx||(t.v.acx=ACX0()))[1]=v,show:(t,v)=>Math.round(v/64*100)+'%',shAll:1},
  'TIME.S':{lab:t=>t.eng===ACID?'TIME.S':'----',long:'SLIDE TIME: HOW LONG A SLIDE GLIDES',get:t=>(t.v.acx||(t.v.acx=ACX0()))[0],set:(t,v)=>(t.v.acx||(t.v.acx=ACX0()))[0]=v,show:(t,v)=>Math.round(10*Math.pow(2,v/127*5.644))+'MS',shAll:1},
  /* COMP (PERFORM 5/7): RELEASE on its own knob, MAKE-UP (Lef 18 nov) */
  'DEC.P':{lab:t=>(t.eng===SNARE||t.eng===SOPHIE||t.eng===WDRUM||t.eng===THUMP&&thAlgo(t)!==7)?'DEC.P':'----',long:'PITCH ENVELOPE DECAY: HOW FAST IT FALLS, MIDDLE = AS BUILT',shOwn:1,   /* SHIFT + ENV.P, as on FM-PERC (Lef 19 nov); THUMP 909 has its own DEC.P on ENGINE 2 */
    get:t=>(t.v.dcp||[64])[0],set:(t,v)=>t.v.dcp=[v],show:(t,v)=>{const f=Math.pow(2,(lofN(v)-.5)*4);return f<.995?'1/'+(1/f).toFixed(1)+'X':f.toFixed(1)+'X';}},
  'C.REL':{glob:1,lab:()=>'REL',long:'RELEASE: HOW FAST THE COMPRESSOR LETS GO',get:()=>glob[8],set:(t,v)=>glob[8]=v,show:(t,v)=>Math.round(10*Math.pow(2,v/127*7.2))+'MS'},
  'C.MKUP':{glob:1,lab:()=>'MAKEUP',long:'MAKE-UP GAIN: LEFT = AUTO (AS LOUD AS WITHOUT COMP), THEN 0 TO +24 DB',get:()=>glob[9]||0,set:(t,v)=>glob[9]=v,show:(t,v)=>v<1?'AUTO':'+'+Math.round((v-.5)/126.5*24)+' DB'},
  /* SAMPLE: page 2 and its SHIFT jobs */
  'TK.EXC':tkK(0,'EXCITE','EXCITE: EACH HIT PINGS THE FILTERS (LEFT) OR BURSTS CLOCK NOISE INTO THEM (RIGHT)',(t,v)=>v===0?'PING':v===127?'NOISE':pct(v)),
  'TK.RES1':tkK(1,'RESO.1','RESONANCE OF FILTER 1: RIGHT = IT SINGS BY ITSELF',(t,v)=>pct(v)),
  'TK.HARM':tkK(2,'HARM','HARMONICS: FILTER 2 = FILTER 1 / 1 1.5 2 3 .. 16; LAST PART X = FILTER 1 MOVES FILTER 2',(t,v)=>tkHarm(v)),
  'TK.RES2':tkK(3,'RESO.2','RESONANCE OF FILTER 2 (A LITTLE MORE THAN FILTER 1, AS ON THE SHERMAN)',(t,v)=>pct(v)),
  'TK.PAR':tkK(4,'PAR>SER','PARALLEL (LEFT) TO SERIES (RIGHT): FILTER 2 TAKES FILTER 1',(t,v)=>v===0?'PAR':v===127?'SER':pct(v)),
  'TK.MODE':tkK(5,'MODE','FILTER MODE: LOW PASS > BAND PASS > HIGH PASS',(t,v)=>v<8?'LP':v>119?'HP':Math.abs(v-64)<6?'BP':v<64?'LP>BP':'BP>HP'),
  'TK.GRIT':tkK(6,'GRIT','GRIT: THE FILTER CLOCK, LEFT = WARM GRAIN, RIGHT = STAIR STEPS AND CLOCK WHINE',(t,v)=>pct(v)),
  'TK.FB':tkK(7,'FDBK','FEEDBACK: THE OUTPUT BACK INTO THE INPUT, TOP 15 % RUNS AWAY (LARSEN)',(t,v)=>v>=108?'RUN '+pct(v):pct(v)),
  'TK.VOICES':tkK(8,'VOICES','VOICES: 1 .. 8 COPIES OF FILTER 1, SPREAD BY DETUNE',(t,v)=>String(1+Math.round(v/127*7))),
  'TK.DET':tkK(9,'DETUNE','DETUNE OF THE VOICES: UP TO +-50 CENTS',(t,v)=>pct(v)),
  'TK.FM':tkK(10,'FM','FM: FILTER 2 AND THE HIT MOVE THE CUTOFFS',(t,v)=>pct(v)),
  'TK.AM':tkK(11,'AM','AM: FILTER 2 MULTIPLIES THE SOUND (FAT, AGGRESSIVE)',(t,v)=>pct(v)),
  'TK.CORR':tkK(12,'CORR','CORRECTION: LEFT -B (MINUS BAND PASS), MIDDLE OFF, RIGHT -B+LH (NOTCH)',(t,v)=>Math.abs(v-64)<3?'OFF':v<64?'-B '+Math.round((64-v)/64*100)+'%':'-B+LH '+Math.round((v-64)/63*100)+'%',{bip:[64,64]}),
  'TK.ENV':tkK(14,'ENV.F','FILTER ENVELOPE: EACH HIT SWEEPS BOTH FILTERS, RIGHT UP, LEFT DOWN, UP TO 4 OCTAVES, AS LONG AS DECAY',(t,v)=>Math.abs(v-64)<2?'OFF':(v<64?'DOWN ':'UP ')+Math.round(Math.abs(v-64)/63*100)+'%'),
  'TK.FBHZ':tkK(13,'FB.HZ','FEEDBACK BAND: WHICH FREQUENCIES GO ROUND, 40 HZ .. 10 KHZ',(t,v)=>tkHz(40*Math.pow(2,v/127*8))),
  'WT.TA':wtT(0,'TBL.A','TABLE OF LAYER A: SIN>SAW PWM SYNC FORMNT, BUFFER (NEWEST RECORDING), THEN YOUR WAV FILES'),
  'WT.TB':wtT(1,'TBL.B','TABLE OF LAYER B: SIN>SAW PWM SYNC FORMNT, BUFFER (NEWEST RECORDING), THEN YOUR WAV FILES'),
  'WT.PA':wtK(1,t=>t.eng===WDRUM?'POS':'POS.A','POSITION IN TABLE A (WT DRUM: WHERE THE SCAN STARTS)',(t,v)=>pct(v)),
  'WT.PB':wtK(3,'POS.B','POSITION IN TABLE B: FIRST TO LAST FRAME',(t,v)=>pct(v)),
  'WT.TUNE':wtK(4,'TUNE.B','TUNE OF LAYER B: -24 .. +24 SEMITONES',(t,v)=>semShow(v,24),{bip:[64,64]}),
  'WT.TUNEA':wtK(14,'TUNE.A','TUNE OF THE TRANSIENT (A): -24 .. +24 SEMITONES',(t,v)=>semShow(v,24),{bip:[64,64]}),
  'WT.FM':wtK(5,t=>t.eng===WDRUM?'X.MOD':'FM','FM: B MODULATES A THROUGH ZERO (WT DRUM: X.MOD, ONLY IN THE ATTACK)',(t,v)=>pct(v)),
  'WT.RING':wtK(6,'RING','RING MODULATION OF A AND B',(t,v)=>pct(v)),
  'WT.MIX':wtK(7,'MIX.B','MIX.B: LAYER A < > LAYER B (WT DRUM: TRANSIENT < > BODY)',(t,v)=>v===64?'A=B':v<64?'A '+Math.round((64-v)/64*100)+'%':'B '+Math.round((v-64)/63*100)+'%'),
  'WT.FBA':wtK(8,'FB.A','FEEDBACK OF A ON ITS OWN PHASE',(t,v)=>pct(v)),
  'WT.FBB':wtK(10,'FB.B','FEEDBACK OF B ON ITS OWN PHASE',(t,v)=>pct(v)),
  'WT.XFB':wtK(11,'X.FB','CROSS FEEDBACK: A AND B MOVE EACH OTHER\'S PHASE',(t,v)=>pct(v)),
  'WT.POSM':wtK(9,'POS.M','B MOVES THE POSITION OF A, MIDDLE = NONE',(t,v)=>{const c=Math.round((v-64)/63*100);return c?(c>0?'+':'')+c+'%':'OFF';},{bip:[64,64]}),
  'WT.FINE':wtK(12,'FINE.B','FINE TUNE OF B: +-100 CENTS',(t,v)=>{const c=Math.round((v-64)/63*100);return(c>0?'+':'')+c+' CT';},{bip:[64,64]}),
  'WT.SYNA':wwK(0,'SYNC.A','HARD SYNC OF A: IT RUNS UP TO 36 SEMITONES ABOVE ITS NOTE AND RESTARTS EVERY CYCLE',(t,v)=>v?'+'+(v/127*36).toFixed(1)+' ST':'OFF'),
  'WT.BNDA':wwK(1,'BEND.A','BEND OF A: PHASE DISTORTION, LEFT AND RIGHT BEND THE WAVE OTHER WAYS, MIDDLE = NONE',wwBip,{bip:[64,64]}),
  'WT.FRMA':wwK(2,'FORM.A','FORMANT OF A: THE WAVE PLAYS 1 .. 5X FASTER INSIDE ITS CYCLE, THE NOTE STAYS',(t,v)=>v?'X'+Math.pow(5,v/127).toFixed(2):'OFF'),
  'WT.FLDA':wwK(3,'FOLD.A','WAVEFOLDER ON A (SHIFT: ASYM.A)',wwOff),
  'WT.ASYA':wwK(4,'ASYM.A','ASYMMETRY OF A: BENDS THE LOWER HALF OF THE WAVE',wwOff),
  'WT.SYNB':wwK(5,'SYNC.B','HARD SYNC OF B: IT RUNS UP TO 36 SEMITONES ABOVE ITS NOTE AND RESTARTS EVERY CYCLE',(t,v)=>v?'+'+(v/127*36).toFixed(1)+' ST':'OFF'),
  'WT.BNDB':wwK(6,'BEND.B','BEND OF B: PHASE DISTORTION, LEFT AND RIGHT BEND THE WAVE OTHER WAYS, MIDDLE = NONE',wwBip,{bip:[64,64]}),
  'WT.FRMB':wwK(7,'FORM.B','FORMANT OF B: THE WAVE PLAYS 1 .. 5X FASTER INSIDE ITS CYCLE, THE NOTE STAYS',(t,v)=>v?'X'+Math.pow(5,v/127).toFixed(2):'OFF'),
  'WT.FLDB':wwK(8,'FOLD.B','WAVEFOLDER ON B (SHIFT: ASYM.B)',wwOff),
  'WT.ASYB':wwK(9,'ASYM.B','ASYMMETRY OF B: BENDS THE LOWER HALF OF THE WAVE',wwOff),
  'WT.VOIC':{lab:t=>wtE(t)?'VOICES':'----',long:'UNISON: 1 .. 4 VOICES OF THE WHOLE OSCILLATOR, DETUNED (MORE CPU)',n:()=>4,idx:t=>wwv(t)[10],setIdx:(t,k)=>wwv(t)[10]=Math.max(0,Math.min(3,k)),show:t=>wwv(t)[10]+1+(wwv(t)[10]?' VOICES':' VOICE'),shAll:1},
  'WT.DET':wwK(11,'DETUNE','UNISON DETUNE: THE VOICES SPREAD UP TO +-1 SEMITONE',(t,v)=>'+-'+Math.round(Math.pow(v/127,2)*100)+' CT'),
  'WT.OTUNE':wwK(12,'TUNE.O','TUNE OF BOTH OSCILLATORS: -36 .. +24 SEMITONES, STEPLESS',(t,v)=>{const s=wtOst(v);return(s>0?'+':s<0?'-':'')+Math.abs(s).toFixed(1)+' ST';},{fine:.5,det:WT_O0,bip:[WT_O0,WT_O0]}),
  'WT.OFINE':wwK(13,'FINE.O','FINE TUNE OF BOTH OSCILLATORS: +-100 CENTS',(t,v)=>{const c=Math.round((v-64)/63*100);return(c>0?'+':'')+c+' CT';},{bip:[64,64]}),
  'WT.SCAN':wtK(13,'SCAN','SCAN: HOW FAST A HIT RUNS THROUGH THE TABLE, 5 MS .. 2 S',(t,v)=>msShow(5*Math.pow(2,v/127*8.64))),
  'SM.ALGO':smD(0,'ALGO','ALGO: THE SOURCE: MIC (THE MOVE\'S INPUT), RADIO (WI-FI) OR FILE (A WAV, LOAD PAD)',SM_ALGO),
  'SM.START':smK(1,'START','START OF THE PART THAT PLAYS',(t,v)=>pct(v)),
  'SM.END':smK(2,'LENGTH','LENGTH OF THE PART FROM START (1 MS .. ALL), MOVES WITH START',(t,v)=>{if(v>=127)return'ALL';const P=smPart(t);return P?msShow(P.len):pct(v);}),
  'SM.SLICE':smD(3,'SLC.L','SLICE LENGTH AT THE TEMPO, FROM START; ALL = THE WHOLE PART',SM_SLC,{stat:'SLICE LENGTH',show:t=>{const n=smSlices(t);return SM_SLC[fromV(smv(t)[3],SM_SLC.length)]+', '+n+(n>1?' SLICES':' SLICE');}}),   /* and how many slices that gives (Lef 18 nov) */
  'SM.INDEX':smK(4,'INDEX','INDEX: WHICH SLICE PLAYS (OF HOW MANY)',(t,v)=>(Math.min(smSlices(t)-1,Math.floor(v/128*smSlices(t)))+1)+'/'+smSlices(t),{stat:'SLICE'}),
  'SM.PITCH':smD(5,'PITCH','PITCH IN SEMITONES',[...Array(49)].map((_,k)=>(k>24?'+':'')+(k-24)+' ST')),
  'SM.TUNE':smK(6,'TUNE.S','TUNE SAMPLE: +-100 CENTS, TO PUT THE SAMPLE IN KEY',(t,v)=>{const c=Math.round((v-64)/63*100);return(c>0?'+':'')+c+' CT';},{bip:[64,64]}),
  'SM.MON':smK(7,'MON.L','MONITOR: HEAR THE INPUT, LEFT = OFF (MIC: OFF WHILE THE SPEAKER IS ON)',(t,v)=>!v?'OFF':ui.smGuard&&!smRadio(t)?'SPK OFF':pct(v)),
  'SM.TIME':smD(8,'TIME.M','MAX RECORDING TIME',smTime),
  'SM.BITS':smD(9,'BITS','BITS OF A NEW RECORDING',SM_BITS),
  'SM.RATE':smD(10,'RATE','SAMPLE RATE OF A NEW RECORDING (LOWER = LONGER)',SM_RATES),
  'SM.SYNC':smD(11,'SYNC','SYNC: RECORD 1, 2 OR 4 BARS, FROM THE NEXT BAR',SM_SYNC),
  'SM.VARI':smK(12,'VAR.I','VARIATION INDEX: CHANCE OF A RANDOM SLICE PER HIT',(t,v)=>v?pct(v):'OFF'),
  'SM.STRETCH':smK(13,'STRETCH','STRETCH: LENGTH WITHOUT CHANGING THE PITCH, LEFT = OFF, MIDDLE = 100%',(t,v)=>v<1?'OFF':Math.round(25*Math.pow(2,(v-1)/126*4))+'%',{slow:1,det:64}),   /* stepless for the LFO, half as sensitive, stops on 100% once (Lef 22 nov) */
  'SM.DIR':smD(14,'DIR','DIRECTION: FWD REV PING (THERE AND BACK) ONCE, L. = LOOP UNTIL THE ENVELOPE ENDS',SM_DIRS),
  'SM.ING':smK(15,'GAIN','GAIN OF THE SAMPLE AND THE MONITOR (THE WAVE GROWS WITH IT)',(t,v)=>{const d=Math.round((v-64)/63*24);return(d>0?'+':'')+d+' DB';},{bip:[64,64]}),
  'SN.ALGO':{lab:t=>t.eng===SNARE?'ALGO':'----',long:'ALGO: 808 909 XXX (FM, X.MOD) 000 (FREE MIX)',n:()=>4,idx:snA,setIdx:(t,i)=>{if(i!==snA(t))snareAlgo(t,i);},show:t=>SN_ALGO[snA(t)],shAll:1},
  BAL:{lab:t=>t.eng===SNARE&&snA(t)===1?'BAL':'----',long:'BALANCE: THE TWO 909 OSCILLATORS, LOW < > HIGH',get:t=>t.v.st[0],set:(t,v)=>t.v.st[0]=v,show:(t,v)=>pct(v),bip:[64,64],shAll:1},
  INDEX:{lab:t=>t.eng===SNARE&&snA(t)===2?'INDEX':'----',long:'FM INDEX: HOW DEEP THE FM GOES',get:t=>t.v.st[0],set:(t,v)=>t.v.st[0]=v,show:(t,v)=>pct(v),shAll:1},
  'TYPE.B':{lab:t=>t.eng===SNARE&&snA(t)===3?'TYPE.B':'----',long:'BODY: 808 909 FM SUB',n:()=>4,idx:t=>fromV(t.v.cc[0],4),setIdx:(t,i)=>t.v.cc[0]=toV(i,4),show:t=>SN_TB[fromV(t.v.cc[0],4)],shAll:1},
  'DEC.B':{lab:t=>t.eng===SNARE?'DEC.B':'----',long:'BODY DECAY: THE DRUM HEAD',get:t=>t.v.tat[0],set:(t,v)=>t.v.tat[0]=v,show:(t,v)=>pct(v),shAll:1},
  'TUNE.R':{lab:t=>t.eng===SNARE?'TUNE.R':'----',long:'RING TUNE: THE SHELL MODES',get:t=>t.v.col[0],set:(t,v)=>t.v.col[0]=v,show:(t,v)=>'X'+Math.pow(2,(v/127-.5)*2).toFixed(2),bip:[64,64],shAll:1},
  'DEC.R':{lab:t=>t.eng===SNARE?'DEC.R':'----',long:'RING DECAY: THE SHELL',get:t=>t.v.pw[0],set:(t,v)=>t.v.pw[0]=v,show:(t,v)=>pct(v),shAll:1},
  'MIX.R':{lab:t=>t.eng===SNARE?'MIX.R':'----',long:'RING LEVEL: 808 TONE, RIGHT = EXTRA MODES',get:t=>t.v.fa[0],set:(t,v)=>t.v.fa[0]=v,show:(t,v)=>v<3?'OFF':pct(v),shAll:1},
  'TYPE.W':{lab:t=>t.eng===SNARE?'TYPE.W':'----',long:'WIRES: 808 909 WHITE PINK CLAP BLACK',n:()=>6,idx:t=>fromV(t.v.chp[0],6),setIdx:(t,i)=>t.v.chp[0]=toV(i,6),show:t=>SN_TN[fromV(t.v.chp[0],6)],shAll:1},
  'COL.W':{lab:t=>t.eng===SNARE?'COLOR':'----',long:'WIRES COLOR: DARK < > BRIGHT',stat:'WIRES COLOR',get:t=>t.v.nf[0],set:(t,v)=>t.v.nf[0]=v,show:(t,v)=>'X'+Math.pow(2,(v/127-.5)*4).toFixed(2),bip:[64,64],shAll:1},
  'RESO.W':{lab:t=>t.eng===SNARE?'RESO.W':'----',long:'WIRES RESONANCE',get:t=>t.v.gdr[0],set:(t,v)=>t.v.gdr[0]=v,show:(t,v)=>'X'+Math.pow(2,(v/127-.5)*4).toFixed(2),bip:[64,64],shAll:1},
  'NOISE.8':{lab:t=>t.eng===SNARE?'NOISE':'----',long:'808 NOISE: HOW MUCH WHITE NOISE (THE SNAPPY)',get:t=>t.v.macros[6],set:(t,v)=>t.v.macros[6]=v,show:(t,v)=>pct(v),shAll:1},
  'DEC.N':{lab:t=>t.eng===SNARE?'DEC.N':'----',long:'808 NOISE DECAY: HOW LONG THE NOISE SOUNDS',get:t=>t.v.pe[0],set:(t,v)=>t.v.pe[0]=v,show:(t,v)=>{const ms=20*Math.pow(50,v/127);return ms<1000?Math.round(ms)+'MS':(ms/1000).toFixed(1)+'S';},shAll:1},
  'DEC.W':{lab:t=>t.eng===SNARE?'DEC.W':'----',long:'WIRES DECAY',get:t=>t.v.pe[0],set:(t,v)=>t.v.pe[0]=v,show:(t,v)=>pct(v),shAll:1},
  SNAP:{lab:t=>t.eng===SNARE?'SNAP':'----',long:'SNAP: HOLD OF THE WIRES (CLAP: HOW LONG IT CLAPS)',get:t=>t.v.fo[0],set:(t,v)=>t.v.fo[0]=v,show:(t,v)=>Math.round(120*(v/127)**2)+'MS',shAll:1},
  GDRV:{lab:t=>[DUST,CHORD,MATTER,HIVE,NEBULA,WAVE,TANK].includes(t.eng)?'DRIVE':'----',long:'DRIVE',get:t=>t.v.gdr[0],set:(t,v)=>t.v.gdr[0]=v,show:(t,v)=>num(v),shAll:1},
  NFILT:{lab:t=>t.eng===NEBULA?'FILTER':'----',long:'FILTER LOW < OPEN > HIGH',get:t=>t.v.nf[0],set:(t,v)=>t.v.nf[0]=v,show:(t,v)=>filtShow(v),bip:FILT_MID,shAll:1},
  'EQ.L':{lab:()=>'EQ.L',long:'EQ LOW SHELF 120 HZ',get:t=>t.v.cs[0],set:(t,v)=>t.v.cs[0]=v,show:(t,v)=>dbShow(v),bip:[64,64],shAll:1},
  'EQ.M':{lab:()=>'EQ.M',long:'EQ MID BELL (FREQUENCY: EQ.F)',get:t=>t.v.cs[1],set:(t,v)=>t.v.cs[1]=v,show:(t,v)=>dbShow(v),bip:[64,64],shAll:1},
  'EQ.F':{lab:()=>'EQ.F',long:'EQ MID FREQUENCY',get:t=>t.v.cs[2],set:(t,v)=>t.v.cs[2]=v,show:(t,v)=>fqShow(100*Math.pow(2,v/127*6.32)),shAll:1},
  'EQ.H':{lab:()=>'EQ.H',long:'EQ HIGH SHELF 8 KHZ',get:t=>t.v.cs[3],set:(t,v)=>t.v.cs[3]=v,show:(t,v)=>dbShow(v),bip:[64,64],shAll:1},
  SIDECH:{lab:()=>'AMT.S',long:'SIDECHAIN AMOUNT: HOW DEEP THE DUCK',get:t=>t.v.sc[1],set:(t,v)=>t.v.sc[1]=v,show:(t,v)=>pct(v)},
  /* TIME (Lef 22 nov): middle = FOLLOW the source's level; left = the duck lets go earlier than the source, down to 1/64 s after each hit;
     right = it holds on longer, a release up to 1.5 s. Own key: 'TIME.S' is ACID's slide time */
  'SC.TIME':{lab:()=>'TIME',long:'SIDECHAIN TIME: MIDDLE = FOLLOW THE SOURCE, LEFT = SHORTER, RIGHT = LONGER',shOwn:1,get:t=>scv(t)[2],set:(t,v)=>scv(t)[2]=v,
    show:(t,v)=>{const d=v/127*2-1;if(Math.abs(d)<0.02)return 'FOLLOW';const ms=d<0?1000*Math.pow(2,6*d):150*Math.pow(10,d);return (d<0?'-':'+')+(ms<1000?Math.round(ms)+'MS':(ms/1000).toFixed(1)+'S');}},
  'FILT.S':{lab:()=>'FILT.S',long:'SIDECHAIN FILTER ON THE SOURCE: LP LEFT, HP RIGHT, MIDDLE = OFF',get:t=>scv(t)[3],set:(t,v)=>scv(t)[3]=v,show:(t,v)=>Math.abs(v-64)<2?'OFF':(v<64?'LP ':'HP ')+Math.round(Math.abs(v-64)/63*100)+'%'},
  /* STUT.LFO: SHIFT = every track and the master repeat, as on STUTTER */
  'LFO.S':{lab:()=>'LFO.S',long:'STUTTER LFO SPEED: LEFT = THE STUTTER LENGTH, FURTHER = CLOCK DIVS',n:()=>8,idx:t=>fromV(t.v.stu[8],8),setIdx:(t,i)=>{t.v.stu[8]=toV(i,8);if(ui.shift)stutShared[8]=toV(i,8);},show:t=>ST_SPEEDS[fromV(t.v.stu[8],8)]},
  'LFO.D':{lab:()=>'LFO.D',long:'STUTTER LFO DESTINATION (ALSO WHERE SWEEP GOES)',n:()=>8,idx:t=>fromV(t.v.stu[9],8),setIdx:(t,i)=>{t.v.stu[9]=toV(i,8);if(ui.shift)stutShared[9]=toV(i,8);},show:t=>ST_DESTS[fromV(t.v.stu[9],8)][0]},
  'SC.SRC':{lab:()=>'SRC.S',long:'SIDECHAIN: THE TRACK THAT DUCKS THIS ONE',n:()=>9,idx:t=>fromV(t.v.sc[0],9),setIdx:(t,i)=>t.v.sc[0]=toV(i,9),show:t=>{const n=fromV(t.v.sc[0],9);return n?'T'+n:'OFF';}},
  'MONO.B':{lab:()=>'MONO.B',long:'BASS MONO: HOW MUCH, SHIFT: FREQUENCY',get:t=>t.v.cs[5],set:(t,v)=>t.v.cs[5]=v,show:(t,v)=>v?pct(v):'OFF'},
  'MONO.F':{lab:()=>'MONO.F',long:'BASS MONO: BELOW THIS FREQUENCY',get:t=>t.v.cs[6],set:(t,v)=>t.v.cs[6]=v,show:(t,v)=>fqShow(60+v/127*240)},
  SAT:{lab:()=>'SAT',long:'SATURATION (AIRWINDOWS CHANNEL9), SHIFT: CONSOLE',get:t=>t.v.cs[7],set:(t,v)=>t.v.cs[7]=v,show:(t,v)=>v?Math.round(v/127*200)+'%':'OFF'},
  'TYPE.S':{lab:()=>'TYPE.S',long:'SAT CONSOLE: NEVE API SSL TEAC MACKIE',n:()=>5,idx:t=>t.v.cs[8]|0,setIdx:(t,i)=>t.v.cs[8]=i,show:t=>CONSOLES[t.v.cs[8]|0]},
  COMP:{lab:()=>'COMP',long:'TRACK COMPRESSOR',get:t=>t.v.cs[4],set:(t,v)=>t.v.cs[4]=v,show:(t,v)=>v?pct(v):'OFF',shAll:1},
  SCHOR:{lab:t=>t.eng===SHARK?'CHORUS':'----',long:'CHORUS: OFF I II I+II (JUNO)',n:()=>4,idx:t=>t.v.shc[0],setIdx:(t,i)=>t.v.shc[0]=i,show:t=>CH_CHOR[t.v.shc[0]],shAll:1},
  'CHOR.A':{lab:t=>t.eng===CHORD||t.eng===SHARK?'CHOR.A':'----',long:'CHORUS AMOUNT',get:t=>t.v.cha[0],set:(t,v)=>t.v.cha[0]=v,show:(t,v)=>pct(v),shAll:1},
  'VAR.P':{lab:()=>'VAR.P',long:'VARIATION PITCH: RANDOM PITCH PER HIT',get:t=>t.v.vp[0],set:(t,v)=>t.v.vp[0]=v,show:(t,v)=>pct(v),shAll:1},
  SCALE:{lab:()=>'SCALE',long:'SCALE OF THIS TRACK (WHEN MAIN IS OFF)',n:()=>SCALES.length,idx:t=>fromV(t.v.key[0],SCALES.length),setIdx:(t,i)=>t.v.key[0]=toV(i,SCALES.length),show:t=>mainOn()?'MAIN':SCALES[fromV(t.v.key[0],SCALES.length)][0],shAll:1},
  ROOT:{lab:()=>'ROOT',long:'ROOT OF THIS TRACK (WHEN MAIN IS OFF)',n:()=>12,idx:t=>fromV(t.v.key[1],12),setIdx:(t,i)=>t.v.key[1]=toV(i,12),show:t=>mainOn()?'MAIN':NOTES[fromV(t.v.key[1],12)],shAll:1},
  TUNE:{lab:()=>'TUNE',long:'TUNE: SLOW WANDERING DETUNE',get:t=>t.v.tu[0],set:(t,v)=>t.v.tu[0]=v,show:(t,v)=>v?'+-'+Math.round(Math.pow(v/127,2)*60)+'CT':'OFF',shAll:1},
  /* DENS: the hits; on ROLL SHIFT = DENS.R, how often a roll comes, per track (Lef 22 nov); elsewhere SHIFT = all tracks */
  DENS:{lab:t=>ui.shift&&t.gen===6?'DENS.R':'DENS',long:'DENSITY: HOW MANY HITS; ROLL + SHIFT: DENS.R, HOW OFTEN A ROLL COMES',
    get:t=>t.v.pat[4],set:(t,v)=>{t.v.pat[4]=v;patKnob(t,4);},shOwn:t=>ui.shift&&t.gen===6,
    n:t=>ui.shift&&t.gen===6?17:0,idx:t=>rdOf(t),setIdx:(t,i)=>{if(i!==rdOf(t)){t.rold=i;t.steps=gen(t);}},
    show:t=>ui.shift&&t.gen===6?Math.round(rdOf(t)/16*100)+'%':Math.round(t.dens/7*100)+'%'},
  'VAR.D':{lab:()=>ui.shift?'CLK.D':'VAR.D',long:'VARIATION DECAY: LEFT SHORTER, RIGHT LONGER; SHIFT: CLK.D, HOW OFTEN A NEW DECAY COMES',get:t=>t.v.vd[0],set:(t,v)=>t.v.vd[0]=v,bip:[64,64],
    n:()=>ui.shift?VDC_L.length:0,idx:t=>vdcI(t),setIdx:(t,i)=>t.v.vdc=[toV(i,VDC_L.length)],shOwn:1,   /* SHIFT = CLK.D, per track (Lef 19 nov) */
    show:(t,v)=>ui.shift?VDC_L[vdcI(t)]:v===64?'OFF':(v<64?'-':'+')+Math.round(Math.abs(v-64)/(v<64?64:63)*100)+'%'},
  'RPT.T':{lab:()=>'LOOP.N',long:'LOOP.N: LOOP THE LAST N STEPS AS HEARD',shAll:1,n:()=>RPTS.length,idx:t=>Math.max(0,RPTS.indexOf(t.rpt||0)),
    setIdx:(t,i)=>{if(!ui.playing){toast('LOOP.N: PRESS PLAY FIRST',2000);return;}const k=tracks.indexOf(t);t.rpt=RPTS[i];audio.ready&&audio.send({rpt:[k,t.rpt]});},show:t=>t.rpt?t.rpt+' ST':'OFF'}};
/* MOD 1-3 (v118): per source S(peed) W(ave) A(mount) D(estination); labels source first (only on MOD).
   Core source bits: LFO1 0, LFO2 1, ENV 2, RND A 3, RND B 4 */
const MSRC={LFO1:0,LFO2:1,ENV:2,RNDA:3,RNDB:4,LFO3:5},MOD_DLY=2000;
/* the destinations of a track: every knob of its ENGINE pages 1 and 2 (also their SHIFT jobs) by core param, then TUNE, SEND A, SEND B */
const destCache={};
function destList(t){const key=t.eng+(t.eng===THUMP?'/'+thAlgo(t):'');if(destCache[key])return destCache[key];   /* THUMP: the knob names follow the model */
  const i0=tracks.indexOf(t),S={sel:ui.sel,cat:ui.cat,cp:ui.cp.slice(),shift:ui.shift,layer:ui.layer,enc:Object.assign({},ui.enc),toast:ui.toast,touched:ui.touched,acc:ui.ownAcc};
  const keep=JSON.stringify(t),out=[],seen=new Set();holdRender++;
  try{ui.sel=i0;for(const pg of(ENG_PG[t.eng]||[0,0]).map((_,i)=>i))for(const sh of[false,true]){ui.cat=2;ui.cp[2]=CATS[2].pages.findIndex(q=>q.eng===pg&&(!q.only||q.only(t)));if(ui.cp[2]<0)continue;const b=cpage().base;ui.layer=b[0];ui.enc[b[0]]=b[1];ui.shift=sh;
      const K=knobInfos();for(let k=0;k<8;k++){const lab=K[k].lab,sp=kSpec(k);if(!sp||lab==='----')continue;
        const a=trackP(t);ui.ownAcc=0;
        if(sp.own){const o=OWN[sp.own];if(ownStep(o,t))o.setIdx(t,(o.idx(t)+1)%Math.max(1,o.n(t)));else o.set(t,o.get(t)<64?o.get(t)+40:o.get(t)-40);}
        else withCtx(ctxOf(sp),()=>{const kk=sp.src[2],v=encGet(kk);encSet(kk,v<64?v+40:v-40);});
        const z=trackP(t),q=a.findIndex((v,j)=>v!==z[j]);Object.assign(t,JSON.parse(keep));
        if(q<0||seen.has(q)||q===EFS_P.ENGINE||q===EFS_P.VDCLK)continue;seen.add(q);out.push({lab:dn(lab,t),p:q,cat:'ENGINE'});}}}
  finally{Object.assign(t,JSON.parse(keep));ui.sel=S.sel;ui.cat=S.cat;ui.cp=S.cp;ui.shift=S.shift;ui.layer=S.layer;ui.enc=S.enc;ui.toast=S.toast;ui.touched=S.touched;ui.ownAcc=S.acc;holdRender--;}
  out.push({lab:'TUNE',p:1000,cat:'PITCH'},{lab:'CLOCK',p:EFS_P.CDIV,cat:'TRIGGERS'},{lab:'SEND A',p:37,cat:'SEND'},{lab:'SEND B',p:50,cat:'SEND'});   /* CLOCK = the whole track's clock (/8 .. X4); CLK.D left out (Lef 22 nov) */if(t.eng===SAMPLE)out.push({lab:'REC',p:1001,cat:'SAMPLE'});   /* SAMPLE: a new cycle starts a recording */
  return destCache[key]=out;}
/* + the MIX of each FX slot that has one (core EFS_FX1_D 31, EFS_FX2_D 36; Lef 15 nov): follows the slot types, so not cached */
const TY_CYC=[0,1,2,3,4,5,SPRING];   /* FX.1 / FX.2 step through these (never GRAIN or OFF), as the core does */
/* more destinations after the engine knobs (Lef 22 nov), each with its category for the screen; the LFOs last.
   Only values the core reads (VAR.T, DENS and ROTATE are made in the app, so a source cannot move them) */
const DEST_MORE=[['TRIG.P',11,'TRIGGERS'],['VAR.V',53,'TRIGGERS'],['VAR.P',92,'PITCH'],['CHAOS',102,'PERFORM'],['STUT.P',62,'STUTTER'],['STUT.M',91,'STUTTER'],
  ['EQ.L',110,'CHANNEL'],['EQ.M',111,'CHANNEL'],['EQ.H',113,'CHANNEL'],['CHAN.S',117,'CHANNEL'],['CHAN.C',114,'CHANNEL'],['SIDE.A',104,'SIDECHAIN']];   /* OWNER.PARAM (Lef 24 nov) */
const destListAll=t=>{const o=destList(t).slice(),has=new Set(o.map(e=>e.p)),add=e=>{if(!has.has(e.p)){has.add(e.p);o.push(e);}};
  [0,1].forEach(s=>{if(FX[t.slot[s]][1][3]==='MIX'||t.slot[s]===2)add({lab:'FX'+(s+1)+'.M',p:s?36:31,cat:'GRID FX'});});[0,1].forEach(s=>{if(TY_CYC.includes(t.slot[s]))add({lab:'FX'+(s+1)+'.T',p:s?32:27,cat:'GRID FX'});});
  [0,1].forEach(s=>{if(t.slot[s]===FX_OFF)return;FX[t.slot[s]][1].slice(0,3).forEach((n,j)=>{if(n&&n!=='----')add({lab:'FX'+(s+1)+'.'+(j+1),real:n,p:(s?33:28)+j,cat:'GRID FX'});});});   /* the first three knobs of each slot */
  DEST_MORE.forEach(([lab,p,cat])=>add({lab,p,cat}));
  add({lab:'ENV.A',p:64,cat:'MOD'});add({lab:'RNDA.S',p:40,cat:'MOD'});add({lab:'RNDA.A',p:41,cat:'MOD'});add({lab:'RNDB.S',p:44,cat:'MOD'});add({lab:'RNDB.A',p:45,cat:'MOD'});
  [0,1,2].forEach(q=>{const free=q<2?!!(t.lhz&&t.lhz[q]):!!(l3v(t)[3]);   /* a free LFO (Hz) has its speed on another value */
    add({lab:'LFO'+(q+1)+'.S',p:free?[65,66,191][q]:[16,18,188][q],cat:'MOD'});add({lab:'LFO'+(q+1)+'.A',p:[17,19,189][q],cat:'MOD'});});
  return o;};
/* GRID FX header: the page number always shows (Lef 22 nov); long names: GRID goes, then the names get shorter */
function fxHead(t,pos){const T='T'+(ui.sel+1),room=124-tw(pos)-4;if(t.slot[0]===FX_OFF&&t.slot[1]===FX_OFF)return T+' GRID FX (EMPTY)';
  const a=slotNow(t,0),b=slotNow(t,1);let h=`${T} GRID FX 1:${a} 2:${b}`;if(tw(h)<=room)return h;
  for(let n=8;n>=2;n--){h=`${T} FX 1:${a.slice(0,n)} 2:${b.slice(0,n)}`;if(tw(h)<=room)return h;}return h;}
/* the slot type sounding now: a modulated TYPE shows with ~ in front */
function slotNow(t,s){const i=tracks.indexOf(t),f=ui.fxn&&ui.fxn[i]!=null?(s?ui.fxn[i]&63:ui.fxn[i]>>6):t.slot[s];return f!==t.slot[s]&&FX[f]?'~'+FX[f][0]:FX[t.slot[s]][0];}   /* SEND A / B: this track's send amount (core EFS_FB_SEND, EFS_RV_SEND; Lef 15 nov) */
const EFS_P={ENGINE:54,CDIV:15,VDCLK:137};   /* core param numbers the page needs by name */
/* the destination a source has now: 0 = OFF, else 1 + its place in destList */
function destIdx(t,b){let d=t.mdst[b];if(d==null||d<0){d=t.routes.findIndex(r=>r>>b&1);if(d<0)return 0;}const i=destListAll(t).findIndex(e=>e.p===d);return i<0?0:i+1;}
function setDest(t,b,i){const e=i>0?destListAll(t)[i-1]:null;t.routes=t.routes.map(r=>r&~(1<<b));t.mdst[b]=-1;
  if(e){if(e.p<8)t.routes[e.p]|=1<<b;t.mdst[b]=e.p;}}
/* D: turning picks a destination on the screen; standing still on it for 2 s makes it the destination */
function destTurn(t,b,i){clearTimeout(ui.dpT);ui.dp={t:tracks.indexOf(t),b,i};
  ui.dpT=setTimeout(destNow,MOD_DLY);}
/* letting go of the knob picks it at once (Lef 19 nov); a finger on it: after 2 s still */
function destNow(){if(!ui.dp)return;clearTimeout(ui.dpT);const d=ui.dp;ui.dp=null;const u=tracks[d.t];pushUndo();setDest(u,d.b,d.i);const n=Object.keys(MSRC).find(k=>MSRC[k]===d.b);
  toast(`T${d.t+1} ${n} > `+(d.i?destCatLab(destListAll(u)[d.i-1]):'OFF'),1500);render();}
const destShown=(t,b)=>ui.dp&&ui.dp.b===b&&ui.dp.t===tracks.indexOf(t)?ui.dp.i:destIdx(t,b);
const lofV=t=>t.v.lof||[64,64],lofN=v=>v===64?.5:v<64?v/128:.5+(v-64)/126;   /* LFO OFFSET: 64 = none, sent as 0..1 with 0.5 exactly in the middle */
function modOwn(){const o={},sp=(q,n)=>({lab:()=>n+'.S',long:n.replace('LFO','LFO ')+' SPEED: SYNC, SHIFT = FREE IN HZ',
    get:t=>ui.shift||t.lhz[q]?t.v.hz[q]:t.v.mod[q*2],set:(t,v)=>{if(ui.shift){t.v.hz[q]=v;t.lhz[q]=true;}else{t.v.mod[q*2]=v;t.lhz[q]=false;}},
    show:(t,v)=>ui.shift||t.lhz[q]?hzShow(v):rate(v)});
  const amt=(n,g,s,long)=>({lab:()=>n+'.A',long,get:g,set:s,show:(t,v)=>pct(v)});
  const dst=(n,b)=>({lab:()=>n+'.D',long:n+' DESTINATION: TURN, LET GO = PICK (OR 2 S STILL)',n:t=>destListAll(t).length+1,idx:t=>destShown(t,b),
    setIdx:(t,i)=>destTurn(t,b,i),show:t=>{const i=destShown(t,b);return i?destListAll(t)[i-1].lab:'OFF';}});
  [0,1].forEach(q=>{const n='LFO'+(q+1);o[n+'.S']=sp(q,n);
    o[n+'.W']={lab:()=>ui.shift?'PHASE.'+(q+1):n+'.W',long:n+' WAVE, SHIFT: PHASE',n:()=>ui.shift?8:WAVES.length,idx:t=>ui.shift?(t.lph||[0,0])[q]:t.waves[q],   /* SHIFT: PHASE in 45 degree steps (Lef 15 nov) */
      setIdx:(t,i)=>{if(ui.shift){if(!t.lph)t.lph=[0,0];t.lph[q]=i;}else t.waves[q]=i;},show:t=>ui.shift?String((t.lph||[0,0])[q]*45):PIC+'LFO:'+t.waves[q]};
    o[n+'.A']={lab:()=>ui.shift?n+'.O':n+'.A',long:n+' AMOUNT (DEPTH), SHIFT: OFFSET',shOwn:1,   /* SHIFT = OFFSET: the swing moves down / up, middle = around the knob, ends = only below / above it (Lef 19 nov) */
      get:t=>ui.shift?lofV(t)[q]:t.v.mod[q*2+1],set:(t,v)=>{if(ui.shift){if(!t.v.lof)t.v.lof=[64,64];t.v.lof[q]=v;}else t.v.mod[q*2+1]=v;},
      show:(t,v)=>ui.shift?(v===64?'0':(v<64?'-':'+')+Math.round(Math.abs(v-64)/(v<64?64:63)*100)+'%'):pct(v)};
    o[n+'.D']=dst(n,q);});
  [0,1].forEach(r=>{const n='RND'+'AB'[r],j=4+r*2;
    o[n+'.S']={lab:()=>n+'.S',long:'RND '+'AB'[r]+' SPEED (SYNC)',get:t=>t.v.mod[j],set:(t,v)=>t.v.mod[j]=v,show:(t,v)=>rate(v)};
    o[n+'.A']=amt(n,t=>t.v.mod[j+1],(t,v)=>t.v.mod[j+1]=v,'RND '+'AB'[r]+' AMOUNT, SHIFT: SMOOTH');
    o[n+'.SM']={lab:()=>'SMOOTH',long:'RND '+'AB'[r]+' SMOOTH: 0 = STEPPED, RIGHT = GLIDES',get:t=>t.v.rsm[r],set:(t,v)=>t.v.rsm[r]=v,show:(t,v)=>v?pct(v):'STEP'};
    o[n+'.D']=dst(n,3+r);});
  {const n='LFO3',L=l3v;   /* LFO 3: the same knobs and SHIFT jobs as LFO 1 / 2 (Lef 22 nov) */
    o['LFO3.S']={lab:()=>'LFO3.S',long:'LFO 3 SPEED: SYNC, SHIFT = FREE IN HZ',get:t=>ui.shift||L(t)[3]?L(t)[2]:L(t)[0],
      set:(t,v)=>{if(ui.shift){L(t)[2]=v;L(t)[3]=1;}else{L(t)[0]=v;L(t)[3]=0;}},show:(t,v)=>ui.shift||L(t)[3]?hzShow(v):rate(v)};
    o['LFO3.W']={lab:()=>ui.shift?'PHASE.3':'LFO3.W',long:'LFO3 WAVE, SHIFT: PHASE',n:()=>ui.shift?8:WAVES.length,idx:t=>ui.shift?L(t)[5]:L(t)[4],
      setIdx:(t,i)=>{if(ui.shift)L(t)[5]=i;else L(t)[4]=i;},show:t=>ui.shift?String(L(t)[5]*45):PIC+'LFO:'+L(t)[4]};
    o['LFO3.A']={lab:()=>ui.shift?'LFO3.O':'LFO3.A',long:'LFO3 AMOUNT (DEPTH), SHIFT: OFFSET',shOwn:1,get:t=>ui.shift?L(t)[6]:L(t)[1],set:(t,v)=>{if(ui.shift)L(t)[6]=v;else L(t)[1]=v;},
      show:(t,v)=>ui.shift?(v===64?'0':(v<64?'-':'+')+Math.round(Math.abs(v-64)/(v<64?64:63)*100)+'%'):pct(v)};
    o['LFO3.D']=dst(n,5);}
  o['PLOCK.G']={lab:()=>'PLOCK.G',long:'P-LOCK GLIDE: LOCKED KNOBS GLIDE TO THE NEXT STEP\'S VALUE, OVER THE LAST PART OF EACH STEP',get:t=>plkv(t)[0],set:(t,v)=>plkv(t)[0]=v,
    show:(t,v)=>v?Math.round(v/127*100)+'% STEP':'OFF',shAll:1};
  o['PLOCK.H']={lab:()=>'PLOCK.H',long:'P-LOCK HOLD: ON = A LOCK STAYS UNTIL THE NEXT LOCK, OFF = BACK TO THE KNOB ON STEPS WITHOUT A LOCK',n:()=>2,idx:t=>plkv(t)[1]?1:0,
    setIdx:(t,i)=>plkv(t)[1]=i?127:0,show:t=>plkv(t)[1]?'ON':'OFF',shAll:1};
  o['ENV.AT']={lab:()=>'ENV.AT',long:'MOD ENV ATTACK',get:t=>t.env[0],set:(t,v)=>t.env[0]=v,show:(t,v)=>timeShow(decSec(v))};
  o['ENV.DC']={lab:()=>'ENV.DC',long:'MOD ENV DECAY',get:t=>t.env[1],set:(t,v)=>t.env[1]=v,show:(t,v)=>timeShow(decSec(v))};
  o['ENV.A']=amt('ENV',t=>t.v.edp[0],(t,v)=>t.v.edp[0]=v,'MOD ENV AMOUNT (DEPTH)');o['ENV.D']=dst('ENV',2);
  return o;}
Object.assign(OWN,modOwn());
const ownStep=(o,t)=>!!o.n&&o.n(t)>0;
const ownPut=(o,t,u)=>{if(ownStep(o,t)){const n=o.n(t);o.setIdx(t,n>1?Math.round(u/127*(n-1)):0);}else if(o.set)o.set(t,u);};   /* the inverse of ownVal */
const ownVal=(o,t)=>ownStep(o,t)?(o.n(t)>1?Math.round(o.idx(t)/(o.n(t)-1)*127):0):o.get?o.get(t):0;
/* a turn of an own knob: steps move one per notch of about 8, values like any knob; SHIFT = all tracks where allowed */
function ownTurn(nm,k,d){const o=OWN[nm],t=tracks[ui.sel];if(o.lab(t)==='----')return;pushUndo('own'+nm+ui.sel);
  if(ui.slkIn)ui.ownAcc=0;   /* P-LOCK: the whole turn so far is replayed from the step's start value, so nothing may carry over (Lef 22 nov) */
  const list=ui.shift&&!(typeof o.shOwn==='function'?o.shOwn(t):o.shOwn)?tracks.filter(u=>o.lab(u)!=='----'):[t];   /* SHIFT: every track that has this knob (not when SHIFT has its own job) */
  if(ownStep(o,t)){const N=o.n(t),few=N<15&&!ui.slkIn,W=few?Math.max(3,Math.min(8,Math.round(24/N))):8;if(few)d=Math.sign(d);   /* under 15 choices (Lef 26 nov, Core Principle): no speed-up and each choice holds longer, in proportion: 2-3 choices 8 clicks, 4 six, 5 five, 8 three */
    ui.ownAcc=(ui.ownAcc||0)+d;const q=Math.trunc(ui.ownAcc/W);if(ui.slkIn)ui.ownAcc=0;if(!q)return;ui.ownAcc-=q*W;
    const i=Math.max(0,Math.min(o.n(t)-1,o.idx(t)+q));list.forEach(u=>{if(ownStep(o,u))o.setIdx(u,Math.min(i,o.n(u)-1));});}
  else{let dd=d;if(o.fine)dd=d*o.fine;else if(o.slow){ui.ownAcc=(ui.ownAcc||0)+d;dd=Math.trunc(ui.ownAcc/2);ui.ownAcc-=dd*2;if(!dd)return;}   /* slow: half as sensitive */
    const o0=o.get(t);
    if(ui.slkIn){let v=Math.max(0,Math.min(127,o0+dd));   /* P-LOCK replay: across det it holds for 3 clicks, worked out from the whole turn */
      if(o.det!=null&&(o0<=o.det&&v>o.det||o0>=o.det&&v<o.det)){const h=o.fine?3*o.fine:o.slow?2:3,ex=v-o.det;v=Math.abs(ex)<=h?o.det:o.det+ex-Math.sign(ex)*h;}
      list.forEach(u=>o.set(u,v));ui.ownAcc=0;return;}
    if(o.det!=null&&o0===o.det&&(ui.detAcc=(ui.detAcc||0)+1)<4)return;ui.detAcc=0;let v=Math.max(0,Math.min(127,o0+dd));if(o.det!=null&&(o0<o.det&&v>o.det||o0>o.det&&v<o.det))v=o.det;   /* det: a turn across it stops on it, 3 more clicks to leave it (Lef 22 nov: easy to find 100 % / 0 ST) */
    list.forEach(u=>o.set(u,v));}}
/* the names on the device (one word per idea, function first): v106 labels that read differently now */
const RN={'P.ENV':'ENV.P','F.ENV':'ENV.F','F.AMT':'AMT.F','F.ATK':'ATK.F','N.TYPE':'TYPE.N','C.DEC':'DEC.C','C.TONE':'TONE.C','T.DEC':'DEC.T','T.COL':'COL.T',
  'L.WAVE':'WAVE.L','BODY.P':'PITCH.B','ENV.DP':'DEPTH.E','S.TIME':'DEC.P',FEEDBK:'FDBK','L.NOTE':'LIST.N',GLIDE:'PORTA','VAR.R':'VAR.T','RND.V':'VAR.V','SUB.D':'----'};
function rn(l,t){if(!l)return l;const e=t.eng,tex=isTex(t);
  if(l==='SWEEP'&&(e===0||e===THUMP))return'ENV.P';if(l==='SWEEP'&&tex)return'DETUNE';
  if(l==='TIMBRE'&&e===0)return'RATIO';if(l==='TIMBRE'&&tex)return'WARP';
  if(l==='COLOR'&&e===0)return'INDEX';if(l==='COLOR'&&tex)return'MORPH';
  if(l==='DRIVE'&&tex)return'XMOD';if(l==='SPREAD'&&e===HANDS)return'GAP';if(l==='SPREAD'&&e===DUST)return'METAL';
  return RN[l]||l;}
/* the name on the screen (Lef 24 nov): OWNER.PARAM, the owner first; a whole word where the header already names the owner.
   Only the shown name: inside, the old names stay the keys (LONG, KDESC, own knobs), so nothing else moves */
const DN={'ENV.P':'P.ENV','DEC.P':'P.DEC','ATK.F':'F.ATK','AMT.F':'F.AMT','TIME.S':'SLD.T','AMT.A':'ACC.A','TYPE.N':'N.TYPE','DEC.N':'N.DEC',
  'DEC.M':'M.DEC','TYPE.F':'F.TYPE','PITCH.B':'B.PIT','DEC.T':'T.DEC','COL.T':'T.COL','DEC.C':'C.DEC','TONE.C':'C.TONE',
  'DEC.B':'B.DEC','TUNE.R':'R.TUNE','DEC.R':'R.DEC','MIX.R':'R.MIX','TYPE.W':'W.TYPE','RESO.W':'W.RESO','DEC.W':'W.DEC','MIX.W':'W.MIX',
  'TBL.A':'A.TBL','POS.A':'A.POS','TBL.B':'B.TBL','POS.B':'B.POS','TUNE.B':'B.TUNE','MIX.B':'B.MIX','FB.A':'A.FB','POS.M':'A.SCAN','FB.B':'B.FB','FINE.B':'B.FINE','TUNE.A':'A.TUNE',
  'SYNC.A':'A.SYNC','BEND.A':'A.BEND','FORM.A':'A.FORM','FOLD.A':'A.FOLD','ASYM.A':'A.ASYM','SYNC.B':'B.SYNC','BEND.B':'B.BEND','FORM.B':'B.FORM','FOLD.B':'B.FOLD','ASYM.B':'B.ASYM',
  'TUNE.O':'O.TUNE','FINE.O':'O.FINE','TYPE.S':'S.TYPE','AMT.S':'AMOUNT','FILT.S':'FILTER','SRC.S':'SOURCE','PLOCK.G':'GLIDE','PLOCK.H':'HOLD',
  'LFO.S':'SPEED','LFO.D':'DEST','PHASE.1':'LFO1.P','PHASE.2':'LFO2.P','PHASE.3':'LFO3.P','LEN.R':'ROLL.L','DENS.R':'ROLL.D','SCL.M':'MAIN.S','ROOT.M':'MAIN.R'};
const dn=(l,t=tracks[ui.sel])=>l==='ENV.F'?(t&&(t.eng===ACID||t.eng===TANK)?'F.ENV':'F.DEC'):DN[l]||l;   /* ENV.F: ACID, TANK the envelope amount, the synths its decay */
const rnd2=(l,t)=>dn(rn(l,t),t);   /* v106 label > the name on the screen */
let seed=(Date.now()&0x7fffffff)||1234567; /* a different start every time */const rnd=()=>{seed=(seed*1103515245+12345)&0x7fffffff;return seed/0x7fffffff;};
/* the euclidean generator runs in the C core; the JS line is the same formula, used only until the core has loaded */
function euclid(k,n,rot){
  const a=[];for(let i=0;i<n;i++)a.push(((i+rot)*k)%n<k);return a;}
/* default kit: macro values per track (PITCH DECAY COLOR TIMBRE SWEEP DRIVE NOISE LEVEL) and noise colour;
   COLOR moves to Shift + FILTER (t.v.col), knob 3 starts as FILTER open (64) */
/* DECAY and ATTACK knobs: time = 4 s x value squared (0 = off). decN / attN turn a value of the old exponential knob
   (5 ms..4 s, 1 ms..4 s) into the new one, so stored sounds keep their length; an old drone (124+) stays a drone (127) */
const decN=(v,drone)=>drone&&v>=124?127:Math.min(127,Math.round(127*Math.sqrt(0.005*Math.pow(2,v/127*9.6439)/4)));
const attN=v=>Math.min(127,Math.round(127*Math.sqrt(0.001*Math.pow(2,Math.pow(v/127,2)*12)/4)));
const decSec=v=>4*Math.pow(v/127,2);
const handsTail=v=>0.02+2*Math.pow(v/127,2),handsN=v=>1+Math.floor(Math.pow(v/127,2)*39),toneShow=v=>{const f=400*Math.pow(2,v/127*3.3);return f<1000?String(Math.round(f)):(f/1000).toFixed(1)+'K';};
const thLenS=v=>{const x=v/127;return x<=.8?.05*Math.pow(30,x):.75974*Math.pow(2/.75974,(x-.8)*5);};   /* THUMP: the length the Omega models get, 50 ms .. 2 s */
const DEC_LONG=new Set([1,2,3,4,6,7,10,11,12,17]),decSecT=(t,v)=>DEC_LONG.has(t.eng)?8*Math.pow(v/127,3):decSec(v);   /* the synths: 8 s x knob cubed, the middle stays 1 s (Lef 25 nov; core efs_voice) */
const decShow=(t,v,cell)=>t.eng===HANDS?timeShow(handsTail(v)):t.eng===THUMP?timeShow(thLenS(v)):t.eng===0?timeShow(decSec(v)/2):v>=127&&t.eng!==0&&t.eng!==ACID&&t.eng!==SNARE?(cell?'DRONE':'DRONE MODE'):timeShow(decSecT(t,v));
const timeShow=s=>s<=0?'OFF':s<1?Math.round(s*1000)+'MS':s.toFixed(1)+'S';
const stShow=v=>v?timeShow(0.005+Math.pow(v/127,2)*0.395):'AUTO';
/* CURVE is named after the attack: LOG = slow start (the decay falls exponentially), EXP = snappy (the decay holds, then falls) */
const curveShow=v=>v<6?'LOG':v>=58&&v<=70?'LIN':v>121?'EXP':num(v);
const famtShow=v=>Math.abs(v-64)<=1?'0':(v>64?'+':'-')+Math.round(Math.abs(v-64)/63*100);
/* a knob that picks a waveform shows it as a small picture on the screen: its value text is PIC + the shape (and the knob value for a morph) */
const PIC='\u0001',WAVE_PICS=new Set(['SINE','FOLD','TRI','SAW','SQUARE','DIGI']);
const sharkName=v=>{const w=v/127*3,n=['SAW','SHARK','SQUARE','PULSE'],i=Math.round(w);return Math.abs(w-i)<.08?n[i]:n[Math.floor(w)]+' > '+n[Math.min(3,Math.floor(w)+1)];};
const acidName=v=>v<2?'SAW':v>125?'SQUARE':'SAW < '+pct(v)+' > SQUARE';
/* the words for a picture value (bottom line, mouse-over) */
const plain=s=>{if(typeof s!=='string'||s[0]!==PIC)return s;const[n,v]=s.slice(1).split(':');return n==='SHK'?sharkName(+v):n==='ACD'?acidName(+v):n==='LFO'?WAVES[+v]:n;};
const isTex=t=>t.eng>=1&&t.eng<=4,isFm=t=>t.eng<=4,hasCurve=t=>t.eng!==ACID&&t.eng!==HANDS&&!X3(t)&&!isSyn(t),hasTune=t=>t.eng!==ACID&&t.eng!==CHORD&&t.eng!==HANDS;
/* TUNE (Shift + PITCH, RANGE off): FREE = stepless, SEMI = on semitones; RANGE 0 is free, except synths while the MAIN key is on (keySnap) */
const TUNES=['FREE','SEMI'];
function tuneP(t){const p=t.v.macros[0]/127,m=fromV(t.v.tn[0],2);if(!m||!hasTune(t))return p;
  let c=1200*Math.log2(20*Math.pow(2,p*8)/32.7032);   /* cents above C1 */
  c=Math.round(c/100)*100;
  return Math.max(0,Math.min(1,Math.log2(32.7032*Math.pow(2,c/1200)/20)/8));}
/* MAIN key on, RANGE OFF: a synth track's one pitch snaps to the nearest note of the key; drums and noise stay free (Lef 15 nov) */
const keySnap=t=>mainOn()&&!pMel(t)&&(isTex(t)||[ACID,CHORD,SHARK,HIVE,NEBULA].includes(t.eng));
function snapP(t){const p=tuneP(t),c=1200*Math.log2(20*Math.pow(2,p*8)/32.7032),sc=SCALES[scaleOf(t)],per=sc[3]||1200,degs=sc[2]||CH,r=rootOf(t)*100;
  let best=c,bd=1e9;for(let o=Math.floor((c-r)/per)-1;o<=Math.floor((c-r)/per)+1;o++)for(const d of degs){const x=r+o*per+d,e=Math.abs(x-c);if(e<bd){bd=e;best=x;}}
  return Math.max(0,Math.min(1,Math.log2(32.7032*Math.pow(2,best/1200)/20)/8));}
const KIT=[[30,60,20,0,90,30,0,110],[62,45,40,50,40,25,80,95],[105,20,100,90,0,10,50,80],[50,55,50,40,60,20,10,95],
  [85,70,90,75,10,15,0,75],[60,100,30,30,0,20,127,90],[70,35,30,60,20,40,100,85],[95,30,70,20,127,50,0,75]];
const KIT_NOISE=[0,0,0,0,0,3,1,0];
KIT.forEach(k=>k[1]=decN(k[1]));
/* a track as it starts: INIT puts every track back to this (Lef 13 nov) */
const freshTrack=i=>({
  eng:0,l128:1,rv:2,dv:2,pv:2,gr:2,tv:2,syn:2,nb:2,th:3,lf:2,fv:2,len:16,gen:0,dens:0,rot:0,roln:4,rold:8,steps:[],mute:false,oto:null,
  slot:[FX_OFF,FX_OFF],routes:Array(8).fill(0),mdst:[-1,-1,-1,-1,-1,-1],lhz:[false,false],lph:[0,0],modOff:Array(8).fill(false),waves:[0,0],rloop:[false,false],rlen:[16,16],rsmooth:[false,true],env:[0,0],
  noise:KIT_NOISE[i],black:[64,64,64,40],
  v:{macros:KIT[i].map((v,k)=>k===2?64:v),col:[KIT[i][2]],pat:[0,0,0,127,64,0,15,64],
     mod:[40,0,20,0,104,0,64,0],pitch:[0,toV(3,SCALES.length),0,0,15,0,0,64],fx:[127,0,0,0,0,0,0,0],
     sA:[0,0,0,0,0,0,0,0],sB:[0,0,0,0,0,0,0,0],sp:[44,44],att:[0],lis:[0],lch:[127],lm:[0],pan:[64],sc:SC0(),eq:[64,64],stu:STU0.slice(),sauto:[0],sl:[0],ac:[0],edp:[64],hz:[0,0],gx:GX0(),gate:[64],cv:[48],cc:[48],chp:[48],crv:[0],pe:[0],fo:[0],st:[0],fa:[0],pw:[0],tn:[toV(1,3)],fol:[0],hrm:[toV(1,HARMS.length)],rtu:[0],vp:[0],vd:[64],tu:[0],tat:[0],gdr:[0],nf:[64],cha:[0],chs:[0],rsm:[0,76],key:KEY0(),shc:[0],cs:CS0(),sm:SM0()},
  slR:[...Array(128)].map(()=>Math.random()),acR:[...Array(128)].map(()=>Math.random())});
const tracks=[...Array(8)].map((_,i)=>freshTrack(i));
tracks.forEach(t=>{t.steps=gen(t);t.v.pat[4]=Math.round(t.dens/7*127);t.v.pat[5]=0;t.v.pat[6]=lenV(t.len);
  t.pdeg=Array(128).fill(0);t.pcent=Array(128).fill(0);});
/* roles of the kit: [engines to pick from (the first is the default), then per macro [min,max]: PITCH DECAY COLOR (Shift + FILTER) TIMBRE SWEEP DRIVE NOISE LEVEL, attack, noise colours]
   1 kick, 2 snare, 3 hihat, 4 clap (HANDS), 5 bass (SHARK), 6 second bass (ACID), 7 chords (J60), 8 pad (SWARM) */
const ROLES=[
  [[THUMP,0],[[16,28],[55,75],[5,30],[0,20],[70,110],[15,50],[0,8],[97,102]],[0,0],[0]],
  [[SNARE,0],[[45,62],[40,60],[25,60],[30,70],[25,55],[15,40],[60,100],[81,87]],[0,0],[0,1]],
  [[0],[[100,120],[10,35],[80,120],[70,110],[0,15],[0,25],[30,80],[69,74]],[0,0],[0]],
  [[9,0,6],[[60,80],[25,40],[40,60],[30,50],[20,40],[0,20],[20,40],[84,92]],[0,0],[0,1,3]],
  [[SHARK],[[20,32],[55,80],[10,50],[0,40],[0,30],[20,60],[0,0],[88,94]],[0,0],[0]],
  [[5,0,1,3],[[20,32],[55,80],[10,50],[0,40],[0,30],[20,60],[0,0],[83,88]],[0,15],[0]],
  [[7],[[50,70],[85,105],[60,90],[20,40],[40,60],[30,50],[0,0],[74,80]],[5,20],[0]],
  [[HIVE,4,1,2],[[40,60],[60,90],[20,90],[0,60],[20,70],[0,20],[0,12],[69,74]],[100,124],[2]]];
ROLES.forEach(r=>{r[1][1]=r[1][1].map(v=>decN(v));r[2]=r[2].map(attN);});
const rint=(a,b)=>a+Math.floor(rnd()*(b-a+1));
const pick=a=>a[Math.floor(rnd()*a.length)];
/* a fresh sound for track i within its role (engine, macros, attack, noise colour) */
/* FILTER per role: kick and bass stay open; a noisy sound often gets a high-pass (long noise sweeps), sometimes a low-pass;
   the rest now and then a light touch. 64 = open */
function filterFor(i,noise){if(i===0||i===4)return 64;const r=rnd();
  if(noise>=60)return r<.45?rint(80,112):r<.65?rint(25,50):64;
  return r<.15?(i===2?rint(70,90):rint(40,56)):64;}
/* macros of a role (random or the middle); knob 3 from the role table is COLOR, the knob itself gets a FILTER value */
function roleMacros(i,mid){const m=ROLES[i][1].map(([a,b])=>mid?Math.round((a+b)/2):rint(a,b)),col=m[2];m[2]=mid?64:filterFor(i,m[6]);return[m,col];}
/* an ACID sound: cutoff low to mid, resonance up, env mod, sometimes the RAT; slides and accents on some steps */
function acidSound(t){const m=t.v.macros;m[1]=rint(20,80);m[2]=rint(15,70);t.v.pw=[rnd()<.5?rint(0,30):rint(90,127)];t.v.col=[rint(40,110)];m[4]=m[1];
  m[5]=rnd()<.4?rint(30,90):0;m[6]=0;m[3]=rint(60,112);t.v.sl=[rint(15,40)];t.v.ac=[rint(15,45)];}
/* the engines with their own knob meanings get their own random sound on top of the role */
function engRnd(t){if(t.eng===ACID)acidSound(t);else if(t.eng===SHARK)sharkSound(t,true);else if(t.eng===CHORD)chordSound(t,true);else if(t.eng===HIVE)hiveSound(t,true);else if(t.eng===NEBULA)nebSound(t,true);else if(t.eng===THUMP)thumpSound(t,true);else if(t.eng===SOPHIE)sophieSound(t,true);else if(t.eng===SNARE)snareSound(t,true);else if(t.eng===SAMPLE)smv(t)[4]=rint(0,127);else if(wtE(t))wtSound(t,true);else if(t.eng===TANK)tkSound(t,true);else if(t.eng===SID)sidSound(t,true);}   /* SAMPLE: RND.S picks another slice (INDEX), nothing else of the sample (Lef 18 nov) */
function roleSound(i){const t=tracks[i],[engs,mac,att,cols]=ROLES[i];t.eng=engs[0];   /* the start-up kit = the INIT kit (Lef 19 nov) */
  const[m,c]=roleMacros(i);t.v.macros=m;t.v.col=[c];if(!isSyn(t))t.v.att=[rint(att[0],att[1])];engRnd(t);t.noise=pick(cols);if(t.home)t.home=t.v.macros.slice();}
/* tracks 5-8 get a melody (RANGE open, MODE B: the lane moves on each hit); 8 runs at clock /2 */
function roleMelody(i){if(i<4)return;const t=tracks[i];
  t.v.pitch[2]=rangeV(i<=5?rint(4,8):i===6?rint(7,14):rint(5,10));t.v.pitch[3]=127;t.v.pitch[4]=lenV(rint(i===7?4:8,16));
  t.v.pitch[5]=0;t.v.pitch[6]=i===7?rint(20,50):0;pitchGen(t);
  if(i===7)t.v.pat[7]=toV(3,8);}
/* start-up: every track its role sound, one random master scale and root for all tracks, no triggers */
tracks.forEach((_,i)=>{roleSound(i);roleMelody(i);if(tracks[i].eng===SNARE)snareSound(tracks[i]);});   /* the SNARE starts as the pure 808, as after INIT (Lef 19 nov) */
glob[0]=toV(1+pick([3,4,5,6,7,9,10,13,14,15,22,26]),SCALES.length+1);glob[1]=toV(rint(0,11),12);tracks.forEach(t=>t.v.key=KEY0());
/* the three RANDOM buttons (GLOBAL page): sound, rhythm, rhythm lengths 16-64; each for all tracks, one undo */
/* RANDOM / DEFAULT: `only` = the one track to act on (tap), null = all tracks (SHIFT) */
let only=null;const each=f=>tracks.forEach((t,i)=>{if(only==null||only===i)f(t,i);});
/* a new random sound in the track's role, but the engine stays (change it in MENU > ENGINE) */
/* Core Principle (Lef 15 nov): a random or mutated sound never touches the VCA envelope (ATTACK, DECAY, CURVE, THUMP ATTACK)
   nor LEVEL, PAN, PITCH, PROB or the pattern (ACID SLIDE / ACCENT); every track, also with SHIFT */
const VCA_KEEP=['att','crv','tat','pan','sl','ac','pat'];
function vcaKeep(t){return{p:t.v.macros[0],d:t.v.macros[1],l:t.v.macros[7],o:VCA_KEEP.map(k=>t.v[k]&&t.v[k].slice()),pm:PITCH_M(t).map(k=>[k,t.v.macros[k]])};}
function vcaBack(t,k){t.v.macros[0]=k.p;t.v.macros[1]=k.d;t.v.macros[7]=k.l;if(k.pm&&PITCH_M(t).join()===k.pm.map(x=>x[0]).join())k.pm.forEach(([i,v])=>t.v.macros[i]=v);VCA_KEEP.forEach((n,j)=>{if(k.o[j])t.v[n]=k.o[j];});}
function keepEngSound(i){const t=tracks[i],e=t.eng,src=t.v.macros[6],kp=vcaKeep(t);roleSound(i);
  if(t.eng!==e){t.eng=e;newSound(i,false);}if(e===NEBULA)t.v.macros[6]=src;vcaBack(t,kp);if(t.home)t.home=t.v.macros.slice();}
function rndSound(){each((_,i)=>keepEngSound(i));}
/* new melodies on the tracks that have one (RANGE > 0); with none, tracks 6-8 get their role melody */
function rndMelody(){if(only!=null){const t=tracks[only];if(!pRange(t)){if(only>=4)roleMelody(only);else{t.v.pitch[2]=rangeV(7);pitchGen(t);}return;}}
  const mel=tracks.filter((t,i)=>pRange(t)>0&&(only==null||only===i));
  if(!mel.length){[4,5,6,7].forEach(roleMelody);return;}
  mel.forEach(t=>{t.pkey=String(pRange(t));pitchGen(t);});}
/* the safe range of each slot type's knobs: a new effect starts from the middle */
const FX_RANGE=[[[30,110],[0,90],[0,127],[60,127]],[[10,90],[0,60],[20,110],[50,110]],[[64,64],[40,110],[30,110],[0,0]],
  [[0,127],[0,127],[0,0],[30,90]],[[20,110],[0,80],[0,127],[30,90]],[[0,127],[0,70],[0,127],[20,70]],[[40,110],[90,127],[32,32],[30,80]],[[0,0],[0,0],[0,0],[0,0]],[[30,100],[40,100],[30,100],[30,80]],
  [[0,64],[112,112],[0,0],[127,127]],[[20,60],[0,0],[127,127],[127,127]],[[64,64],[40,90],[0,0],[127,127]],[[64,64],[0,0],[64,64],[127,127]],
  [[10,30],[0,0],[64,64],[127,127]],[[64,64],[64,64],[64,64],[127,127]],[[30,30],[32,32],[127,127],[127,127]],[[25,25],[25,25],[0,0],[127,127]],
  [[40,40],[80,80],[50,50],[127,127]],[[40,40],[80,80],[90,90],[127,127]],[[80,80],[50,50],[50,50],[0,0]],[[50,50],[70,70],[100,100],[100,100]],
  [[30,30],[64,64],[14,14],[100,100]],[[70,70],[64,64],[90,90],[100,100]],[[30,30],[70,70],[90,90],[64,64]],[[56,56],[55,55],[64,64],[45,45]]];   /* NEBULA: GRANULAR, half wet */   /* ECHO: 1/8, some repeats, FILTER open */   /* TANK: some drive, the middle, an octave, mostly wet; OTT: the classic, a little dry left */
/* PERF rows 3 (MUTATE) and 4 (DEFAULT): the same six, each in its own colour (red sound, yellow triggers, green pitch, blue length, purple fx, orange prob, teal chaos); pad 8 on row 4 = ALL (white) */
const DEF_COL=['var(--track-1)','var(--track-3)','var(--track-4)','var(--track-6)','var(--track-7)','var(--track-2)','var(--track-5)','var(--lit)'];
const DEF_RHY=['x...x...x...x...','....x.......x...','x.x.x.x.x.x.x.x.','............x...','...x......x.....','x.....x...x.....','......x.......x.','x...............'];
const SEND_START=[[0,toV(2,14),70,70,64,32,0,76,64],[0,toV(6,14),86,51,76,102,0,76,64]];   /* A = PLATE, B = DELAY */
function defRhythm(){each((t,i)=>{const p=DEF_RHY[i];t.gen=4;t.rot=0;t.altT=0;t.fillT=0;t.steps=[...Array(128)].map((_,s)=>p[s%16]==='x');
  t.dens=Math.round((p.split('x').length-1)/16*7);t.v.pat[4]=Math.round(t.dens/7*127);});}
function defLength(){each(t=>{t.len=16;t.v.pat[6]=lenV(16);if(t.gen<4||t.grv!=null)t.steps=gen(t);});ui.stepPage=0;}
/* default melody: tracks 1-4 none (RANGE 0), tracks 5-8 RANGE 8 with a fresh melody */
function defMelody(){each((t,i)=>{if(i>=4){t.v.pitch[2]=rangeV(8);t.pkey='8';pitchGen(t);}else{t.v.pitch[2]=0;t.pkey=null;}});}
/* the default sound of an engine on top of its role: HANDS a clap, ACID a low, round bass line, J60 its chords */
function defEng(t){const m=t.v.macros;if(t.eng===HANDS)handsSound(t);else if(t.eng===CHORD)chordSound(t);
  else if(t.eng===ACID){m[0]=toV(1,P_OCTS);m[1]=40;m[2]=30;m[3]=70;m[4]=40;m[5]=0;m[6]=0;t.v.col=[55];t.v.pw=[0];}
  else if(t.eng===SHARK){sharkSound(t);m[0]=toV(1,P_OCTS);}else if(t.eng===SOPHIE)sophieSound(t);else if(t.eng===SNARE)snareSound(t);else if(t.eng===THUMP)thumpSound(t);else if(t.eng===HIVE)hiveSound(t);}   /* INIT kit (Lef 19 nov): THUMP SNARE FM-PERC HANDS SHARK ACID J60 HIVE */
/* track 8 by default: a slow, dark, detuned SWARM pad with a long swell and a glide */
function padSound(t){const m=t.v.macros;m[1]=110;m[2]=44;m[3]=40;m[4]=70;m[5]=45;m[6]=8;m[7]=80;t.v.col=[85];t.v.att=[75];t.v.crv=[64];t.noise=1;}
function defSound(){each((t,i)=>{const[engs,mac,att,cols]=ROLES[i];t.eng=engs[0];const[m,c]=roleMacros(i,true);if(i===2)m[6]=127;t.v.macros=m;t.v.col=[c];t.v.sl=[0];t.v.ac=[0];t.v.crv=[0];t.v.fa=[0];t.v.pw=[0];t.v.tat=[0];t.v.gdr=[0];t.v.nf=[64];t.v.cha=[0];  /* track 3, the hi-hat: NOISE fully open */
  t.v.att=[Math.round((att[0]+att[1])/2)];t.noise=cols[0];if(i===2){m[1]=ROLES[2][1][1][0];t.v.vd=[100];}defEng(t);   /* hi-hat (Lef 26 nov): DECAY short, VAR.D open to the right, now and then an open hat */if(i===7&&t.eng===4)padSound(t);if(t.home)t.home=t.v.macros.slice();});}
function defFx(){each((t,i)=>{t.slot=[FX_OFF,FX_OFF];t.v.fx=[127,0,0,0,0,0,0,0];t.v.gx=GX0();t.v.eq=t.slot.map(y=>y===2?0:64);t.v.sA[0]=0;t.v.sB[0]=0;});
  if(only==null)SEND_START.forEach((a,k)=>a.forEach((v,j)=>sendShared[k][j]=v));}
/* row 4: DEFAULT, except pad 4 = a fully random LENGTH 4..64 (odd lengths on purpose), pad 8 = ALL: pads 1-7 back to default, LENGTH 16 (Lef 13 nov) */
function rndLength(){each(t=>{setLen(t,rint(4,128));t.v.pat[6]=lenV(t.len);});ui.stepPage=0;}
function defAll(){[defSound,defRhythm,defMelody,defLength,defFx,defChance,defChaos].forEach(f=>f());}
const DEF_BTN=[['SOUND',defSound],['TRIGGERS',defRhythm],['PITCH',defMelody],['LENGTH',rndLength,'RANDOM LENGTH 4-128'],['FX',defFx],['PROB',defChance],['CHAOS',defChaos],['ALL',defAll]];
/* MUTATE (= randomize) per category, in the DEFAULT order: SOUND = every engine knob (the engine stays), TRIGGERS = a new pattern of the track's ALGO,
   PITCH = a new melody, LENGTH = a new track length 4 8 12 16 24 32 48 64, FX = two new slot effects (no GRAIN: CPU), PROB = a new PROB 10..100 % */
function mutRhythm(){each(t=>{t.dens=rint(1,6);t.v.pat[4]=Math.round(t.dens/7*127);if(t.gen===0)t.rot=rint(0,Math.max(0,t.len-1));if(t.gen===4)t.grv=rint(0,GROOVES.length-1);if(t.gen===6)t.roln=rint(2,6);t.steps=gen(t);});}
const MUT_LENS=[4,8,12,16,24,32,48,64,96,128];   /* musical lengths only (Lef 13 nov) */
function mutLength(){each(t=>{setLen(t,MUT_LENS[rint(0,MUT_LENS.length-1)]);t.v.pat[6]=lenV(t.len);});ui.stepPage=0;}
function mutFx(){const types=[0,1,2,3,4,5,SPRING];each(t=>{for(let r=0;r<2;r++){const c=types[rint(0,types.length-1)];t.slot[r]=c;FX_RANGE[c].forEach(([lo,hi],j)=>t.v.fx[r*4+j]=rint(lo,hi));t.v.gx[r*2]=64;t.v.gx[r*2+1]=0;t.v.gx[4+r*2]=0;t.v.gx[5+r*2]=0;t.v.eq[r]=c===2?0:64;}});}
/* ALL RANDOM (Lef 24 nov): SHIFT + PERFORM row 4 pad 8, every track, everything new; lengths only 4 8 16 32 64.
   The one place where random also moves ATTACK, DECAY, CURVE, LEVEL, PAN and PITCH (Lef: "helemaal crazy"); the engines stay */
function allRandom(){only=null;
  tracks.forEach(t=>{setLen(t,pick([4,8,16,32,64,128]));t.gen=pick(ALGOS.filter(g=>g!==8));});ui.stepPage=0;
  mutRhythm();rndMelody();rndSound();rndPitch();mutFx();mutChance();mutChaos();
  tracks.forEach(t=>{t.v.macros[1]=rint(8,118);t.v.macros[7]=rint(55,120);t.v.att=[rint(0,70)];t.v.crv=[rint(0,127)];t.v.pan=[rint(16,112)];if(t.home)t.home=t.v.macros.slice();});}
function mutChaos(){each(t=>t.v.chs[0]=rint(0,127));}
function defChaos(){each(t=>t.v.chs[0]=0);}
function mutChance(){each(t=>t.v.pat[3]=rint(13,127));}   /* 10..100 % (Lef 13 nov) */
const MUT_BTN=[['SOUND',rndSound],['TRIGGERS',mutRhythm],['PITCH',rndMelody],['LENGTH',mutLength],['FX',mutFx],['PROB',mutChance],['CHAOS',mutChaos]];
function defGlitch(){if(only==null)STU0.forEach((x,k)=>stutShared[k]=x);each(t=>{t.v.stu=STU0.slice();t.v.sauto[0]=0;t.stuP=0;});}
/* RANDOM PROB: each press steps the depth 5 15 25 50 75 %; every track draws its own PROB within it (no role preference) */
function defChance(){each(t=>t.v.pat[3]=127);}
const perf=[0,64,64,0,0,0,0,127];
/* FEEDBACK page: SEND is per track, the loop itself (AMOUNT..RETURN) is shared by all tracks */
/* REVERB page: SEND is per track, SIZE..RETURN are shared (one plate for all tracks) */
let volume=100,bpm=120.0;
const ui={layer:'track',enc:{track:1,param:0,perf:0,fx:0,glob:0},cat:0,cp:[0,0,0,0],sel:0,param:0,shift:false,playing:false,pos:0,stepPage:0,
  tpos:Array(8).fill(-1),ppos:Array(8).fill(-1),heldStep:null,held:null,modSrc:0,loops:Array(8).fill(0),muteHeld:false,muteUsed:false,altOn:Array(8).fill(false),fillOn:Array(8).fill(false),soloT:-1,muteQueue:new Set(),muteMode:false,
  touched:null,toast:null,toastT:0,stutter:new Set(),repeat:null,snaps:Array(16).fill(null),undos:[],redos:[],rec:false,recLast:null,undoTag:null,undoT:0,mi:0,pi:0,pa:0,confirm:null,pending:null,loop:null,last:null,cap:0,hit:Array(8).fill(0),hitT:0};
const PV_HOLD=400;   /* TURING+/- held this long: it writes on every step */
const HIT_MS=25,HIT_GAP=15; /* row 1 lights this long when its track plays a hit (Lef 24 nov: shorter); a hit while still lit goes dark HIT_GAP ms first, so every hit shows */
function hitMark(i,now){if(now-ui.hit[i]<HIT_MS&&now>=ui.hit[i]){ui.hit[i]=now+HIT_GAP;clearTimeout(ui.gapT);ui.gapT=setTimeout(()=>{ui.ledNow=1;render();},HIT_GAP);}else if(!(ui.hit[i]>now))ui.hit[i]=now;ui.ledNow=1;}
function hitOff(){clearTimeout(ui.hitT);ui.hitT=setTimeout(()=>{ui.ledNow=1;render();},HIT_MS+HIT_GAP+5);}
const hitLit=c=>{const d=performance.now()-ui.hit[c];return d>=0&&d<HIT_MS;};
const page=()=>LAYERS[ui.layer].pages[ui.enc[ui.layer]];
function gen(t){const n=t.len;t.span=t.unit=n;const a=Array(128).fill(false);let b;
  /* density 0..7: pad 1 = empty pattern, pad 8 = every step */
  if(t.gen===0)b=euclid(Math.round(t.dens/7*n),n,(n-t.rot%n)%n);   /* ROTATE up = the pattern moves right */
  else if(t.gen===2){let r=Math.floor(rnd()*65535);b=[...Array(n)].map((_,i)=>((r>>(i%16))&1)===1&&rnd()<t.dens/5);}
  else if(t.gen===8)b=Array(n).fill(false);   /* OTOMAT: the field plays, not the steps */
  else b=t.gen===6?roll(t,n):groove(t,n);
  if(t.gen!==0&&t.rot%n){const r=t.rot%n;b=b.map((_,i)=>b[((i-r)%n+n)%n]);}   /* ROTATE stays when DENS, GROOVE or LEN.R makes the pattern again */
  b.forEach((v,i)=>a[i]=v);return a;}
/* generator pads remember their pattern per track: back to a generator brings its pattern back
   (while density, rotate and length are the same); pressing the active generator again makes a new one */
function pickGen(t,c){if(!t.gmem)t.gmem={};const key=t.dens+'/'+t.rot+'/'+t.grv+'/'+t.len+'/'+rlenOf(t);
  t.gmem[t.gen]={key,steps:t.steps.slice()};
  if(c===t.gen){t.steps=gen(t);return;}
  t.gen=c;const m=t.gmem[c];if(m&&m.key===key)t.steps=m.steps.slice();else t.steps=gen(t);}
/* a new length keeps the pattern: shorter hides steps (back longer brings them back), longer repeats the pattern into empty steps */
function setLen(t,n){const sp=Math.max(t.span||0,t.len),u=Math.min(t.unit||sp,sp);for(let i=sp;i<n;i++)t.steps[i]=t.steps[i%u];t.unit=u;t.span=Math.max(sp,n);t.len=n;t.v.pat[6]=lenV(n);}  /* span: how far the pattern was ever written; unit: the part that repeats */
/* the LENGTH knob always sits on the real length, so turning it counts on from there (Lef 17 nov) */
function lenV(n){return Math.max(0,Math.min(127,n-1));}   /* LENGTH and PITCH LENGTH: the knob value is the length - 1 (1..128, Lef 25 nov) */
/* LENGTH stops (Lef 22 nov): on 4 8 16 32 64 the knob holds for 3 more clicks, so they are easy to find */
const LEN_STOPS=[4,8,16,32,64,128];
/* LENGTH, TRIGGERS and PITCH the same (Lef 24 nov): a slow click = 1 step, a fast turn = as many steps as the knob sends;
   it stops on 4 8 16 32 64 for 5 clicks (a fast turn never jumps over them) and, turned slowly, on 3 6 12 24 48 for 2 clicks */
const LEN_LIGHT=[3,6,12,24,48,96];
function lenMove(L0,d){const s=Math.sign(d);let L=Math.max(1,Math.min(MAXS,L0+d));
  const S=LEN_STOPS.find(n=>s>0?n>L0&&n<L:n<L0&&n>L);if(S!=null&&s<0){const T=LEN_STOPS.filter(n=>n<L0&&n>L);L=T[T.length-1];}else if(S!=null)L=S;return L;}
function lenStep(L0,d){if(!d)return L0;const hold=LEN_STOPS.includes(L0)?5:LEN_LIGHT.includes(L0)&&Math.abs(d)===1?2:0;
  if(hold&&ui.lenAt===L0){if((ui.lenAcc=(ui.lenAcc||0)+1)<=hold)return L0;}else if(hold){ui.lenAt=L0;ui.lenAcc=1;return L0;}
  if(Math.abs(d)===1){ui.lenHalf=ui.lenDir===d?(ui.lenHalf||0)+1:1;ui.lenDir=d;if(ui.lenHalf<2)return L0;ui.lenHalf=0;}else ui.lenHalf=0;   /* slow: 2 clicks per step, so every length is easy to land on (Lef 25 nov) */
  const L=lenMove(L0,d);ui.lenAt=null;ui.lenAcc=0;return L;}
function lenHold(L0,L1){return false;}   /* replaced by lenStep */
/* VAR.R: a variation of the drawn steps for this loop only (t.vst), made fresh from the drawn steps each loop */
function varySteps(i){const t=tracks[i],v=t.v.pat[0]/127;if(v<=0){t.vst=null;return;}const a=t.steps.slice();
  /* only the hits there are move one step or drop out, never a new hit: DENS 0 stays silent */
  const hits=a.map((x,s)=>x&&s<t.len?s:-1).filter(s=>s>=0),n=Math.min(hits.length,Math.max(1,Math.round(v*v*hits.length*.5)));
  for(let k=0;k<n;k++){const s=hits.splice(Math.floor(rnd()*hits.length),1)[0];a[s]=false;
    if(rnd()<.6){const q=(s+(rnd()<.5?-1:1)+t.len)%t.len;if(!a[q]&&!t.steps[q])a[q]=true;}}
  t.vst=a;t.vsig=t.steps.join();}
const playSteps=t=>fillSteps(t,altSteps(t,t.v.pat[0]>0&&t.vst&&t.vsig===t.steps.join()?t.vst:t.steps));
/* VAR.1 1-4: four variants with as many hits as the rhythm: the downbeats stay, some other hits move to a free step nearby.
   VAR.2 1-2: hits added on the heaviest free steps. Both always the same for the same rhythm; one at a time */
/* VAR.1 / VAR.2 every N bars (Lef 24 nov): altEv / fillEv 1 = every bar (as before), 2..4 = only the last bar of every N; preTick picks the bar ahead */
const evOf=(t,k)=>Math.max(1,t[k]||1),altNow=t=>!!t.altT&&(evOf(t,'altEv')<=1||!!ui.altOn[tracks.indexOf(t)]),fillNow=t=>!!t.fillT&&(evOf(t,'fillEv')<=1||!!ui.fillOn[tracks.indexOf(t)]);
function evPick(g){const nb=Math.floor((g+1)/16);let ch=false;   /* g = the last 16th of a bar: the next bar is bar nb (0 = the first) */
  tracks.forEach((t,i)=>{const a=(nb+1)%evOf(t,'altEv')===0,f=(nb+1)%evOf(t,'fillEv')===0;if(a!==!!ui.altOn[i]||f!==!!ui.fillOn[i]){ui.altOn[i]=a;ui.fillOn[i]=f;if(t.altT&&evOf(t,'altEv')>1||t.fillT&&evOf(t,'fillEv')>1)ch=true;}});
  if(ch){sync();render();}}
function altSteps(t,a){const v=altNow(t)?t.altT||0:0,n=t.len;if(!v)return a;let r=(v*7919+a.reduce((h,x,i)=>x?(h*31+i+1)%1e9:h,7))>>>0;
  const rn=()=>(r=(r*1664525+1013904223)>>>0)/4294967296,b=a.slice(0,n),hits=[...Array(n).keys()].filter(i=>b[i]&&i%16!==0);
  const m=Math.max(1,Math.round(hits.length*.5));
  for(let k=0;k<m&&hits.length;k++){const s=hits.splice(Math.floor(rn()*hits.length),1)[0],near=[1,-1,2,-2,3,-3].map(d=>(s+d+n)%n).filter(q=>!b[q]&&q%16!==0);
    if(!near.length)continue;const q=near[Math.floor(rn()*Math.min(near.length,4))];b[s]=false;b[q]=true;}
  return b;}
/* VAR.2 (Lef 15 nov): every press a new random fill: free 16ths filled more and more towards the end of each bar, now and then a short run
   of 16ths; your own hits stay. a = null returns only the added steps (they play as ghost notes, softer) */
function fillSteps(t,a){const f=fillNow(t)?t.fillT||0:0,n=t.len;if(!f)return a;const src=a||altSteps(t,t.v.pat[0]>0&&t.vst&&t.vsig===t.steps.join()?t.vst:t.steps);
  let r=((t.fillSeed||1)*2654435761+src.reduce((h,x,i)=>x?(h*31+i+1)%1e9:h,7))>>>0;const rn=()=>(r=(r*1664525+1013904223)>>>0)/4294967296;
  const add=Array(n).fill(false),base=[0,.3,.55][f];
  for(let i=0;i<n;i++){if(src[i])continue;const p=i%16;if(rn()<base*(.25+.75*p/15))add[i]=true;}
  for(let bar=0;bar*16<n;bar++)if(rn()<.5){const len=2+Math.floor(rn()*3),st=bar*16+16-len-Math.floor(rn()*3);for(let i=st;i<st+len;i++)if(i>=0&&i<n&&!src[i])add[i]=true;}   /* a run of 16ths near the end of the bar */
  if(!a)return add;const b=a.slice();add.forEach((x,i)=>{if(x)b[i]=true;});return b;}
function mutate(i,amt,auto){const t=tracks[i];if(!auto)pushUndo('mut'+i);
  const flips=Math.max(1,Math.round(amt*t.len*.5));for(let k=0;k<flips;k++){const s=Math.floor(rnd()*t.len);t.steps[s]=!t.steps[s];}}
function toast(msg,ms=1200){ui.toast=msg;ui.toastT=performance.now();ui.toastMs=ms;draw();}
/* SIDECHAIN (Lef 15 nov): on FX SLOTS, the free knob of slot 2 (DRIVE, RING, OFF: knob 7; CRUSH: knob 8); turn = amount, SHIFT = the track that ducks this one (default T1, Lef 15 nov) */
const scK=t=>-1,scv=t=>{const a=t.v.sc;while(a.length<4)a.push(a.length>=2?64:0);return a;};   /* SIDECHAIN moved to ENGINE 7/7 CHANNEL (Lef 17 nov) */
/* DRIVE: knob 3 of the slot = bell EQ after the drive, EQ.F frequency, SHIFT = EQ.G gain -12..+12 dB (Lef 15 nov); t.v.eq = gain per slot */
const eqK=(t,k)=>(t.slot[k>>2]===1||t.slot[k>>2]===2)&&k%4===2;   /* CRUSH: SHIFT + RATE = JITTER in the same place (Lef 15 nov) */
function slotLabels(t){return[...FX[t.slot[0]][1],...FX[t.slot[1]][1]].map((l,k)=>eqK(t,k)&&ui.shift?(t.slot[k>>2]===2?'JITTER':'EQ.G'):k===scK(t)?(ui.shift?'SC.SRC':'SIDECH'):isGrainShift(t,k)?(t.slot[k>>2]===TANKFX?TK_SHIFT[k%4]:t.slot[k>>2]===NEBFX?NB_SHIFT[k%4]:t.slot[k>>2]===ECHOFX?EC_SHIFT[k%4]:GR_SHIFT[k%4]):l);}
function encLabels(){const p=page(),t=tracks[ui.sel];
  if(p.key==='sA'||p.key==='sB')return[`T${ui.sel+1}.SND`,'TYPE',...SEND_TYPES[sType(p.key==='sA'?0:1)][1].map((l,k)=>k===1&&tapeF(p.key==='sA'?0:1)?'FILTER':l),`T${ui.sel+1}.PRE`,'RETURN']; /* T-knobs: this track; the rest: all tracks */
  if(p.key==='glob'&&ui.shift)return p.labels.map((l,k)=>k===5?'REL':l);
  if(p.key==='perf'&&ui.shift)return p.labels.map((l,k)=>k===1?'PROB':l);
  if(ui.layer==='param')return tracks.map((_,i)=>'T'+(i+1));
  if(p.key==='fx')return slotLabels(t);
  if(p.key==='mod'&&ui.shift)return['HZ.1',p.labels[1],'HZ.2',p.labels[3],p.labels[4],'ENV.DP','ATTACK','DECAY'];
  if(p.key==='macros'&&t.eng===ACID)return p.labels.map((l,k)=>ui.shift&&k===1?'GATE':ui.shift&&k===7?'PAN':k===2?(ui.shift?'F.AMT':'CUTOFF'):ui.shift&&k===6?'N.TYPE':k===3?(ui.shift?'WAVE':'RESO'):k===4?'F.ENV':k===5?'RAT':l);
  if(p.key==='macros'&&t.eng===THUMP)return thumpL(t,ui.shift);
  if(p.key==='macros'&&t.eng===SAMPLE)return SM_L[ui.shift?1:0];
  if(p.key==='macros'&&(wtE(t)||t.eng===TANK))return(t.eng===WDRUM?WD_L:WT_L)[ui.shift?1:0];
  if(p.key==='macros'&&t.eng===SNARE)return SN_L[ui.shift?1:0].map((l,k)=>k===0&&ui.shift&&!(hasTune(t)&&!pRange(t))?'PITCH':l);
  if(p.key==='macros'&&t.eng===SOPHIE)return SO_L[ui.shift?1:0].map((l,k)=>k===0&&ui.shift&&!(hasTune(t)&&!pRange(t))?'PITCH':l);
  if(p.key==='macros'&&isSyn(t)){const L=(t.eng===SHARK?SHARK_L:t.eng===SID?SID_L:t.eng===HIVE?HIVE_L:t.eng===NEBULA?NEB_L:SYN_L)[ui.shift?1:0];return L.map((l,k)=>k===0&&ui.shift?(hasTune(t)&&!pRange(t)?'TUNE':'PITCH'):l);}
  if(p.key==='macros'&&t.eng===HANDS)return p.labels.map((l,k)=>ui.shift?['----','ATTACK','----','----','----','----','----','PAN'][k]:['TONE','DECAY','FILTER','HANDS','SPREAD','DRIVE','ROOM','LEVEL'][k]);
  if(p.key==='macros'&&t.eng===MATTER)return p.labels.map((l,k)=>ui.shift?[pRange(t)?'PITCH':'TUNE','ATTACK','DRIFT','RUMBLE','DROP','BREAK','N.TYPE','PAN'][k]:['PITCH','DECAY','FILTER','VOICE','CRACK','SCRAPE','NOISE','LEVEL'][k]);
  if(p.key==='macros'&&t.eng===DUST)return p.labels.map((l,k)=>ui.shift&&k===0&&!pRange(t)?'TUNE':ui.shift&&k===1?'ATTACK':ui.shift&&k===3?'CURVE':ui.shift&&k===7?'PAN':ui.shift&&k===6?'N.TYPE':ui.shift&&k===2?'SPREAD':k===3?'CHAOS':k===4?'DENS':k===5?'FDBK':l);
  if(p.key==='macros'&&ui.shift)return p.labels.map((l,k)=>k===1?'ATTACK':k===2?'COLOR':k===0&&hasTune(t)&&!pRange(t)?'TUNE':k===3?'CURVE':k===4&&isTex(t)?'P.ENV':k===4&&t.eng===0?'S.TIME':k===5&&isFm(t)?'FOLD':k===6?'N.TYPE':k===7?'PAN':l);
  /* STUTTER: SHIFT keeps the labels (it sets all tracks, Lef 22 nov) */
  if(p.key==='pitch'&&ui.shift)return p.labels.map((l,k)=>k===5?'ACCENT':k===6?'SLIDE':l);
  return p.labels;}

/* ---------- sound: the EFOS core (one C source) ----------
   Preferred: WebAssembly in an AudioWorklet. Where a browser blocks WebAssembly, the same core runs as
   plain JavaScript (generated from the .wasm by wasm2js). Where it blocks worklets, a ScriptProcessor plays it. */
/* ---------- sound: the EFOS core runs as the module's DSP (dsp.so, the same C as the web app) ----------
   The web app sends its whole state after every change; here only the parts that changed go out,
   as text lines, at most once per tick (see the Move layer at the end). */
core = {     /* the generator the page itself uses (the same as efs_euclid in the core) */
  _lo: 0, _hi: 0,
  efs_euclid(k, n, rot) { n = Math.max(1, Math.min(64, n | 0)); k = Math.max(0, Math.min(n, k | 0)); rot = Math.max(0, rot | 0); let lo = 0, hi = 0;
    for (let i = 0; i < n; i++) if (((i + rot) * k) % n < k) { if (i < 32) lo |= 1 << i; else hi |= 1 << (i - 32); } this._lo = lo | 0; this._hi = hi | 0; },
  efs_gen_lo() { return this._lo; }, efs_gen_hi() { return this._hi; },
};
const _sent = new Map(), _outQ = [];
const _f = v => { v = +v; if (!Number.isFinite(v)) return '0'; const s = String(Math.round(v * 1e6) / 1e6); return s.indexOf('e') >= 0 ? v.toFixed(7) : s; };
const _grp = (k, s) => { if (_sent.get(k) !== s) { _sent.set(k, s); _outQ.push(s); } };
const _lane = L => L ? `${L.p} ` + L.v.map(_f).join(' ') : '-1';
function moveSend(m) {
  if (m.state) { const s = m.state;
    _grp('B', 'B ' + _f(s.bpm)); _grp('M', 'M ' + (s.mlen | 0)); _grp('V', 'V ' + _f(s.vol)); _grp('G', 'G ' + s.g.map(_f).join(' '));
    s.tracks.forEach((t, i) => {
      _grp('P' + i, `P ${i} ` + t.p.map(_f).join(' '));
      _grp('R' + i, `R ${i} ` + t.routes.map(v => v | 0).join(' '));
      if (t.md) _grp('D' + i, `D ${i} ` + t.md.map(v => v | 0).join(' '));
      _grp('U' + i, `U ${i} ${t.mute | 0}`);
      _grp('L' + i, `L ${i} ${t.len | 0}`);
      _grp('S' + i, `S ${i} ` + [...t.sw, ...t.gw].map(v => v >>> 0).join(' '));
      _grp('Q' + i, `Q ${i} ` + (t.cond || []).map(v => v | 0).join(' '));
      _grp('A' + i, `A ${i} ` + [...t.slw, ...t.acw].map(v => v >>> 0).join(' '));
      if (t.notes) _grp('N' + i, `N ${i} ${t.plen | 0} ` + t.notes.map(_f).join(' '));
      { const a = t.scl || []; _grp('C' + i, `C ${i} ${a.length} ` + a.map(_f).join(' ')); }
      if (t.chord) _grp('H' + i, `H ${i} ` + t.chord.map(c => _f(c[0]) + ' ' + _f(c[1])).join(' '));
      for (let k = 0; k < 16; k++) _grp('K' + i + '.' + k, `K ${i} ${k} ` + _lane(t.lock && t.lock[k]));
    });
    if (s.oto) _grp('OT', 'OT ' + (s.oto.m | 0) + (s.oto.c.length ? ' ' + s.oto.c.join(' ') : ''));   /* OTOMAT: the tracks on it, the field */
    _grp('F', 'F ' + (s.fillm | 0)); _grp('LB', 'LB ' + (s.last ? 1 : 0));
    const G = s.glock; if (G) { _grp('GL', 'GL ' + (G.len | 0)); for (let k = 0; k < 16; k++) _grp('GK' + k, `GK ${k} ` + _lane(G.lanes && G.lanes[k])); }
  }
  if (m.reseed) _outQ.push(`rs ${m.reseed[0] | 0} ${m.reseed[1] | 0}`);
  if (m.stut) _outQ.push(`st ${m.stut[0] | 0} ${m.stut[1] | 0}`);
  if (m.cap != null) _outQ.push('cap ' + (m.cap | 0));
  if (m.clear) _outQ.push('clr');
  if ('rep' in m) _outQ.push('rep ' + (m.rep | 0));
  if (m.rept) _outQ.push(`rept ${m.rept[0] | 0} ${m.rept[1] | 0}`);
  if (m.swr) _outQ.push('swr');
  if (m.rpt) _outQ.push(`rpt ${m.rpt[0] | 0} ${m.rpt[1] | 0}`);
  if (m.trig) _outQ.push(`trig ${m.trig[0] | 0} ${_f(m.trig[1])}`);
  if (m.prev) _outQ.push(`prev ${m.prev[0] | 0} ${_f(m.prev[1])}`);
  if (m.prevs) _outQ.push(`prevs ${m.prevs[0] | 0} ${m.prevs[1] | 0}`);
  if ('play' in m) _outQ.push('play ' + (m.play | 0));
  if (m.rr) _outQ.push('rr');   /* RADIO: a new random station */
  if (m.smr) _outQ.push(`smr ${m.smr[0] | 0} ${m.smr[1] | 0}`);   /* SAMPLE: REC on / off */
  if (m.sgr) _outQ.push(`sgr ${m.sgr[0] | 0}`);   /* the Sample button: GENERAL buffer on / off */
  if (m.sgt) _outQ.push(`sgt ${m.sgt[0] | 0}`);   /* its take into a SAMPLE track */
  if (m.smp) _outQ.push(`smp ${m.smp[0] | 0} ${m.smp[1] | 0}`);   /* SAMPLE: PLAY on / off */
  if ('co' in m) _outQ.push('co ' + (m.co ? 1 : 0));   /* MIDI clock out */
}
const audio = { ctx: null, ready: true, mode: 'MOVE', send: moveSend, out: null };
function startAudio() {}
setTimeout(() => { if (!restoredState) tracks.forEach(t => { if (t.gen === 0) t.steps = gen(t); }); render(); }, 0);

/* the whole state goes to the core after every change (a few hundred numbers) */
/* the global values and one track's params, in the order of the core */
const gArr=()=>[...[...perf.slice(0,7),...[0,1].flatMap(k=>[1,2,3,4,5,7].map(j=>sendShared[k][j])),glob[2],glob[3],glob[4],glob[5],glob[8],glob[6],glob[7]].map(v=>v/127),...stutShared.slice(0,7).map((v,k)=>k===0?(fromV(v,10)+.5)/10:k===2?(fromV(v,8)+.5)/8:v/127),perf[7]/127,sendShared[0][8]/127,sendShared[1][8]/127,stutShared[7]/127,(fromV(stutShared[8],8)+.5)/8,(fromV(stutShared[9],8)+.5)/8,(stutShared[10]||0)/4,(stutShared[11]||0)/4,(glob[9]||0)/127];
function trackP(t){
  const m=t.v.mod.map(v=>v/127);
  const p=[...t.v.macros.map((v,k)=>k===0&&pMel(t)?octP(t):k===0?(keySnap(t)?snapP(t):tuneP(t)):v/127),...t.v.pat.map(v=>v/127),m[0],m[1],m[2],m[3],t.env[0]/127,t.env[1]/127];p.push((t.noise+.5)/4,...t.black.map(v=>v/127));
  for(let k=0;k<2;k++)p.push((t.slot[k]+.5)/FX.length,...t.v.fx.slice(k*4,k*4+4).map((v,j)=>j===3&&t.slot[k]===2?1:v/127));   /* CRUSH: a hidden MIX, always full (for MIX.1 / MIX.2) */p.push(t.v.sA[0]/127,...t.waves.map(w=>(w+.5)/7),
    m[4],m[5],t.v.rsm[0]/127,(t.rlen[0]-1)/15,m[6],m[7],t.v.rsm[1]/127,(t.rlen[1]-1)/15,t.rloop[0]?1:0,t.rloop[1]?1:0,t.v.sB[0]/127,t.v.pitch[6]/127,pMode(t),t.v.pat[5]/127,(t.eng+.5)/ENGINES.length,t.v.att[0]/127,lisSrc(t)<0?0:(lisSrc(t)+1.5)/9,1,t.v.sA[6]>=64?1:0,t.v.sB[6]>=64?1:0,t.v.pan[0]/127,(fromV(t.v.stu[0],10)+1.5)/11,t.v.sauto[0]/127,t.v.col[0]/127,t.v.edp[0]/127,...[0,1].map(q=>t.lhz&&t.lhz[q]?Math.max(.001,t.v.hz[q]/127):0),t.v.gx[0]/127,t.v.gx[1]/127,t.v.gx[2]/127,t.v.gx[3]/127,t.v.gate[0]/127,...(t.eng===THUMP?[(thAlgo(t)+.5)/TH_NA,t.v.cc[0]/127,t.v.chp[0]/127]:t.eng===HIVE?[(fromV(t.v.cv[0],8)+.5)/8,t.v.cc[0]/127,t.v.chp[0]/127]:t.eng===MATTER||t.eng===SHARK||t.eng===SOPHIE||t.eng===SNARE?[t.v.cv[0]/127,t.v.cc[0]/127,t.v.chp[0]/127]:[(jMono(t)?0.5:t.eng===CHORD&&fromV(t.v.cv[0],4)===0?1.5:fromV(t.v.cv[0],4)+.5)/4,(fromV(t.v.cc[0],4)+.5)/4,(fromV(t.v.chp[0],4)+.5)/4]),t.v.gx[4]/127,t.v.gx[5]/127,t.v.gx[6]/127,t.v.gx[7]/127,t.v.crv[0]/127,t.v.pe[0]/127,t.v.fo[0]/127,t.v.st[0]/127,folSrc(t)<0?0:(folSrc(t)+1.5)/9,t.v.fa[0]/127,t.v.pw[0]/127,
    t.v.stu[1]/127,(fromV(t.v.stu[2],8)+.5)/8,t.v.stu[3]/127,t.v.stu[4]/127,t.v.stu[5]/127,t.v.stu[6]/127);
  p.push(t.v.vp[0]/127,t.v.vd[0]/127,t.v.tu[0]/127,t.v.stu[7]/127,(fromV(t.v.stu[8],8)+.5)/8,(fromV(t.v.stu[9],8)+.5)/8);   /* VAR.P, VAR.D, TUNE, STUTTER LFO */
  p.push(t.v.tat[0]/127,t.v.gdr[0]/127,t.v.nf[0]/127,t.v.cha[0]/127,t.v.chs[0]/127,(fromV(t.v.sc[0],9)+.5)/9,t.v.sc[1]/127,t.v.eq[0]/127,t.v.eq[1]/127,(t.lph||[0,0])[0]/8,(t.lph||[0,0])[1]/8,((t.v.shc||[0])[0]+.5)/4,...(t.v.cs||CS0()).map((v,k)=>k===8?((v|0)+.5)/5:k===4||k===5||k===6?v/127:v===64&&k!==2?.5:v/127));
  p.push(...smv(t).map(v=>v/127),...(t.v.acx||ACX0()).map(v=>v/127),(vdcI(t)+.5)/6,scv(t)[2]/127,scv(t)[3]/127,lofN(lofV(t)[0]),lofN(lofV(t)[1]),lofN((t.v.dcp||[64])[0]),...wtPush(t),...tkPush(t),...wwPush(t),...l3Push(t),...plkv(t).map(v=>v/127),lmv(t)[0]/127,...sidPush(t),...j6Push(t));   /* + PLOCK.G, PLOCK.H */   /* + LFO 3 */   /* + TANK */   /* + WAVETABLE */   /* + DEC.P (THUMP SNARE SOPHIE) */   /* + LFO OFFSET 1 / 2 */   /* + SIDECHAIN TIME.S, FILT.S */   /* + ACID TIME.S, AMT.A */   /* + SAMPLE */   /* + CHANNEL STRIP */   /* + SHARK CHORUS */   /* + LFO PHASE 1 / 2 */   /* + DRIVE bell EQ gain per slot */   /* + SIDECHAIN source, amount */   /* THUMP ATTACK, DRIVE (engines without their own), NEBULA FILTER, J60 CHORUS AMOUNT, CHAOS */
  return p;}
function trackState(t){const p=trackP(t);
  const ps=playSteps(t),pg=fillNow(t)?fillSteps(t,null):null,sw=[0,0,0,0],gw=[0,0,0,0];for(let i=0;i<t.len;i++){if(ps[i])sw[i>>5]|=1<<(i&31);if(pg&&pg[i])gw[i>>5]|=1<<(i&31);}
  const slw=acidMask(t.slR,t.v.sl[0]),acw=acidMask(t.acR,t.v.ac[0]);
  return{cond:Array.from({length:TRACK_STEPS},(_,k)=>t.cond&&t.cond[k]||0),scl:sclNotes(t),p,slw,acw,routes:t.routes.map((m,k)=>t.modOff[k]?0:m),md:t.mdst.map(d=>d==null||d<8?-1:d),mute:silent(t)?1:0,len:t.len,sw,gw,plen:folSrc(t)>=0?pLen(tracks[folSrc(t)]):pLen(t),notes:folSrc(t)>=0?Array.from({length:pLen(tracks[folSrc(t)])},(_,s)=>harmSemis(t,tracks[folSrc(t)],s)):Array.from({length:pLen(t)},(_,s)=>semis(t,s)),lock:t.lanes&&t.lanes.some(Boolean)?t.lanes.map(l=>l&&{p:l.p,v:l.v.slice(0,t.len)}):null,chord:t.eng===CHORD||t.eng===SID?Array.from({length:pLen(t)},(_,s)=>chordIv(t,s)):null};}
function syncNow(){if(!audio.ready)return;audio.send({state:{oto:{m:otoMask(),c:otoMask()?otoCells().map(c=>c[0]*32+c[1]*4+c[2]):[]},fillm:ui.fillHeld|0,last:lastBar(),bpm,mlen:Math.round((ui.mlen||0)*16),vol:volume/127,g:gArr(),tracks:tracks.map(trackState),
  glock:{len:glen(),lanes:glanes.some(Boolean)?glanes.map(l=>l&&{p:l.p,v:l.v.slice(0,glen())}):null}}});}
/* position from the core; a wrapped pattern can mutate (VAR.R) */
function fromCore(d){
  if(d.ok){audio.mode+=' '+d.ok;toast(audio.ctx.state==='running'?'SOUND ON ('+audio.mode+')':'TAP PLAY AGAIN FOR SOUND',3000);return;}
  if(d.radio!=null){if(d.radio!==ui.radio){ui.radio=d.radio;if(tracks.some(smRadio))toast('RADIO: '+d.radio,3000);}return;}   /* RADIO: the stream's state and station */
  if(d.smr!=null){const o=ui.smr||0,n=d.smr;if(n!==o){const s=ui.sel,was=o>>s&1,is=n>>s&1,ww=o>>8+s&1,wi=n>>8+s&1,w=' T'+(s+1);   /* SAMPLE: tracks recording (bits 0-7), waiting for the bar (8-15) */
    for(let i=0;i<8;i++)if(n>>i&1&&!(o>>i&1)&&ui.sgGot)ui.sgGot[i]=null;   /* an own recording replaces the Sample-button take */
    if(tracks[s].eng===SAMPLE){if(was&&!is)toast('REC FULL'+w);else if(is&&!wi&&(!was||ww))toast('REC STARTED'+w);else if(!was&&wi)toast('REC WAIT: NEXT BAR'+w);}   /* the pad says its own start / stop */
    ui.smr=n;render();}return;}
  if(d.sg!=null){if(d.sg!==ui.sg){const o=ui.sg||0,n=d.sg;ui.sg=n;genShow();
      if(n>>3!==o>>3&&n&2&&!(n&5)){toast('SAMPLE: TAKE READY',2000);   /* a new take: tracks that play a Sample-button take get it at once (Lef 19 nov) */
        tracks.forEach((t,i)=>{if(t.eng===SAMPLE&&!smFile(t)&&ui.sgGot&&ui.sgGot[i]!=null){audio.ready&&audio.send({sgt:[i]});ui.sgGot[i]=n>>3;}});}
      render();}return;}   /* the GENERAL buffer: take x 8, +1 recording, +2 there, +4 waiting for the bar */
  if(d.smw!=null){ui.smw=d.smw;if(!ui.menu&&!ui.saver)draw();return;}   /* SAMPLE: the waveform of the selected track (Move) */
  if(d.smg!=null){if(d.smg!==ui.smGuard){ui.smGuard=d.smg;render();}return;}   /* the speaker is on: no MIC monitor */   /* SAMPLE: tracks recording */
  if(d.fxn){ui.fxn=d.fxn;if(ui.layer==='fx')draw();return;}   /* slot types sounding now (TYPE.1 / TYPE.2) */
  if(d.cpu!=null){ui.cpu=d.cpu;{const n=performance.now();if(d.cpu>=CPU_SPIKE&&n-(ui.cpuWarnT||-1e9)>10000&&!ui.saver){ui.cpuWarnT=n;toast('CPU HIGH '+Math.round(d.cpu*100)+'%',2000);}}   /* a warning on every spike, at most once per 10 s (Lef 22 nov) */if(((ui.layer==='glob'||ui.cat===3)&&!ui.menu||ui.menu==='main')&&!ui.saver)draw();return;}
  if('bat' in d){ui.bat=d.bat;if(ui.menu==='main'&&!ui.saver)draw();return;}   /* Move battery {p, chg}, null = none */
  if(d.cs!=null){const ext=!!(d.cs&1);if(ext!==!!ui.ext){ui.ext=ext;toast(ext?'MIDI CLOCK IN':'MIDI CLOCK GONE',2000);}
    if(ext){if(d.bn&&Math.abs(bpm-d.bn)>=.05)bpm=Math.round(d.bn*10)/10;if(!!(d.cs&2)!==ui.playing){setPlaying(!!(d.cs&2),false);if(!ui.playing)return;}}}   /* the clock leads PLAY and the tempo */
  if(!ui.playing||d.g<0)return;ui.pos=d.g;preTick(d.g);otoTick(d.g);
  if(d.hits){midiOut(d.hits);const now=performance.now();for(let i=0;i<8;i++)if(d.hits>>i&1)hitMark(i,now);hitOff();}if(d.gr!=null)ui.gr=d.gr;
  tracks.forEach((t,i)=>{if(t.gen===8){const H=(ui.oh||(ui.oh=[]))[i]||(ui.oh[i]=[]);if(d.pos[i]!==ui.tpos[i])H[d.pos[i]]=0;if(d.hits>>i&1)H[d.pos[i]]=1;}   /* OTOMAT: the step pads show where the field played this loop (Lef 26 nov) */
    if(ui.playing)trgTur(t,ui.tpos[i],d.pos[i]);ui.tpos[i]=d.pos[i];if(d.ppos){if(ui.playing)turStep(t,ui.ppos[i],d.ppos[i]);ui.ppos[i]=d.ppos[i];}if(ui.tw&&ui.tw.list.includes(i)&&d.pos[i]!==ui.tw['p'+i]&&performance.now()-ui.tw.t0>PV_HOLD){ui.tw['p'+i]=d.pos[i];turWrite(t,i,ui.tw.c===6);}if(d.loops[i]>ui.loops[i]){const v=t.v.pat[0]/127;varySteps(i);soundVar(i);pitchVar(i);}ui.loops[i]=d.loops[i];});
  render();}

/* ---------- build controls ---------- */
const encX=[571,703,834,965,1097,1229,1361,1492];
const encs=[],leds=[],encL=[];
encX.forEach((cx,i)=>{const b=roundBtn(cx,452,60,'enc',null);b.appendChild(document.createElement('i'));
  b.setAttribute('aria-label','Encoder '+(i+1));encs.push(b);bindEnc(b,i);
  const[x,y]=P(cx,512);leds.push(el('div','led',x-2,y-2));const[lx,ly]=P(cx,536);encL.push(el('div','enc-l',lx-46,ly-7));});
const vol=roundBtn(1710,455,72,'enc',null);vol.appendChild(document.createElement('i'));vol.setAttribute('aria-label','Volume');bindEnc(vol,'vol');
{const[x,y]=P(262,426),[x2,y2]=P(420,512);const w=el('div','wm',x,y,x2-x,y2-y);pix(w.appendChild(document.createElement('div')),'EFOS',5);{const r=w.appendChild(document.createElement('div')),c=document.createElement('div');pix(r.appendChild(document.createElement('div')),'TERMINAL >',2);c.className='cur';r.appendChild(c);pix(c,'_',2);} /* a prompt with a cursor that blinks on the beat */w.setAttribute('aria-label','EFOS Terminal');}
const jog=roundBtn(337,640,128,'enc',null);jog.setAttribute('aria-label','Jog wheel: tempo');bindEnc(jog,'jog');
const CAT_KEYS=['9','0','-','='];   /* keyboard: the four left keys */
const pills=[595,695,795,895].map((cy,i)=>{const[x,y]=P(466,cy);const b=el('button','pill',x-10,y-28);const L=CATS[i].name;
  b.setAttribute('aria-label',L);b.onclick=()=>{catPress(i);render();};return b;});
const padX=[516,647,778,909,1040,1171,1302,1433],padY=[553,653,753,853];
const pads=padY.map((py,r)=>padX.map((px,c)=>{const[x,y]=P(px,py);const b=el('button','pad',x,y);
  b.setAttribute('aria-label',`Pad row ${r+1}, column ${c+1}`);
  b.addEventListener('pointerdown',e=>{e.preventDefault();if(r===0)held0.add(c);padDown(r,c);});
  b.addEventListener('pointerup',()=>{if(r===0)held0.delete(c);padUp(r,c);});b.addEventListener('pointerleave',()=>{if(r===0)held0.delete(c);padUp(r,c);});return b;}));
const FN=[['CAP','REC'],['LOOP','MUTE'],['DEL','COPY'],['UNDO','SHIFT']];
const fn={};[596,695,795,894].forEach((cy,r)=>[1610,1699].forEach((cx,c)=>{const n=FN[r][c];fn[n]=roundBtn(cx,cy,68,'fn',n);}));
fn.BACK=roundBtn(297,795,68,'fn','<');fn.MENU=roundBtn(386,795,68,'fn','MENU');
fn.PLAY=roundBtn(298,1011,68,'fn','PLAY');fn.RECB=roundBtn(387,1011,68,'fn','REC');
fn.PREV=roundBtn(1601,1011,44,'fn','<');fn.NEXT=roundBtn(1713,1011,44,'fn','>');
fn.PLUS=roundBtn(1657,980,44,'fn','+');fn.MINUS=roundBtn(1657,1041,44,'fn','-');
const steps=[...Array(16)].map((_,i)=>{const b=roundBtn(542+i*65.47,1011,44,'step',null);b.setAttribute('aria-label','Step '+(i+1));
  b.onclick=()=>stepClick(i);
  b.addEventListener('pointerdown',()=>{ui.heldStep=i;ui.stepT0=performance.now();clearTimeout(ui.condHT);ui.condHT=setTimeout(condHint,STEP_HOLD);ui.stepLk=null;ui.slk=null;ui.slkShow=null;slkView();render();});const up=()=>{if(ui.heldStep===i)ui.heldStep=null;};
  b.addEventListener('pointerup',up);b.addEventListener('pointerleave',up);b.addEventListener('pointercancel',up);return b;});

/* mouse-over: after 0.4 s a label with the name and the keyboard key; pads only on row 1 */
const TIPS={PLAY:'PLAY: SPACE',SHIFT:'SHIFT: SHIFT',MUTE:'MUTE: M (HOLD = ON)',MENU:'MENU: KEY ,   PRESETS: KEY .',BACK:'BACK: ESC',
  DEL:'DEL: BACKSPACE   SHIFT = INIT',COPY:'COPY: HOLD C',CAP:'CAP: K   HOLD = OFF',LOOP:'LOOP: L   PRESET LOOPER SETTINGS   SHIFT = ON / OFF',UNDO:'UNDO: U   SHIFT = REDO',REC:'SAMPLE: RECORD THE MIC INTO THE GENERAL BUFFER, AGAIN = STOP   SAMPLE TRACKS: PLAY PAD BLINKS = LOAD IT',RECB:'REC: R   TURN KNOBS WHILE PLAYING   SHIFT = CLEAR   DEL + KNOB = CLEAR KNOB',
  PREV:'STEP PAGE  SHIFT = NUDGE',NEXT:'STEP PAGE  SHIFT = NUDGE',PLUS:'PAGE: + OR UP   SHIFT = LENGTH',MINUS:'PAGE: - OR DOWN   SHIFT = LENGTH'};
const tipEl=el('div','tip',0,0);let tipT=null;
function tipShow(b,s){clearTimeout(tipT);if(!set.tips)return;if(typeof s==='function')s=s();if(!s)return;tipT=setTimeout(()=>{pix(tipEl,s,2);tipEl.style.display='block';
  const w=tipEl.offsetWidth,h=tipEl.offsetHeight,cx=b.offsetLeft+b.offsetWidth/2,cy=b.offsetTop+b.offsetHeight/2;   /* on the middle of the control, not over its label */
  tipEl.style.left=Math.max(4,Math.min(stage.offsetWidth-w-4,Math.round(cx-w/2)))+'px';
  tipEl.style.top=Math.max(4,Math.min(stage.offsetHeight-h-4,Math.round(cy-h/2)))+'px';},400);}
function tipHide(){clearTimeout(tipT);tipEl.style.display='none';}
function tip(b,s){b.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse')tipShow(b,s);});
  ['pointerleave','pointerdown'].forEach(n=>b.addEventListener(n,tipHide));}
Object.entries(TIPS).forEach(([k,s])=>fn[k]&&tip(fn[k],s));
tip(jog,'JOG: TEMPO   ENTER = PRESS');tip(vol,'VOLUME');
pills.forEach((b,i)=>tip(b,CATS[i].name+': KEY '+CAT_KEYS[i]));
pads.forEach((row,r)=>row.forEach((b,c)=>tip(b,()=>padTip(r,c))));
encs.forEach((b,i)=>tip(b,()=>encTip(i)));
const ROW2_TIP={'V1.INT':'V1.INT: VAR.1 OFF > EVERY BAR > EVERY 2 / 3 / 4 BARS','V2.INT':'V2.INT: VAR.2 OFF > EVERY BAR > EVERY 2 / 3 / 4 BARS (THE LAST BAR)','VAR.1':'VAR.1: OFF > 4 VARIANTS, SAME NUMBER OF HITS','VAR.2':'VAR.2: OFF > 1 > 2 FULLER','FILL':'FILL: HOLD = STEPS WITH TRIG CONDITION FILL PLAY','RND.M':'RND.M: NEW MELODY','RND.P':'RND.P: NEW PITCH (MELODY: NEW OCTAVE)',
  'TURING+':'TURING+: A HIT + NEW NOTE NEXT STEP (HOLD = EVERY STEP)','TURING-':'TURING-: A REST NEXT STEP (HOLD = EVERY STEP)'};
/* what a pad does on the layer and page on screen now (row 0 = the tracks) */
function padTip(r,c){const t=tracks[ui.sel],p=page(),all=' (SHIFT = ALL)',T='T'+(c+1);
  if(r===0)return ui.muteMode||ui.muteHeld?`${T}: MUTE ON / OFF (SHIFT = SOLO)`:`${T}: SELECT, KEY ${c+1} (SHIFT = MUTE)`;
  const nm=ui.cat<3?PADS[ui.cat][c]:null;
  if(ui.cat===0){
    if(r===1)return nm?ROW2_TIP[nm]+all:null;
    if(r===2)return c<4?`RISE ${RISE_L[c]}: A HELD REPEAT SWELLS IN (AGAIN = OFF)`:`SWEEP ${SWEEP_L[c-4]}: A HELD REPEAT MOVES THE LFO DEST (AGAIN = OFF)`;
    if(r===3)return`REPEAT ${REP_PADS[c]}: HOLD (SHIFT = ALL)`;return null;}
  if(ui.cat===1){if(r===1)return nm?ROW2_TIP[nm]+all:null;
    if(r===3)return`${PVARS[c]}: ON / OFF`+all;return null;}
  if(sendPg())return r===3?`SEND ${c<4?'A':'B'} ${[5,10,20,35][c%4]}%`+(c%4===0?', AGAIN = OFF':'')+all:null;
  if(ui.cat===2){const pg=ui.cp[2];
    if(r===3)return`SEND ${c<4?'A':'B'} ${[5,10,20,35][c%4]}%`+(c%4===0?', AGAIN = OFF':'')+all;
    if(pg===FXPG)return`SLOT ${r}: ${FX[padFx((r-1)*8+c)][0]} (AGAIN = OFF, HOLD = PICK)`;
    if(r===1)return nm?{'RND.S':'RND.S: NEW SOUND, SAME ENGINE','RND.I':'RND.I: ANOTHER SLICE (INDEX)','MUT.S':'MUT.S: THE SOUND A LITTLE'}[sndName(nm,t)]+all:null;
    if(r===2&&c<2&&wtE(t))return'LOAD.'+'AB'[c]+': PICK A WAVETABLE WITH THE JOG (NOW '+wtn(t)[c]+')';
    if(r===2&&c===7&&t.eng===SAMPLE)return'MONITOR: '+(smv(t)[7]>0?'ON '+pct(smv(t)[7])+', PRESS = OFF':'OFF, PRESS = ON AGAIN')+all;
    if(r===2&&c===0&&smFile(t))return'LOAD: PICK A WAV WITH THE JOG'+(t.smn?' (NOW '+t.smn+')':'');
    if(r===2&&c===0&&t.eng===SAMPLE)return'REC: RECORD INTO THE BUFFER (AGAIN = STOP)'+all;
    if(r===2&&c===1&&t.eng===SAMPLE&&!smFile(t))return'OVERDUB: RECORD ON TOP, SAME LENGTH (AGAIN = STOP)'+all;
    if(r===2&&c===2&&t.eng===SAMPLE)return(genNew(ui.sel)?'PLAY (BLINKS): LOAD THE NEW SAMPLE-BUTTON TAKE':'PLAY: HEAR THE WHOLE SAMPLE (AGAIN = STOP)')+all;
    if(r===2&&c===3&&smRadio(t))return'RND.R: A NEW RANDOM RADIO STATION';
    if(r===2&&c===2)return'PLAY: ONE HIT OF THIS TRACK ON ITS ROOT NOTE';
    return null;}
  if(ui.layer==='param'){
    if(r===1)return`PICK ${rnd2(p.labels[c],t)}`;
    if(r===2)return`RANDOM ${rnd2(allLab(p),t)} ${T}`+all;
    if(r===3&&c===0)return`RANDOM ${p.name}: ALL TRACKS, SAFE`;if(r===3&&c===1&&p.key==='macros')return'VAR.D: DECAY VARIATION, ALL 8 TRACKS';return null;}
  if(r===1)return`MUTATE ${T}: A NEW SOUND, SAME ENGINE (SHIFT = ONLY A NEW PATTERN)`;
  if(r===2&&c<MUT_BTN.length)return`MUTATE ${MUT_BTN[c][0]}: NEW AT RANDOM`+all;
  if(r===3&&c===7&&ui.shift)return'SHIFT + ALL: ALL RANDOM, EVERY TRACK, EVERYTHING (LENGTH 4 8 16 32 64 128)';
  if(r===3&&c<DEF_BTN.length)return(DEF_BTN[c][2]||`DEFAULT ${DEF_BTN[c][0]}`)+all;
  return null;}
/* a knob: what it does now, and with SHIFT */
function encTip(i){if(!cpage().src){const sh=ui.shift,t=tracks[ui.sel],nm=v=>{ui.shift=v;try{const s=kSpec(i);if(!s)return null;
      if(s.own){const o=OWN[s.own],l=o.lab(t);return l==='----'?null:o.long||l;}
      const l=knobInfos()[i].lab;return l==='----'?null:s.lab?LONG[s.lab]||dn(s.lab):withCtx(ctxOf(s),()=>long(encLabels()[s.src[2]]).replace(/ \(SHIFT \+ [A-Z.]+\)$/,''));}finally{ui.shift=sh;}};
    const a=nm(false),b=nm(true),s=kSpec(i);return a&&b&&b!==a?`${a}   SHIFT: ${b}`:a&&(s&&(s.all||s.own&&OWN[s.own].shAll)||b===a)?a+'   SHIFT: ALL TRACKS':a;}
  const sh=ui.shift;ui.shift=false;const n=encLabels()[i];ui.shift=true;const s=encLabels()[i];ui.shift=sh;
  const f=l=>l&&l!=='----'?long(l).replace(/ \(SHIFT \+ [A-Z.]+\)$/,''):null,a=f(n),b=f(s);if(ui.layer==='perf'&&page().key==='stut')return a+'   SHIFT: ALL TRACKS';return b&&b!==a?`${a||n}   SHIFT: ${b}`:a;}

/* ---------- interaction ---------- */
function setShift(v){ui.shift=v;if(!v)ui.paTurned=false;if(!v&&ui.menu==='presets'&&!ui.saveTo&&ui.pa!==0){ui.pa=0;ui.confirm=null;}   /* SHIFT let go: the list closes, nothing happens (Lef 19 nov) */if(!v&&ui.muteHeld&&ui.muteQueue.size)muteFlush();render();}
fn.SHIFT.addEventListener('pointerdown',()=>setShift(true));
fn.SHIFT.addEventListener('pointerup',()=>setShift(false));fn.SHIFT.addEventListener('pointerleave',()=>ui.shift&&setShift(false));
fn.PLAY.onclick=togglePlay;
/* UNDO: up to 16 steps back (every action stores the whole state), SHIFT + UNDO = redo (key U, SHIFT + U).
   A burst of the same action (engine scroll, copy, one knob nudge) counts as one step. Tempo, mutes and solos stay as they are */
const UNDO_N=16;
function snapAll(){return JSON.stringify({tracks,perf,glob,sendShared,stutShared,glanes,fxLib});}
function pushUndo(tag){const now=performance.now();
  if(tag&&ui.undoTag===tag&&now-ui.undoT<1500){ui.undoT=now;return;}
  ui.undoTag=tag||null;ui.undoT=now;ui.undos.push(snapAll());if(ui.undos.length>UNDO_N)ui.undos.shift();ui.redos.length=0;}
function applySnap(str){const d=JSON.parse(str);
  d.tracks.forEach((x,k)=>{const t=tracks[k];if(!t)return;const mute=t.mute,solo=t.solo;Object.assign(t,x);t.mute=mute;t.solo=solo;});
  [[perf,d.perf],[glob,d.glob],[stutShared,d.stutShared],[sendShared[0],d.sendShared[0]],[sendShared[1],d.sendShared[1]]].forEach(([a,b])=>b&&b.forEach((v,k)=>a[k]=v));
  glanes=d.glanes||Array(LANES).fill(null);fxLib=fxLibOf(d.fxLib);
  ui.stepPage=Math.min(ui.stepPage,Math.ceil(tracks[ui.sel].len/16)-1);sync();render();}
function undoPress(redo){if(!redo&&ui.menu==='presets'&&ui.preDel){const d=ui.preDel;ui.preDel=null;if(d.state){presets.lens[d.i]=d.len;preStore(d.i,d.name,d.state);toast('BACK: '+String(d.i+1).padStart(2,'0')+' '+d.name,2500);}render();return;}
  const from=redo?ui.redos:ui.undos,to=redo?ui.undos:ui.redos;
  if(!from.length){toast(redo?'NOTHING TO REDO':'NOTHING TO UNDO');return;}
  to.push(snapAll());applySnap(from.pop());ui.undoTag=null;toast((redo?'REDO ':'UNDO ')+(redo?ui.redos.length:ui.undos.length)+' LEFT');}
fn.UNDO.onclick=()=>undoPress(ui.shift);
fn.COPY.addEventListener('pointerdown',e=>{e.preventDefault();copyDown();});fn.COPY.addEventListener('pointerup',copyUp);fn.COPY.addEventListener('pointercancel',copyUp);
/* CAP: each press 1 > 2 > 4 > 8 bars > off, at once: the last bars up to the press loop as they were (the core takes fewer
   when less has been played since PLAY) */
const CAP_STEPS=[0,1,2,4,8];
function capPress(){if(!ui.playing){toast('CAP: PRESS PLAY FIRST',2000);return;}const k=CAP_STEPS.indexOf(ui.cap||0);ui.cap=CAP_STEPS[(k+1)%5];
  audio.ready&&audio.send({cap:ui.cap});let n=ui.cap;const have=Math.max(1,Math.floor((ui.pos+1)/16));while(n>1&&n>have)n>>=1;
  toast(ui.cap?`CAP: LAST ${n} BAR${n>1?'S':''} LOOP`:'CAP OFF',2500);render();}
function capOff(){ui.cap=0;audio.ready&&audio.send({cap:0});toast('CAP OFF',1500);render();}
/* CAP: a tap steps on (acts on release), held 0.5 s = off at once */
let capT=null,capLong=false;
function capDown(){if(capT)return;capLong=false;capT=setTimeout(()=>{capLong=true;if(ui.cap)capOff();},500);}
function capUp(){if(!capT)return;clearTimeout(capT);capT=null;if(!capLong)capPress();}
fn.CAP.addEventListener('pointerdown',e=>{e.preventDefault();capDown();});fn.CAP.addEventListener('pointerup',capUp);
fn.CAP.addEventListener('pointerleave',()=>{if(capT){clearTimeout(capT);capT=null;}});
/* REC (motion): with REC on and PLAY on, turning a knob records what it changes on the steps that pass.
   A track lane runs on that track's steps (64), a global lane (sends, PERFORM, compressor, stutter) on the master clock:
   the master length, or 4 bars. Up to 16 lanes per track and 16 global. Steps without a recorded value play the knob as it is.
   SHIFT + REC clears the lanes of the page you are on; hold DEL and turn a knob to clear that knob's lane */
const LANES=16,TRACK_STEPS=MAXS,G_STEPS=256;
let glanes=Array(LANES).fill(null);
const glen=()=>ui.mlen?ui.mlen*16:64;
const NOREC=new Set(['track/pat/0/0','track/pat/0/1','track/pat/0/2','track/pat/0/4','track/pat/0/6','track/pat/0/7','track/pat/1/4','track/pat/1/6','track/pat/1/7',
  'track/pitch/0/3','track/pitch/1/3','fx/sA/0/1','fx/sA/1/1','fx/sB/0/1','fx/sB/1/1']);   /* knobs that build the pattern, and send TYPE */
/* which knob: on ALL ENGINE / ALL TRIGGERS the same name as on the track page */
const recKid=k=>ui.layer==='param'?(allVD(page())?'own/VAR.D/0':`track/${page().key}/0/${pdi(page(),allPar())}`):`${ui.layer}/${page().key}/${ui.shift?1:0}/${pdi(page(),k)}`;
const lanesOf=t=>t.lanes||(t.lanes=Array(LANES).fill(null));
const globalPage=()=>ui.layer==='glob'||(ui.layer==='perf'&&page().key==='perf')||page().key==='sA'||page().key==='sB';
const probe=()=>({g:gArr(),p:tracks.map(trackP)});
function recFind(i){const kid=recKid(i);if(ui.layer==='param'){const l=(tracks[i].lanes||[]).find(l=>l&&l.kid===kid);return l?{l,s:ui.tpos[i]}:null;}   /* ALL pages: knob i = track i, its own recording (Lef 26 nov: the dot everywhere) */
  return(tracks[ui.sel].lanes||[]).find(l=>l&&l.kid===kid)&&{l:(tracks[ui.sel].lanes).find(l=>l&&l.kid===kid),s:ui.tpos[ui.sel]}||
    (glanes.find(l=>l&&l.kid===kid)?{l:glanes.find(l=>l&&l.kid===kid),s:((ui.pos%glen())+glen())%glen()}:null);}
const recMark=i=>!!recFind(i);
const recShow=i=>{const f=ui.playing&&recFind(i);return f&&f.s>=0&&f.l.u[f.s]>=0?f.l.u[f.s]:null;};
function recWrite(lanes,n,s,idx,val,kid,uv,tag){if(s<0)return true;
  let l=lanes.find(l=>l&&l.p===idx);
  if(!l){const k=lanes.indexOf(null);if(k<0)return false;l=lanes[k]={p:idx,kid,v:Array(n).fill(-1),u:Array(n).fill(-1)};}
  l.kid=kid;const now=performance.now(),L=ui.recLast;pushUndo('rec'+tag);
  if(L&&L.tag===tag&&now-L.at<600){let q=L.s;while(q!==s){q=(q+1)%n;l.v[q]=val;l.u[q]=uv;if(l.pk)l.pk[q]=0;}}   /* a fast turn skips no steps */
  l.v[s]=val;l.u[s]=uv;if(l.pk)l.pk[s]=0;ui.recLast={tag,s,at:now};return true;}   /* REC over a P-LOCK: it is a recording now */
function recDiff(k,before,kidO,uvO){const after=probe(),kid=kidO||recKid(k),uv=kidO?uvO:ui.layer==='param'?null:encGet(k);let full=false;   /* kidO / uvO: an own knob (its name, its value) */
  after.g.forEach((v,i)=>{if(Math.abs(v-before.g[i])>1e-6)full=!recWrite(glanes,G_STEPS,((ui.pos%glen())+glen())%glen(),i,v,kid,uv,'g'+i)||full;});
  after.p.forEach((p,j)=>p.forEach((v,i)=>{if(Math.abs(v-before.p[j][i])>1e-6){const t=tracks[j],s=ui.tpos[j];
    if(s>=0&&s<t.len)full=!recWrite(lanesOf(t),TRACK_STEPS,s,i,v,kid,ui.layer==='param'?(([a,i])=>a[i])(allArr(t,page())):uv,j+'.'+i)||full;}}));
  if(full)toast('REC FULL: 16 KNOBS, SHIFT + REC CLEARS');}
/* own knobs: recorded and P-locked under own/NAME/SHIFT */
const ownKid=nm=>'own/'+nm+'/'+(ui.shift?1:0),ownLane=nm=>{const kid=ownKid(nm),l=(tracks[ui.sel].lanes||[]).find(l=>l&&l.kid===kid);if(l)return{l,s:ui.tpos[ui.sel]};const g=glanes.find(l=>l&&l.kid===kid);return g?{l:g,s:((ui.pos%glen())+glen())%glen()}:null;},   /* also a global own knob (its lane is in glanes) */
  ownRec=nm=>!!ownLane(nm);
const ownShow=nm=>{if(!ui.playing)return null;const f=ownLane(nm);return f&&f.s>=0&&f.l.u[f.s]>=0?f.l.u[f.s]:null;};   /* playing: an own knob follows its recording on the screen too, as the others do (Lef 26 nov: STRETCH stood still) */
function ownClear(nm){const kid=ownKid(nm),t=tracks[ui.sel];let n=0;(t.lanes||[]).forEach((l,j)=>{if(l&&l.kid===kid){if(!n)pushUndo();t.lanes[j]=null;n++;}});
  const lab=OWN[nm].lab(t);toast(n?lab+': RECORDING CLEARED':lab+': NOTHING RECORDED');if(n)sync();render();}
/* DEL held + a knob: its recording goes, and on a sound knob its modulation links too */
function recClearKnob(k){const kid=recKid(k),t=tracks[ui.sel];let n=0;
  [t.lanes,glanes].forEach(a=>a&&a.forEach((l,j)=>{if(l&&l.kid===kid){if(!n)pushUndo();a[j]=null;n++;}}));
  const m=ui.layer==='track'&&page().key==='macros'&&!ui.shift&&t.routes[k]?k:-1;if(m>=0){if(!n)pushUndo();t.routes[m]=0;t.mdst=t.mdst.map(d=>d===m?-1:d);t.modOff[m]=false;}
  const nm=rnd2(encLabels()[k],t);toast(n&&m>=0?nm+': RECORDING + MOD CLEARED':n?nm+': RECORDING CLEARED':m>=0?nm+': MOD CLEARED':nm+': NOTHING RECORDED OR LINKED');if(n||m>=0)sync();render();}
function recPress(){const t=tracks[ui.sel];
  if(ui.shift){const glob=globalPage(),a=glob?glanes:t.lanes;
    if(!a||!a.some(Boolean)){toast(glob?'GLOBAL: NOTHING RECORDED':`T${ui.sel+1}: NOTHING RECORDED`);return;}
    pushUndo('recclr');if(glob)glanes=Array(LANES).fill(null);else t.lanes=null;
    toast((glob?'GLOBAL':`T${ui.sel+1}`)+' REC CLEARED (UNDO = BACK)');sync();render();return;}
  ui.rec=!ui.rec;ui.recLast=null;toast(ui.rec?(ui.playing?'REC ON: TURN KNOBS':'REC ON: PRESS PLAY, TURN KNOBS'):'REC OFF',2500);render();}
fn.RECB.onclick=recPress;
/* the Sample button (top right, Lef 19 nov): the mic into ONE general buffer, whatever track is selected; again = stop.
   Every SAMPLE track's PLAY pad blinks until it has taken the newest take (the first press takes it, then it is PLAY again). */
/* Lef 19 nov: the take is whole bars so it loops in time: it starts on the next bar (playing), at most 4 bars (as many as fit in 16 s);
   a second press stops it at the end of the bar it is in; RECORDING NOW stays on the screen until it is done */
function genRecPress(){const g=ui.sg||0,busy=!!(g&5);audio.ready&&audio.send({sgr:[busy?0:1]});
  if(!busy){ui.sg=g|(ui.playing?4:1);genShow();}else if(g&4){ui.sg=g&~5;toast('SAMPLE: REC CANCELLED');}else toast('SAMPLE: STOPS AT THE END OF THIS BAR',2500);render();}
function genShow(){const g=ui.sg||0,m=g&4?'SAMPLE: WAIT FOR THE BAR':g&1?'RECORDING NOW':null;
  if(m){ui.toast=m;ui.toastT=performance.now();ui.toastMs=1e9;}else if(ui.toast==='RECORDING NOW'||ui.toast==='SAMPLE: WAIT FOR THE BAR')ui.toast=null;}
fn.REC.onclick=genRecPress;
const genNew=i=>{const g=ui.sg||0;return !!(g&2)&&!(g&5)&&tracks[i].eng===SAMPLE&&!smFile(tracks[i])&&(ui.sgGot||[])[i]!==g>>3;};
/* MENU: a list (ENGINE, PRESETS); jog or + / - picks, jog press (Enter) opens, < (Esc) goes back, MENU closes.
   SHIFT + MENU opens PRESETS straight away. ENGINE: jog, + / - or up / down picks (you hear it at once), Shift = all tracks */
const MENU_ALL=['ENGINE','PRESETS','BUFFER','LOAD','SAVE','SCREENSAVER','MIDI','MOUSE-OVER','MIRROR SCREEN','VERSION'];let MENU_ITEMS=MENU_ALL.slice();   /* the Move leaves out what only works in a browser (postlude) */   /* VERSION: the installed module version, read only (Lef 19 nov) */   /* MIRROR SCREEN: a QR code to the mirror page (Lef 19 nov) */
/* MENU > BUFFER (Lef 22 nov): keep a recording as a WAV in Samples/Recordings; SAVE asks which, RENAME and DELETE work on the kept files */
const BUF_ACTS=[['SAVE','KEEP A RECORDING AS A WAV'],['RENAME','A KEPT RECORDING'],['DELETE','A KEPT RECORDING']];
function bufSrcRows(){const r=[];if((ui.sg||0)&2)r.push({nm:'SAMPLE BUTTON',d:'ITS LAST TAKE',src:'gen'});
  tracks.forEach((t,i)=>{if(t.eng===SAMPLE&&t.smf)r.push({nm:'T'+(i+1)+' SAMPLE',d:'REC / FILE OF TRACK '+(i+1),src:i});});return r;}
function bufPress(){const R=globalThis.efosRecs;
  if(ui.menu==='buffer'){if(!R){toast('ONLY ON THE MOVE');return;}const a=BUF_ACTS[ui.si][0];
    if(a==='SAVE'){if(!bufSrcRows().length){toast('NOTHING RECORDED YET',2000);return;}ui.menu='bufsave';ui.si=0;ui.toast=null;render();return;}
    ui.bufFiles=R.list();if(!ui.bufFiles.length){toast('NOTHING KEPT YET: SAVE FIRST',2000);return;}ui.bufAct=a;ui.menu='buffiles';ui.si=0;ui.confirm=null;ui.toast=null;render();return;}
  if(ui.menu==='bufsave'){const r=bufSrcRows()[ui.si];if(!r)return;ui.menu='buffer';ui.si=0;R.save(r.src,preName());render();return;}
  if(ui.menu==='buffiles'){const n=ui.bufFiles[ui.si];if(n==null)return;
    if(ui.bufAct==='RENAME'){ui.rnFile=n;ui.rnI=null;ui.ri=0;ui.menu='rename';ui.confirm=null;ui.toast=null;render();return;}
    if(ui.confirm!=='bd'+n){ui.confirm='bd'+n;toast('PRESS AGAIN: DELETE '+n,2500);return;}
    ui.confirm=null;if(R.del(n)){toast('DELETED: '+n,2000);ui.bufFiles=R.list();ui.si=Math.min(ui.si,Math.max(0,ui.bufFiles.length-1));if(!ui.bufFiles.length)ui.menu='buffer';}else toast('NOT DELETED',2000);render();}}
function bufRows(){return ui.menu==='buffer'?BUF_ACTS.length:ui.menu==='bufsave'?bufSrcRows().length:(ui.bufFiles||[]).length;}
function menuToggle(v){if(v===undefined&&ui.shift&&ui.menu==='presets'){preActNext();return;}
  if(v===false||(v===undefined&&ui.menu))ui.menu=false;else{ui.menu=ui.shift?'presets':'main';ui.pa=0;}
  ui.confirm=null;ui.toast=null;render();}
/* . opens PRESETS on LOAD (again = close); SHIFT + . opens it, then steps through the actions */
function presetKey(sh){if(ui.menu!=='presets'){ui.menu='presets';ui.pa=0;ui.confirm=null;ui.toast=null;render();return;}
  if(sh)preActNext();else menuToggle(false);}
let PRE_HIDE=new Set();const paVis=()=>PRE_ACTS.map((_,i)=>i).filter(i=>!PRE_HIDE.has(i));   /* the Move hides EXPORT / IMPORT (no files to pick there yet) */
function preActNext(){const V=paVis();ui.pa=V[(Math.max(0,V.indexOf(ui.pa))+1)%V.length];ui.confirm=null;ui.toast=null;render();}   /* SHIFT + . steps round */
/* SHIFT + jog in PRESETS: the action the jog press does; stops at both ends of the list */
function preActBy(d){if(ui.shift)ui.paTurned=true;const V=paVis(),q=Math.max(0,V.indexOf(ui.pa));ui.pa=V[Math.max(0,Math.min(V.length-1,q+d))];ui.confirm=null;ui.toast=null;render();}
function menuBack(){if(ui.menu==='cond'){ui.menu=false;ui.condS=null;toast('NOTHING CHANGED');render();return;}
if(ui.menu==='song'){if(ui.loop)loopStop();ui.menu='presets';ui.toast=null;render();return;}   /* SONG MODE: < goes back and stops the song at once (Lef 20 nov) */
  if(ui.loop){loopStop();render();return;}   /* < stops the PRESET LOOPER first, on every page (Lef 19 nov) */
  if(ui.menu==='clrmod'){ui.menu=false;toast('NOTHING CLEARED');render();return;}
  if(ui.menu==='del'){ui.menu=false;toast('NOTHING DELETED');render();return;}
  if(ui.menu==='ask'){ui.menu='presets';ui.ask=null;toast('NOT OVERWRITTEN');render();return;}
  if(ui.menu==='rename'&&ui.rnFile!=null){ui.rnFile=null;ui.menu='buffiles';ui.toast=null;render();return;}
  if(ui.menu==='bufsave'||ui.menu==='buffiles'){ui.menu='buffer';ui.si=0;ui.confirm=null;ui.toast=null;render();return;}
  if(ui.menu==='looper'||ui.menu==='song'||ui.menu==='rename'){ui.menu='presets';ui.toast=null;render();return;}
  if(ui.menu==='ctl'){ui.menu='midi';ui.si=0;ui.toast=null;render();return;}
  if(ui.menu==='ctlmap'){ui.menu='ctl';ui.si=3;ui.confirm=null;ui.toast=null;render();return;}
  if(ui.menu==='type'){renameDo(typeStr());return;}   /* TYPE: < = done */
  if(ui.menu==='files'&&ui.fdir){const was=ui.fdir.split('/').pop();ui.fdir=ui.fdir.split('/').slice(0,-1).join('/');ui.flist=globalThis.efosFiles?globalThis.efosFiles.list(ui.fdir):[];ui.fi=Math.max(0,ui.flist.findIndex(x=>x.dir&&x.n===was));render();return;}   /* LOAD: < = up a folder, at the top it closes */
  if(ui.menu==='files'){ui.menu=false;ui.toast=null;render();return;}
  ui.saveTo=false;ui.menu=ui.menu==='main'||!ui.menu?false:'main';ui.confirm=null;ui.toast=null;render();}
function menuMove(d){if(ui.menu==='engine')engBy(d);
  else if(ui.menu==='rename'){ui.ri=Math.max(0,Math.min(RN_LIST.length,ui.ri+d));ui.toast=null;render();}
  else if(ui.menu==='type')typeBy(d);
  else if(ui.menu==='song'){if(ui.shift&&ui.sr<presets.song.rows.length){songTurn(1,d);return;}ui.sr=Math.max(0,Math.min(presets.song.rows.length,ui.sr+d));ui.toast=null;render();}   /* SHIFT + jog = TIMES of the row (Lef 20 nov) */
  else if(ui.menu==='cond'||ui.menu==='clrmod'||ui.menu==='del'||ui.menu==='ask'||ui.menu==='power'){const n=ui.menu==='cond'?COND_N.length:ui.menu==='del'?DEL_ROWS.length:ui.menu==='clrmod'?clrModRows().length:ui.menu==='ask'?2:(ui.pw||[]).length;ui.si=Math.max(0,Math.min(n-1,ui.si+d));ui.toast=null;render();}
  else if(ui.menu==='buffer'||ui.menu==='bufsave'||ui.menu==='buffiles'){ui.si=Math.max(0,Math.min(bufRows()-1,ui.si+d));ui.confirm=null;ui.toast=null;render();}
  else if(ui.menu==='files'){ui.fi=Math.max(0,Math.min((ui.flist||[]).length-1,ui.fi+d));ui.toast=null;render();}
  else if(ui.menu==='main'){ui.mi=Math.max(0,Math.min(MENU_ITEMS.length-1,ui.mi+d));render();}
  else if(ui.menu==='presets'){if(ui.shift){preActBy(d);return;}ui.pi=Math.max(0,Math.min(PRESET_N-1,ui.pi+d));ui.confirm=null;ui.toast=null;render();}
  else if(ui.menu==='screensaver'||ui.menu==='midi'||ui.menu==='ctl'){const rows=setRows();if(ui.shift){setBy(rows[ui.si],d);return;}ui.si=Math.max(0,Math.min(rows.length-1,ui.si+d));ui.toast=null;render();}
  else if(ui.menu==='ctlmap'){ui.si=Math.max(0,Math.min(ctlMapRows().length-1,ui.si+d));ui.confirm=null;ui.toast=null;render();}}
function jogPress(){if(ui.menu==='cond'){condSet();return;}if(ui.menu==='del'){delMenuGo();return;}if(ui.menu==='clrmod'){const r=clrModRows()[ui.si];ui.menu=false;if(r)r.go();render();return;}
  if(ui.menu==='ask'){const A=ui.ask;ui.menu='presets';ui.ask=null;if(A&&ui.si===1)A.yes();else{toast('NOT OVERWRITTEN');render();}return;}
  if(ui.menu==='power'){return;}
  if(ui.menu==='main'){const it=MENU_ITEMS[ui.mi];ui.toast=null;ui.si=0;
    if(it==='LOAD'){ui.loadOne=true;importInput.click();toast('PICK AN EFOS FILE ON YOUR COMPUTER',2500);return;}
    if(it==='MOUSE-OVER'){set.tips=!set.tips;setSave();if(!set.tips)tipHide();toast('MOUSE-OVER '+(set.tips?'ON':'OFF'));return;}   /* the labels on pads, knobs and buttons */
    if(it==='MIRROR SCREEN'){if(!globalThis.efosMirror){toast('ONLY ON THE MOVE');return;}const u=globalThis.efosMirror.url(),on=globalThis.efosMirror.on&&globalThis.efosMirror.on();ui.mir={url:u,own:true,qr:globalThis.efosMirror.qr(u)};ui.menu='mirror';if(on)toast('MIRROR DISPLAY ON');render();return;}
    if(it==='VERSION'){if(!globalThis.efosPower){return;}ui.pw=globalThis.efosPower();ui.si=0;ui.menu='power';render();return;}   /* test: which power / battery files the Move has (Lef 19 nov) */
    if(it==='SAVE'){ui.menu='presets';ui.pa=3;ui.saveTo=true;ui.confirm=null;render();return;}
    ui.menu=it.toLowerCase();if(it==='MIDI'&&audio.mode!=='MOVE')midiInit(true);render();}
  else if(ui.menu==='screensaver'||ui.menu==='midi'||ui.menu==='ctl'){const r=setRows()[ui.si];if(r.go)r.go();else setBy(r,1);}
  else if(ui.menu==='ctlmap')ctlMapPress();
  else if(ui.menu==='engine'||ui.menu==='mirror')menuToggle(false);
  else if(ui.menu==='presets')presetAct();
  else if(ui.menu==='looper')loopToggle();
  else if(ui.menu==='rename')renamePick();
  else if(ui.menu==='type')typeNext();
  else if(ui.menu==='song')songJog();
  else if(ui.menu==='files')smFilePick();
  else if(ui.menu==='buffer'||ui.menu==='bufsave'||ui.menu==='buffiles')bufPress();}
function engBy(d){const n=ENG_ORD.length,e=ENG_ORD[Math.max(0,Math.min(n-1,engPos(tracks[ui.sel].eng)+d))],list=ui.shift?tracks:[tracks[ui.sel]];
  pushUndo('eng');list.forEach(t=>engApply(t,e===1&&isTex(t)?t.eng:e));render();}   /* TEX keeps its MODE */
function engApply(t,e){{if(isSyn(t)&&e!==CHORD&&e!==SHARK)t.v.macros[6]=0;   /* their NOISE knob was CHORUS / DRIVE */
    if(e===SHARK&&t.eng!==SHARK){sharkSound(t);t.v.macros[0]=toV(1,P_OCTS);}if(e===HIVE&&t.eng!==HIVE)hiveSound(t);if(e===NEBULA&&t.eng!==NEBULA)nebSound(t);if(e===THUMP&&t.eng!==THUMP)thumpSound(t);if(e===CHORD&&t.eng!==CHORD)chordSound(t);if(e===MATTER&&t.eng!==MATTER)matterSound(t);if(e===HANDS&&t.eng!==HANDS)handsSound(t);if(e===SOPHIE&&t.eng!==SOPHIE)sophieSound(t);if(e===SNARE&&t.eng!==SNARE)snareSound(t);if(e===SAMPLE&&t.eng!==SAMPLE)smSound(t);if((e===WAVE||e===WDRUM)&&t.eng!==e){t.eng=e;wtSound(t);}if(e===TANK&&t.eng!==TANK){t.eng=e;tkSound(t);}if(e===SID&&t.eng!==SID){t.eng=e;sidSound(t);}t.eng=e;}}
fn.MENU.onclick=()=>menuToggle();fn.BACK.onclick=()=>menuBack();
/* ---------- SETTINGS (this browser): screensaver and MIDI ---------- */
const SAVERS=['INTRO','STARS','BOOT'],WAITS=[0,1,5,25];   /* WAIT in minutes, 0 = off */
const set=Object.assign({tips:true,saver:0,wait:2,midiIn:'',midiOut:'',clkOut:false,ch:[1,2,3,4,5,6,7,8]},(()=>{try{return JSON.parse(localStorage.getItem('efs-settings-v1')||'{}');}catch(e){return{};}})());
const setSave=()=>{try{localStorage.setItem('efs-settings-v1',JSON.stringify(set));}catch(e){}};
const waitShow=()=>WAITS[set.wait]?WAITS[set.wait]+' MIN':'OFF';
function setRows(){if(ui.menu==='ctl')return ctlRows();if(ui.menu==='screensaver')return[
    {nm:'SAVER',val:()=>SAVERS[set.saver],by:d=>{set.saver=(set.saver+d+SAVERS.length)%SAVERS.length;}},
    {nm:'WAIT',val:waitShow,by:d=>{set.wait=(set.wait+d+WAITS.length)%WAITS.length;}},
    {nm:'PREVIEW',val:()=>'PRESS',go:()=>saverStart()}];   /* runs until the next press or turn */
  const io=(key,list)=>({nm:key==='midiIn'?'INPUT':'OUTPUT',val:()=>!midi.acc?'N/A':set[key]?short(midiName(list(),set[key])):'OFF',
    by:d=>{const ids=['',...list().map(p=>p.id)];set[key]=ids[(ids.indexOf(set[key])+d+ids.length)%ids.length]||'';midiBind();}});
  return[...(audio.mode==='MOVE'?[{nm:'CLOCK OUT',val:()=>set.clkOut?'ON':'OFF',by:()=>{set.clkOut=!set.clkOut;audio.send({co:set.clkOut?1:0});}},{nm:'CLOCK SENT',val:()=>ui.mco||'-'}]:[]),   /* MIDI clock out: on the Move only (USB-A); CLOCK SENT = what the host took */
    ...(audio.mode==='MOVE'?[]:[io('midiIn',()=>midi.ins),io('midiOut',()=>midi.outs)]),   /* ports: Web MIDI only; the Move has one USB-A port */...tracks.map((_,i)=>({nm:'T'+(i+1)+' CHANNEL',val:()=>String(set.ch[i]),by:d=>{set.ch[i]=(set.ch[i]-1+d+16)%16+1;}})),
    {nm:'CONTROLLER',val:()=>CTL_DEV[ctlSet().dev]+(ui.ctlE16?' E16 ON':''),go:()=>{ui.menu='ctl';ui.si=0;ui.toast=null;render();}}];}   /* a MIDI controller on USB-A (Lef 19 nov) */
/* ---------- MIDI CONTROLLER on USB-A (Lef 19 nov): FOLLOW = its knobs 1-8 are the 8 knobs on screen, 9-16 the same with SHIFT;
   LEARN = touch an EFOS knob and turn a controller knob: that knob keeps that function on every page. AUTO / E16 / EC4: CC 1-16 on channel 1, relative
   (the OXI E16 in remote mode, which EFOS asks for itself; the EC4 set once with Schwung's EC4 Setup). OTHER: any CC, absolute, only what is learned. ---------- */
const CTL_DEV=['AUTO','EC4','E16','OTHER'];
function ctlSet(){if(!set.ctl||typeof set.ctl!=='object')set.ctl={dev:0,fol:true,learn:false,map:{}};if(!set.ctl.map)set.ctl.map={};return set.ctl;}
function ctlRows(){const C=ctlSet();return[
    {nm:'DEVICE',val:()=>CTL_DEV[C.dev],by:d=>{C.dev=(C.dev+d+CTL_DEV.length)%CTL_DEV.length;ui.ctlLast={};}},
    {nm:'FOLLOW',val:()=>C.dev===3?'----':C.fol?'ON':'OFF',by:()=>{C.fol=!C.fol;}},
    {nm:'LEARN',val:()=>C.learn?'ON':'OFF',by:()=>{C.learn=!C.learn;}},
    {nm:'LEARNED',val:()=>String(Object.keys(C.map).length),go:()=>{ui.menu='ctlmap';ui.si=0;ui.toast=null;render();}},
    {nm:'E16',val:()=>ui.ctlE16?'CONNECTED':C.dev===0||C.dev===2?'SEARCHING':'----'}];}
function ctlMapRows(){const C=ctlSet();return[...Object.keys(C.map).map(key=>{const b=C.map[key];return{nm:'CC '+key.split(':')[1]+(key[0]!=='1'?' CH'+key.split(':')[0]:''),val:()=>b.n,key};}),{nm:'CLEAR ALL',val:()=>'PRESS',all:1}];}
function ctlMapPress(){const C=ctlSet(),r=ctlMapRows()[ui.si];if(!r)return;
  if(r.all){if(ui.confirm!=='ctlclr'){ui.confirm='ctlclr';toast('PRESS AGAIN: CLEAR ALL',3000);return;}ui.confirm=null;C.map={};setSave();toast('LEARNED CLEARED',2000);ui.si=0;render();return;}
  if(ui.delHeld){ui.delUsed=true;delete C.map[r.key];setSave();ui.si=Math.max(0,ui.si-1);toast('REMOVED',1500);render();return;}
  toast('DEL + JOG PRESS REMOVES IT',2000);}
/* one knob turn from the controller: on the page on screen (FOLLOW) or on the page it was learned on */
function ctlTurn(b,d){if(!b){turn(ctlK.k,d);return;}
  const sv={cat:ui.cat,cp:ui.cp.slice(),layer:ui.layer,enc:Object.assign({},ui.enc),sh:ui.shift,menu:ui.menu},view=ui.cat===b.c&&ui.cp[b.c]===b.p&&!!ui.shift===!!b.s&&!ui.menu;
  if(view){turn(b.k,d);return;}
  let info=null;try{ui.menu=false;goPage(b.c,b.p);ui.shift=!!b.s;turn(b.k,d);info=knobInfo(b.k,{});}
  finally{ui.cat=sv.cat;ui.cp=sv.cp;ui.layer=sv.layer;ui.enc=sv.enc;ui.shift=sv.sh;ui.menu=sv.menu;}
  if(info)toast(rnd2(info.lab,tracks[ui.sel])+' '+info.txt,1200);render();}
const ctlK={k:0};
function ctlMidi(st,d1,d2){const C=ctlSet(),ty=st&0xf0,ch=(st&15)+1;if(!ui.ctlLast)ui.ctlLast={};
  if(ty===0x90||ty===0x80){if(d1===16&&ch===1&&C.dev!==3)setShift(ty===0x90&&d2>0);return;}   /* E16 / EC4 SHIFT note */
  if(ty!==0xb0)return;
  const key=ch+':'+d1,rel=C.dev!==3&&ch===1&&d1>=1&&d1<=16;let d;
  if(rel)d=d2<64?d2:d2-128;else{const o=ui.ctlLast[key];ui.ctlLast[key]=d2;if(o==null)return;d=d2-o;}
  if(!d)return;ui.lastIn=performance.now();
  if(C.learn&&typeof ui.held==='number'&&!ui.menu){const sp=kSpec(ui.held);if(sp){const inf=knobInfo(ui.held,{});
      C.map[key]={c:ui.cat,p:ui.cp[ui.cat],k:ui.held,s:ui.shift?1:0,n:rnd2(inf.lab,tracks[ui.sel])+(ui.shift?' (SH)':'')};setSave();toast('LEARNED: CC '+d1+' > '+C.map[key].n,2000);}}
  const b=C.map[key];if(b){ctlTurn(b,d);return;}
  if(rel&&C.fol){const k=(d1-1)%8,sh=d1>8;if(sh===!!ui.shift){turn(k,d);return;}const s0=ui.shift;ui.shift=sh;try{turn(k,d);}finally{ui.shift=s0;}render();}}
function setBy(r,d){if(!r||!r.by){if(r&&r.go)r.go();return;}r.by(d);setSave();ui.toast=null;render();}
const short=s=>{s=String(s).toUpperCase();while(s.length&&tw(s)>58)s=s.slice(0,-1);return s;};
/* SCREENSAVER: after WAIT without input the screen plays SAVER; the first touch only wakes it */
ui.lastIn=performance.now();
function saverStart(ty,once){ui.saver={t0:performance.now()-(once&&ty==='INTRO'?2500:0),ty,once};   /* the start-up INTRO opens on the EFOS logo, no stars first (Lef 17 nov) */const f=()=>{if(!ui.saver)return;draw();requestAnimationFrame(f);};requestAnimationFrame(f);}
function saverWake(){ui.saver=null;ui.lastIn=performance.now();render();}
['pointerdown','keydown','wheel'].forEach(ev=>document.addEventListener(ev,e=>{ui.lastIn=performance.now();
  if(ui.saver&&!(ev==='keydown'&&e.repeat)){e.stopPropagation();if(ev!=='wheel')e.preventDefault();saverWake();}},{capture:true,passive:false}));
setInterval(()=>{const w=WAITS[set.wait];if(!ui.saver&&w&&performance.now()-ui.lastIn>w*60000)saverStart();},1000);
function drawSaver(){const T=(performance.now()-ui.saver.t0)/1000,ty=ui.saver.ty||SAVERS[set.saver];if(ui.saver.once&&T>=14){saverWake();return draw();}   /* once: the start-up INTRO, one run */x.fillStyle='#000';x.fillRect(0,0,128,64);x.fillStyle='#fff';
  if(ty==='BOOT')return saverBoot(T);
  const L=ty==='INTRO'?14:1e9,t=T%L;stars(T,ty==='STARS'||t<6?1:.35,ty==='INTRO'&&t>=4?43:64);if(ty==='INTRO')saverIntro(t);}
const STARS=[...Array(60)].map((_,i)=>[(Math.sin(i*12.9898)*43758.5453)%1,(Math.sin(i*78.233)*12543.37)%1,((Math.sin(i*3.17)*9631.1)%1+1)%1]);
function stars(T,a,maxY){STARS.forEach(([sx,sy,z0])=>{const z=1-((z0+T*.25*a)%1),k=.12/(z+.04),px=64+sx*k*90,py=32+sy*k*45;
  if(z>.75||px<0||px>127||py<0||py>=maxY)return;const s=z<.25?2:1;x.fillRect(Math.round(px),Math.round(py),s,s);});}
/* the 80s film opening: a grid to the horizon, EFOS flies in, a shine runs over it, TERMINAL types itself, then a scanline wipe */
function saverIntro(t){
  if(t>=4){const hz=44;x.fillRect(0,hz,128,1);for(let k=-4;k<=4;k++)line(64+k*3,hz+1,64+k*15,63);   /* a few steep rays: clean steps */
    const off=(t*.8)%1;for(let j=0;j<4;j++){const f=(j+off)/4,y=hz+1+Math.round(19*f*f);if(y>=hz+3&&y<64)x.fillRect(0,y,128,1);}}   /* rows come closer towards the horizon */
  if(t>=2.5){const u=Math.min(1,(t-2.5)/2),e=1-Math.pow(1-u,3),k=1+4*e,w=Math.round(tw('EFOS')*k),X=64-Math.round(w/2),Y=Math.round(24-3*k)-(u>=1?2:0);
    x.fillStyle='#000';x.fillRect(X-2,Y-2,w+4,Math.round(5*k)+4);x.fillStyle='#fff';glyphsZ('EFOS',X,Y,k);   /* grows a pixel at a time, easing out */
    if(u>=1){x.fillStyle='#000';for(let r=Y+13;r<Y+25;r+=2)x.fillRect(X,r,w,1);x.fillStyle='#fff';   /* chrome stripes in the lower half */
      if(t>5&&t<6.4){const q=(t-5)/1.4,v=q*q*(3-2*q),sx=X-24+v*(w+48);x.globalCompositeOperation='xor';   /* the shine: a wide and a thin band */
        for(let r=0;r<25;r++){const o=Math.round(sx+r*.45);x.fillRect(o,Y+r,4,1);x.fillRect(o+7,Y+r,1,1);}x.globalCompositeOperation='source-over';}
      sparkle(t-6.2,X+w-1,Y,1);sparkle(t-6.75,X+2,Y+24,.6);}}
  if(t>=7){const s='TERMINAL',n=Math.min(s.length,Math.floor((t-7)*5)),tx=s.slice(0,n),X=64-Math.round(tw(s+' >_')/2);
    x.fillStyle='#000';x.fillRect(X-2,34,tw(s+' >_')+4,9);x.fillStyle='#fff';glyphs(x,tx,X,36);if(n===s.length)glyphs(x,' >',X+tw(s),36);if(Math.floor(t*2)%2)x.fillRect(X+tw(n===s.length?s+' >':tx)+2,40,4,1);}
  if(t>=12.5){const k=Math.floor((t-12.5)/1.5*32);x.fillStyle='#000';for(let r=0;r<64;r+=2)x.fillRect(0,r,128,1);for(let r=1;r<64;r+=2)if(r/2<k)x.fillRect(0,r,128,1);x.fillStyle='#fff';}}
/* EFOS at any size, every glyph pixel on whole screen pixels: the zoom grows smoothly and stays sharp */
function glyphsZ(str,X,Y,k){let cx=0;for(const c of str){const g=glyph(c);
  for(let r=0;r<g[3];r++){const row=g[4+r],y0=Y+Math.round((g[1]+r)*k),y1=Y+Math.round((g[1]+r+1)*k);
    for(let b=0;b<g[2];b++)if(row>>b&1){const x0=X+Math.round((cx+b)*k),x1=X+Math.round((cx+b+1)*k);x.fillRect(x0,y0,x1-x0,y1-y0);}}cx+=g[0];}}
/* a cartoon glint: a four-point star that turns while its points grow long and shrink back; t = 0..1 s, s = size */
function sparkle(t,cx,cy,s){if(t<0||t>1)return;const g=Math.sin(Math.PI*t),L=Math.round(13*s*g*g+1),a=t*Math.PI*.6;
  for(let i=0;i<4;i++){const c=Math.cos(a+i*Math.PI/2),d=Math.sin(a+i*Math.PI/2),c2=Math.cos(a+Math.PI/4+i*Math.PI/2),d2=Math.sin(a+Math.PI/4+i*Math.PI/2);
    line(cx,cy,Math.round(cx+c*L),Math.round(cy+d*L));if(L>5)line(cx,cy,Math.round(cx+c2*L*.35),Math.round(cy+d2*L*.35));}
  x.fillRect(cx-1,cy,3,1);x.fillRect(cx,cy-1,1,3);}
function line(x0,y0,x1,y1){const n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0));for(let i=0;i<=n;i++){const px=Math.round(x0+(x1-x0)*i/n),py=Math.round(y0+(y1-y0)*i/n);if(px>=0&&px<128&&py>=0&&py<64)x.fillRect(px,py,1,1);}}
function saverBoot(T){const L=['EFOS TERMINAL','','> BOOT','> CHECK CORE .... OK','> CHECK CORE ... OK','> 8 TRACKS ..... OK',...tracks.map((t,i)=>`  T${i+1} ${ENGINES[t.eng]}`),`> TEMPO ${bpm.toFixed(1)}`,`> ${ui.playing?'PLAYING':'STOPPED'}`,'> READY'];
  const chars=Math.floor(T*14)%(L.join('').length+60);let left=chars,out=[];for(const l of L){if(left<=0)break;out.push(l.slice(0,left));left-=l.length;}
  const vis=out.slice(-7);vis.forEach((l,i)=>txt(l,2,2+i*8));const last=vis[vis.length-1]||'';if(Math.floor(T*2)%2)x.fillRect(2+tw(last)+2,2+(vis.length-1)*8+4,4,1);}
/* ---------- MIDI (Web MIDI, where the browser allows it): notes in play a track on its channel, hits go out as notes ---------- */
const midi={acc:null,ins:[],outs:[],asked:false};
const midiName=(list,id)=>(list.find(p=>p.id===id)||{name:'GONE'}).name;
function midiInit(ask){if(midi.acc||midi.asked&&!ask)return;midi.asked=true;
  if(!navigator.requestMIDIAccess){if(ask)toast('MIDI NOT AVAILABLE IN THIS BROWSER',2500);return;}
  try{midi.acc=navigator.requestMIDIAccess();midi.acc.onstatechange=()=>{midiList();render();};midiList();render();}catch(e){if(ask)toast('MIDI NOT ALLOWED HERE',2500);}}
function midiList(){midi.ins=[...midi.acc.inputs.values()];midi.outs=[...midi.acc.outputs.values()];midiBind();}
function midiBind(){if(!midi.acc)return;midi.ins.forEach(p=>p.onmidimessage=p.id===set.midiIn?midiIn:null);}
function midiIn(e){const[st,no,vel]=e.data,ch=(st&15)+1;
  if(st===0xF8||st===0xFA||st===0xFB||st===0xFC){audio.ready&&audio.send({rt:st});return;}   /* MIDI clock in: the core follows it (efs_midi_rt) */
  if((st&240)!==144||!vel)return;
  tracks.forEach((t,i)=>{if(set.ch[i]===ch&&!silent(t)){audio.ready&&audio.send({trig:[i,vel/127]});hitMark(i,performance.now());}});hitOff();}
function midiOut(hits){const o=midi.acc&&set.midiOut&&midi.acc.outputs.get(set.midiOut);if(!o)return;
  tracks.forEach((t,i)=>{if(!(hits>>i&1))return;const ch=set.ch[i]-1,n=Math.max(0,Math.min(127,pMel(t)?48+Math.round(semis(t,Math.max(0,ui.ppos[i]))):36+i));
    try{o.send([144|ch,n,100]);o.send([128|ch,n,0],performance.now()+80);}catch(e){}});}
if(set.midiIn||set.midiOut)setTimeout(()=>midiInit(false),500);
/* ---------- PRESETS: 64 slots of the whole state except the volume ----------
   Stored per viewer in the host's database when there is one, else in this browser.
   A load waits for the next bar so the music runs on; EXPORT / IMPORT move all slots as one .json file. */
const PRESET_N=64,PRE_ACTS=['LOAD','PATTERNS ONLY','SOUNDS ONLY','OVERWRITE','RENAME','INIT','PRESET LOOPER','SONG MODE','EXPORT','IMPORT','CLEAN UP','DELETE'],REN_A=4,INIT_A=5,LOOP_A=6,SONG_A=7,EXP_A=8,IMP_A=9,CLEAN_A=10,DEL_A=11;   /* RENAME, SONG MODE: own screens (Lef 19 nov) */   /* DELETE stays at the bottom */
const LOOP_BARS=[1,2,4,8,16]; /* PRESET LOOPER: BARS each preset plays (presets.main), bars of 16 steps */
const NAME_A=['RUST','IRON','PALE','DEEP','COLD','SOFT','DUST','GLASS','NEON','STATIC','LUNAR','HOLLOW','SILVER','MOSS','ASH','VOLT'];
const NAME_B=['ORBIT','DRIFT','PULSE','SIGNAL','ECHO','COMET','RELAY','VAULT','SPORE','NOVA','GRAIN','TIDE','FLARE','HALO','PRISM','SWARM'];
const PAT_KEYS=['oto','cond','len','span','unit','gen','dens','rot','grv','roln','rold','fillT','fillSeed','altT','altEv','fillEv','steps','gmem','pmem','pkey','pdeg','pcent'],PAT_V=['pat','pitch','lis','lch','lm'];
const presets={names:Array(PRESET_N).fill(null),lens:Array(PRESET_N).fill(null),main:4,lp:{from:0,to:-1,rep:10},song:{rows:[],end:0},cache:{},db:null,uid:null,where:'BROWSER',queue:Promise.resolve()};
const preName=()=>NAME_A[Math.floor(rnd()*NAME_A.length)]+' '+NAME_B[Math.floor(rnd()*NAME_B.length)];
/* older saved tracks: fill in fields that were added later */
/* states from before v101: one STUTTER for all; every track takes it, with its own DIV as its LENGTH */
/* s = the stored shared STUTTER: 9 values before v102 (its MIX was for all), 7 since */
function stuMig(x,s){if(x&&x.v&&x.v.stu&&x.v.stu.length===7){x.v.stu=stu107(x.v.stu);return;}if(!x||!x.v||(x.v.stu&&x.v.stu.length===10))return;const old=s&&s.length===9;
  if(!x.v.stu){if(!old){x.v.stu=(s||STU0).slice(0,7);return;}x.v.stu=stuOf(s);const dv=x.v.sdiv?fromV(x.v.sdiv[0],11):0;if(dv>0)x.v.stu[0]=toV(dv-1,10);}   /* before v101 */
  x.v.stu=stu107(stuNew(x.v.stu,old?s[6]:127));}
const stutMig=d=>{(d.tracks||[]).forEach(x=>stuMig(x,d.stutShared));if(d.stutShared&&d.stutShared.length===9)d.stutShared=stuNew(stuOf(d.stutShared),d.stutShared[6]);if(d.stutShared&&d.stutShared.length===7)d.stutShared=stu107(d.stutShared);};
/* v111: FX.ENV, SND.V and P.RND left PERF and SWING came in (old perf had 10 values); recorded global knobs follow their new place */
const G_OLD=i=>i<3?i:i===3||i===35?-1:i===4?3:i<35?i-1:i-2,PERF_KID={5:4,6:5,7:6};
function perfMig(d){const p=d.perf;if(!p||p.length!==10)return;d.perf=[p[0],p[1],p[2],0,p[5],p[6],p[7],p[8]];
  if(d.glanes)d.glanes=d.glanes.map(l=>{if(!l)return null;const q=G_OLD(l.p);if(q<0)return null;l.p=q;
    const m=/^perf\/perf\/(\d)\/(\d)$/.exec(l.kid||'');if(m&&PERF_KID[m[2]]!=null)l.kid=`perf/perf/${m[1]}/${PERF_KID[m[2]]}`;return l;});}
/* v111: the core lost LFO3 (params 20, 21 and 42, route bit 2): recorded lanes and links move down */
const P_OLD=i=>i<20?i:i<22?-1:i<42?i-2:i===42?-1:i-3;
/* v113: VAR.2 has 2 levels, VAR.1 is new, FILL.M is gone; VAR.D became bipolar (middle = off) */
function fillMig(x){if(!x||x.fv)return;x.fillT=0;x.altT=0;delete x.fillM;if(x.v)x.v.vd=[64];x.fv=2;}
function lfo3Mig(x){if(!x||x.lf)return;delete x.envMode;
  if(x.lanes)x.lanes=x.lanes.map(l=>{if(!l)return null;const q=P_OLD(l.p);if(q<0)return null;l.p=q;return l;});
  if(x.routes)x.routes=x.routes.map(m=>(m&3)|((m>>3)<<2));x.lf=2;}
function migTracks(a){(a||[]).forEach(x=>{if(x)x.rpt=0;
  if(x&&!x.l128){if(x.v&&x.v.pitch)x.v.pitch[4]=Math.round(x.v.pitch[4]/127*63);if(x.v&&x.v.pat&&x.len)x.v.pat[6]=x.len-1;x.l128=1;}   /* 128 steps (Lef 25 nov): LENGTH and PITCH LENGTH knobs are now length - 1 */
  if(x){['pdeg','pcent'].forEach(k=>{if(Array.isArray(x[k]))while(x[k].length<MAXS)x[k].push(0);});['slR','acR'].forEach(k=>{if(Array.isArray(x[k]))while(x[k].length<MAXS)x[k].push(Math.random());});if(Array.isArray(x.steps))while(x.steps.length<MAXS)x.steps.push(false);(x.lanes||[]).forEach(l=>{if(l)['v','u'].forEach(k=>{if(Array.isArray(l[k]))while(l[k].length<MAXS)l[k].push(-1);});});}
  if(x&&!x.mdst)x.mdst=[0,1,2,3,4].map(b=>(x.routes||[]).findIndex(r=>r>>b&1));   /* v118: one destination per source (the first linked macro) */
  if(x&&x.mdst&&x.mdst.length<6)while(x.mdst.length<6)x.mdst.push(-1);   /* LFO 3 (Lef 22 nov): a sixth source */
  if(x&&!x.lhz)x.lhz=[!!(x.v&&x.v.hz&&x.v.hz[0]),!!(x.v&&x.v.hz&&x.v.hz[1])];
  if(x&&x.v&&!x.v.rsm)x.v.rsm=[x.rsmooth&&x.rsmooth[0]?76:0,x.rsmooth&&x.rsmooth[1]?76:0];
  if(x&&x.v&&x.v.pitch&&x.v.fol&&!x.rv){const v=x.v.pitch[2];if(fromV(x.v.fol[0],8)>0)x.v.pitch[2]=v===0?127:1+Math.round(Math.round((v-1)/126*11)/11*125);x.rv=2;}   /* FOLLOW RANGE: 0 was FULL, now FULL is on the right */if(x&&(x.gen===1||x.gen===3||x.gen===5))x.gen=4;   /* PROB, CA and HAND left ALGO: their steps stay, under GROOVES */
  if(x&&x.v){if(!x.v.sc)x.v.sc=SC0();if(!x.v.eq)x.v.eq=[64,64];if(!x.v.rtu)x.v.rtu=[0];if(!x.v.vp)x.v.vp=[0];if(!x.v.vd)x.v.vd=[64];if(!x.v.tu)x.v.tu=[0];if(!x.v.key)x.v.key=KEY0();if(!x.v.shc)x.v.shc=[0];if(!x.v.cs)x.v.cs=CS0();if(!x.v.sm)x.v.sm=SM0();while(x.v.cs.length<9)x.v.cs.push(0);if(!x.v.tat)x.v.tat=[0];if(!x.v.gdr)x.v.gdr=[0];if(!x.v.nf)x.v.nf=[64];if(!x.v.cha)x.v.cha=[127];if(!x.v.chs)x.v.chs=[0];}if(x&&x.v&&x.v.tn&&!x.tv){x.v.tn=[fromV(x.v.tn[0],3)>=1?toV(1,2):toV(0,2)];x.tv=2;}   /* TUNE lost SCALE: it becomes SEMI */
  if(x&&x.v&&x.v.pitch&&!x.pv){x.v.pitch[5]=0;x.pv=2;}   /* GEN became TURING: stored melodies load locked */
  if(x&&x.v&&!x.v.fol){x.v.fol=[0];x.v.hrm=[toV(1,HARMS.length)];}
  if(x&&x.v)stuMig(x,null);
  if(x&&Array.isArray(x.mot)){x.lanes=Array(16).fill(null);x.mot.forEach((m,k)=>{if(m)x.lanes[k]={p:k,kid:'track/macros/0/'+k,v:m.map(v=>v<0?-1:v/127),u:m.slice()};});delete x.mot;}if(x&&x.v){if(!x.v.sl)x.v.sl=[0];if(!x.v.ac)x.v.ac=[0];if(!x.v.edp)x.v.edp=[64];if(!x.v.hz)x.v.hz=[0,0];if(!x.v.gx)x.v.gx=GX0();if(x.v.gx.length===4)x.v.gx=[x.v.gx[0],x.v.gx[1]>=64?127:0,x.v.gx[2],x.v.gx[3]>=64?127:0,0,0,0,0];
    if(!x.gr){x.v.gx[0]=x.v.gx[2]=64;x.v.gx[5]=x.v.gx[7]=0;(x.slot||[]).forEach((ty,k)=>{if(ty===GRAIN&&x.v.fx){x.v.fx[k*4+1]=grOldDens(x.v.fx[k*4+1]);x.v.fx[k*4+2]=grOldPitch(x.v.fx[k*4+2]);}});x.gr=2;}   /* GRAIN became Clouds */if(!x.v.gate)x.v.gate=[64];if(!x.v.cv)x.v.cv=[48];if(!x.v.cc)x.v.cc=[48];if(!x.v.chp)x.v.chp=[48];if(!x.v.crv)x.v.crv=[0];if(!x.v.pe)x.v.pe=[0];if(!x.v.fo)x.v.fo=[0];if(!x.v.st)x.v.st=[0];if(!x.v.tn)x.v.tn=[0];
    if(!x.dv&&x.v.macros){const dr=!!x.eng&&x.eng!==ACID,sec=(lv,f)=>lv&&(lv.v=lv.v.map(q=>q<0?q:f(Math.round(q*127))/127),lv.u=lv.u.map(q=>q<0?q:f(q)));   /* the old DECAY / ATTACK knob: convert once */
      if(x.eng!==ACID){x.v.macros[1]=decN(x.v.macros[1],dr);if(x.home)x.home[1]=decN(x.home[1],dr);}if(x.v.att)x.v.att=[attN(x.v.att[0])];
      (x.lanes||[]).forEach(l=>{if(l&&l.p===1&&x.eng!==ACID)sec(l,v=>decN(v,dr));if(l&&l.p===58)sec(l,attN);});x.dv=2;}}if(x&&x.v&&x.v.macros&&!x.v.col){x.v.col=[x.v.macros[2]];x.v.macros=x.v.macros.slice();x.v.macros[2]=64;if(x.home)x.home[2]=64;}
  if(x&&x.v&&x.v.macros&&!x.syn){const m=x.v.macros;x.v.fa=[0];x.v.pw=[0];   /* J60 and ACID got the synth layout: RESO on knob 4, the filter envelope on knob 5 */
    if(x.eng===CHORD){const reso=x.v.col[0];x.v.pw=[m[3]];x.v.col=[Math.round(64+m[4]*63/127)];m[3]=reso;m[4]=m[1];x.v.fa=[x.v.att?x.v.att[0]:0];m[6]=x.v.cc?x.v.cc[0]:48;}
    if(x.eng===ACID){const reso=x.v.col[0];x.v.pw=[m[3]];x.v.col=[m[4]];m[3]=reso;m[4]=m[1];}
    if(x.home)x.home=m.slice();x.syn=2;}
  if(x&&x.v&&x.v.macros&&!x.nb){if(x.eng===NEBULA){const pos=x.v.col[0],mv=a=>[a[0],a[1],pos,a[2],a[3],...a.slice(5)];   /* NEBULA got POS on knob 3, TEX under Shift + knob 5 */
      x.v.col=[x.v.macros[4]];if(x.home)x.home=mv(x.home);x.v.macros=mv(x.v.macros);
      const sh=(a,z)=>[a[0],a[1],z,a[2],a[3],...a.slice(5)];if(x.routes)x.routes=sh(x.routes,0);if(x.modOff)x.modOff=sh(x.modOff,false);
      const K={'0/2':['0/3',3],'0/3':['0/4',4],'0/4':['1/4',66],'1/2':['0/2',2],'1/4':['1/5',87],'1/5':['1/6',82],'1/6':['1/2',75]};
      (x.lanes||[]).forEach(l=>{const q=l&&K[l.kid.replace('track/macros/','')];if(q){l.kid='track/macros/'+q[0];l.p=q[1];}});}
    x.nb=2;}
  if(x&&x.v&&x.v.macros&&!x.th){if(x.eng===THUMP&&x.v.cv&&fromV(x.v.cv[0],8)===3&&x.v.col){const b=x.v.macros[4];x.v.macros[4]=x.v.col[0];x.v.col=[b];if(x.home)x.home[4]=x.v.macros[4];}   /* SKIN: TENSN on knob 5, BEATER under Shift */
    x.th=2;}
  if(x&&x.v&&x.v.macros&&x.th<3){if(x.eng===THUMP&&x.v.cv&&fromV(x.v.cv[0],8)===3){x.v.fa=[x.v.macros[5]];x.v.macros[5]=112;if(x.home)x.home[5]=112;}   /* SKIN: TONE on knob 6, SHELL under Shift */
    x.th=3;}
  lfo3Mig(x);fillMig(x);});return a;}
/* SOLO is never stored: it is a live action and stays as it is when a preset loads */
/* the star (Lef 19 nov): the active preset changed since it was loaded or saved; the tempo does not count */
let _cmpT=0,_cmpV=false;const preCmp=()=>JSON.stringify({v:1,keyV:1,sendV:SEND_V,tracks:tracks.map(t=>{const c=Object.assign({},t);delete c.solo;return c;}),perf,glob,sendShared,stutShared,glanes,fxLib,snaps:ui.snaps});   /* preSnap without the tempo, in one pass */
function preDirty(){if(ui.act==null||ui.actH==null)return false;const n=Date.now();if(n-_cmpT>400){_cmpT=n;const c=preCmp();if(ui.actRef!=='kept')_cmpV=c!==ui.actRef;else{_cmpV=strHash(c)!==ui.actH;if(!_cmpV)ui.actRef=c;}}return _cmpV;}   /* a plain string compare; the hash only after a restart */
/* the active preset survives a restart (Lef 25 nov): its number and a fingerprint of how it was loaded or saved are kept with the state */
const strHash=s=>{let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0;}return h+':'+s.length;};
const preRef=()=>{ui.actRef=preCmp();ui.actH=strHash(ui.actRef);_cmpT=0;};
let _refT=null;const preRefSoon=()=>{ui.actRef=null;ui.actH=null;if(_refT!=null)clearTimeout(_refT);_refT=setTimeout(()=>{_refT=null;preRef();},300);};   /* after a preset switch the fingerprint waits 300 ms, so the switch itself stays light (Lef 25 nov) */
const preSnap=()=>JSON.stringify({v:1,keyV:1,sendV:SEND_V,tracks:tracks.map(t=>{const c=Object.assign({},t);delete c.solo;return c;}),perf,glob,sendShared,stutShared,glanes,fxLib,bpm,snaps:ui.snaps});
const preIndex=()=>presets.db.doc(`data/users/${presets.uid}/efs-presets`);
const preSlot=i=>preIndex().collection('slots').doc('s'+i);
const preIdx=()=>({names:presets.names,lens:presets.lens,main:presets.main,lp:presets.lp,song:presets.song});
function preLocal(){try{localStorage.setItem('efs-presets-v1',JSON.stringify(Object.assign(preIdx(),{slots:presets.cache})));return true;}catch(e){return false;}}
function preIdxRead(d){if(Array.isArray(d.lens))presets.lens=d.lens.slice(0,PRESET_N).concat(Array(PRESET_N).fill(null)).slice(0,PRESET_N);if(LOOP_BARS.includes(d.main))presets.main=d.main;if(d.lp&&typeof d.lp==='object')presets.lp={from:Math.max(0,Math.min(PRESET_N-1,d.lp.from|0)),to:Math.max(-1,Math.min(PRESET_N-1,d.lp.to??-1)),rep:Math.max(1,Math.min(10,d.lp.rep||10))};
  if(d.song&&Array.isArray(d.song.rows))presets.song={rows:d.song.rows.filter(r=>r&&r.p>=0&&r.p<PRESET_N).map(r=>({p:r.p|0,x:Math.max(1,Math.min(16,r.x|0||1)),b:LOOP_BARS.includes(r.b)?r.b:4})),end:d.song.end?1:0};}
function presetInit(){
  try{if(window.claude&&claude.use){const[db,user]=PALL([claude.use('db'),claude.use('user')]);const uid=user&&user.id();
    if(db&&uid){presets.db=db;presets.uid=uid;presets.where='YOUR ACCOUNT';const s=preIndex().get();
      if(s.exists&&Array.isArray(s.data().names)){presets.names=s.data().names.slice(0,PRESET_N).concat(Array(PRESET_N).fill(null)).slice(0,PRESET_N);preIdxRead(s.data());}}}}
  catch(e){presets.db=null;}
  if(!presets.db)try{const d=JSON.parse(localStorage.getItem('efs-presets-v1')||'null');if(d&&d.names){presets.names=d.names;presets.cache=d.slots||{};preIdxRead(d);}}catch(e){}
  render();}
/* writes one after another, never two at once */
function preWrite(fn){presets.queue=presets.queue.then(fn).catch(()=>toast('NOT SAVED: STORAGE REFUSED',3000));return presets.queue;}
let _soonT=null;function stateSoon(){if(_soonT!=null)clearTimeout(_soonT);_soonT=setTimeout(()=>{_soonT=null;try{saveState();if(sessionStorage.flush)sessionStorage.flush();}catch(e){}},2000);}   /* after a preset SAVE the state goes to disk 2 s later; not after LOAD, where the write held up the new sound (Lef 25 nov) */
function preStore(i,name,state){stateSoon();presets.names[i]=name;presets.cache[i]=state;
  if(presets.db)return preWrite(async()=>{preSlot(i).set({name,state});preIndex().set(preIdx());});
  if(!preLocal())toast('ONLY KEPT UNTIL RELOAD: EXPORT IT',3000);return Promise.resolve();}
/* empty a slot (DELETE); UNDO in the PRESETS menu brings the last one back */
function preRemove(i){presets.names[i]=null;presets.lens[i]=null;delete presets.cache[i];
  if(presets.db)return preWrite(async()=>{preSlot(i).delete();preIndex().set(preIdx());});
  preLocal();return Promise.resolve();}
function preIdxSave(){if(presets.db)preWrite(()=>preIndex().set(preIdx()));else preLocal();}
function preGet(i){if(presets.cache[i])return presets.cache[i];if(!presets.db||!presets.names[i])return null;
  const s=preSlot(i).get();return s.exists?(presets.cache[i]=s.data().state):null;}
/* apply a stored state: ALL, or only the patterns or only the sounds of the 8 tracks */
function preApply(mode,str,noUndo){const d=JSON.parse(str);if(!d||!Array.isArray(d.tracks))return;stutMig(d);migTracks(d.tracks);
  if(!noUndo)pushUndo();
  d.tracks.forEach((x,k)=>{const t=tracks[k];if(!t||!x)return;
    delete x.solo;if(mode<2)x.mute=!!x.mute;   /* ALL and PATTERNS bring the stored mutes back (none stored = all on); SOUNDS leaves them */
    const f=freshTrack(k);   /* what the preset does not hold goes to its start value, never to the preset before it (Lef 19 nov) */
    for(const key in f)if(!(key in x)&&!['slR','acR','mute','solo','smf','smn','lanes'].includes(key))x[key]=f[key];
    x.v=Object.assign({},f.v,x.v||{});if(!('lanes' in x))x.lanes=null;
    if(mode===0){Object.assign(t,x);t.v=Object.assign({},t.v,x.v);return;}
    const pat=key=>PAT_KEYS.includes(key);
    Object.keys(x).forEach(key=>{if(key==='v')return;if(key==='mute'){if(mode===1)t.mute=x.mute;return;}if(pat(key)===(mode===1))t[key]=x[key];});
    Object.keys(x.v||{}).forEach(key=>{if(PAT_V.includes(key)===(mode===1))t.v[key]=x.v[key];});});
  sendMig(d);globMig(d);perfMig(d);
  if(mode===0){[[perf,PERF_START.map((v,k)=>d.perf&&d.perf[k]!=null?d.perf[k]:v)],[glob,GLOB_START.map((v,k)=>d.glob&&d.glob[k]!=null?d.glob[k]:v)],[stutShared,d.stutShared],[sendShared[0],d.sendShared&&d.sendShared[0]],[sendShared[1],d.sendShared&&d.sendShared[1]]]
      .forEach(([a,b])=>b&&b.forEach((v,k)=>a[k]=v));if(d.snaps)ui.snaps=d.snaps;glanes=d.glanes||Array(LANES).fill(null);fxLib=fxLibOf(d.fxLib);}
  else if(mode===2&&d.sendShared)[0,1].forEach(k=>d.sendShared[k]&&d.sendShared[k].forEach((v,j)=>sendShared[k][j]=v));
  if(mode===2)fxLib=fxLibOf(d.fxLib);   /* SOUNDS brings the grid pads too */
  ui.stepPage=0;sync();preRefSoon();render();}
/* a load waits for the last 16th before the next bar (applied on the position report), at once when stopped */
function preQueue(mode,str,name){if(!ui.playing){preApply(mode,str);toast(PRE_ACTS[mode]+': '+name,2500);return;}
  ui.pending={mode,str,name,u:snapAll()};sync();   /* the undo snapshot now, not on the bar line */
toast('NEXT BAR: '+name,2500);}
function preTick(g){if(g%16!==15)return;evPick(g);
  if(ui.pending){const p=ui.pending;ui.pending=null;if(p.u){ui.undos.push(p.u);if(ui.undos.length>UNDO_N)ui.undos.shift();ui.redos.length=0;}preApply(p.mode,p.str,!!p.u);toast(PRE_ACTS[p.mode]+': '+p.name,2500);return;}
  const L=ui.loop;if(!L)return;if(--L.left>0){if(L.left===1)sync();return;}
  if(L.k+1>=L.list.length){if(L.k>=0)L.round++;if(L.rep<10&&L.round>L.rep){ui.loop=null;toast(L.song?'SONG: END, LAST PRESET PLAYS ON':'PRESET LOOPER: DONE',2500);render();return;}L.k=0;}else L.k++;   /* after the last round the last preset plays on */
  loopApply();}
/* PRESET LOOPER (Lef 19 nov): the saved presets from FROM to TO (or ALL), each BARS long, REPEAT rounds (10 = ENDLESS); changes on the bar */
/* LAST trig condition: the bar before a preset change (a load waiting for the bar, or the PRESET LOOPER moving on) */
const lastBar=()=>!!(ui.playing&&(ui.pending||ui.loop&&ui.loop.left===1));
const lpList=()=>{const L=presets.lp,a=L.to<0?0:Math.min(L.from,L.to),b=L.to<0?PRESET_N-1:Math.max(L.from,L.to);return presets.names.map((n,i)=>n&&i>=a&&i<=b?i:-1).filter(i=>i>=0);};
function loopApply(){const L=ui.loop,i=L.list[L.k];preApply(0,L.str[L.k],true);if(L.song)ui.sr=L.song[L.k].r;   /* SONG MODE: the highlight follows the row that plays (Lef 20 nov) */L.left=L.tot=L.bars?L.bars[L.k]:presets.main;sync();ui.pi=i;ui.act=i;ui.last={i,what:'LOOP'};render();}  /* the preset list follows the slot that plays */
function loopStart(){const list=lpList();
  if(!list.length){toast('NOTHING SAVED IN FROM - TO',2500);return;}
  toast('LOADING '+list.length);const str=PALL(list.map(i=>preGet(i)));
  const ok=list.filter((_,k)=>str[k]);if(!ok.length){toast('COULD NOT LOAD',2500);return;}
  ui.pending=null;ui.loop={list:ok,str:str.filter(Boolean),k:0,left:0,tot:1,round:1,rep:presets.lp.rep};
  if(ui.playing){ui.loop.k=-1;ui.loop.left=1;} /* the first one comes in on the next bar */
  else loopApply();
  toast('PRESET LOOPER: '+ok.length+' PRESETS',2500);}
function loopStop(){if(!ui.loop)return;const sg=ui.loop.song;ui.loop=null;toast(sg?'SONG STOPPED':'PRESET LOOPER STOPPED',2000);}
/* RENAME (Lef 19 nov): a quick list of song-part names, or TYPE letter by letter with the jog */
const RN_LIST=['INTRO','VERSE','CHORUS','BRIDGE','SOLO','BREAK','BUILD','DROP','OUTRO'],RN_CH=' ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-.',RN_MAX=14;
function renameOpen(i){ui.rnI=i;ui.ri=0;ui.menu='rename';ui.confirm=null;ui.toast=null;render();}
function rnFree(nm,i){if(!presets.names.some((n,k)=>k!==i&&n===nm))return nm;for(let q=2;q<100;q++){const c=nm+' '+q;if(!presets.names.some((n,k)=>k!==i&&n===c))return c;}return nm;}   /* the same name twice: a number after it */
function renameDo(nm){if(ui.rnFile!=null){const a=ui.rnFile;ui.rnFile=null;nm=String(nm||'').trim().slice(0,RN_MAX);ui.menu='buffer';ui.si=0;   /* a kept recording (MENU > BUFFER) */
    if(!nm){toast('NAME EMPTY: NOT RENAMED',2000);render();return;}const b=globalThis.efosRecs&&globalThis.efosRecs.rename(a,nm);toast(b?'RENAMED: '+b:'NOT RENAMED',2500);render();return;}
  const i=ui.rnI;nm=String(nm||'').trim().slice(0,RN_MAX);ui.menu='presets';
  if(!nm){toast('NAME EMPTY: NOT RENAMED',2000);render();return;}nm=rnFree(nm,i);
  const st=preGet(i);if(!st){toast('COULD NOT LOAD',2500);render();return;}
  preStore(i,nm,st);preRef();toast('RENAMED '+String(i+1).padStart(2,'0')+' '+nm,2500);render();}
function renamePick(){if(ui.ri<RN_LIST.length){renameDo(RN_LIST[ui.ri]);return;}
  const cur=(ui.rnFile!=null?ui.rnFile:presets.names[ui.rnI]||'').toUpperCase().split('').map(c=>Math.max(0,RN_CH.indexOf(c)));ui.tb=cur.length?cur:[1];ui.tc=0;ui.menu='type';ui.toast=null;render();}
function typeBy(d){const b=ui.tb;b[ui.tc]=((b[ui.tc]||0)+d+RN_CH.length*8)%RN_CH.length;ui.toast=null;render();}
function typeNext(){if(ui.tc+1>=RN_MAX){toast('14 CHARACTERS: < = DONE',1500);return;}ui.tc++;if(ui.tb.length<=ui.tc)ui.tb.push(ui.tb[ui.tc-1]||1);render();}
const typeStr=()=>ui.tb.map(c=>RN_CH[c]).join('');
/* SONG MODE (Lef 19 nov): rows of PRESET, TIMES, BARS (per time), played top to bottom; END = STOP or LOOP. Runs on the PRESET LOOPER, < stops it */
const SONG_LAB=['PRESET','TIMES','BARS'];
function songOpen(){ui.menu='song';ui.sr=0;ui.confirm=null;ui.toast=null;render();}
function songRowNew(){const R=presets.song.rows,last=R[R.length-1],first=presets.names.findIndex(Boolean);
  if(first<0){toast('SAVE A PRESET FIRST',2000);return;}R.push(last?{p:last.p,x:last.x,b:last.b}:{p:first,x:1,b:presets.main});ui.sr=R.length-1;preIdxSave();toast('ROW '+R.length+' ADDED',1500);render();}
function songTurn(k,d){const R=presets.song.rows,r=R[ui.sr],s=Math.sign(d);if(!s)return;
  if(k===7){presets.song.end=s>0?1:0;preIdxSave();toast('LOOP '+(presets.song.end?'ON: FROM THE TOP':'OFF: LAST PRESET PLAYS ON'),1500);render();return;}
  if(!r||k>2)return;
  if(k===0){const sv=presets.names.map((n,i)=>n?i:-1).filter(i=>i>=0);if(!sv.length)return;let q=sv.indexOf(r.p);q=q<0?0:Math.max(0,Math.min(sv.length-1,q+s));r.p=sv[q];toast('ROW '+(ui.sr+1)+' PRESET '+String(r.p+1).padStart(2,'0')+' '+(presets.names[r.p]||''),1500);}
  else if(k===1){r.x=Math.max(1,Math.min(16,r.x+s));toast('ROW '+(ui.sr+1)+' PLAYS '+r.x+'X',1500);}
  else{const q=LOOP_BARS.indexOf(r.b);r.b=LOOP_BARS[Math.max(0,Math.min(LOOP_BARS.length-1,(q<0?2:q)+s))];toast('ROW '+(ui.sr+1)+' '+r.b+' BAR'+(r.b>1?'S':'')+' EACH TIME',1500);}
  preIdxSave();ui.touched=k;touchT=performance.now();render();}
function songJog(){const R=presets.song.rows;
  if(ui.delHeld){ui.delUsed=true;if(ui.sr<R.length){R.splice(ui.sr,1);ui.sr=Math.min(ui.sr,R.length);preIdxSave();toast('ROW DELETED',1500);}render();return;}   /* DEL + jog press: the row goes */
  if(ui.sr>=R.length){songRowNew();return;}
  if(ui.loop){loopStop();render();return;}songStart();}
function songStart(){const R=presets.song.rows.filter(r=>presets.names[r.p]);if(!R.length){toast('NO ROWS WITH A PRESET',2000);render();return;}
  toast('LOADING SONG');const slots=[...new Set(R.map(r=>r.p))],got={};PALL(slots.map(i=>{got[i]=preGet(i);}));
  const list=[],str=[],bars=[],song=[];R.forEach((r,ri)=>{if(!got[r.p])return;for(let t=0;t<r.x;t++){list.push(r.p);str.push(got[r.p]);bars.push(r.b);song.push({r:ri,n:R.length,t:t+1,T:r.x});}});
  if(!list.length){toast('COULD NOT LOAD',2500);render();return;}
  ui.pending=null;ui.loop={list,str,bars,song,k:0,left:0,tot:1,round:1,rep:presets.song.end?10:1};
  if(ui.playing){ui.loop.k=-1;ui.loop.left=1;}else loopApply();
  toast('SONG: '+R.length+' ROWS',2000);render();}
function loopToggle(){if(ui.loop){loopStop();render();return;}const r=loopStart();if(r&&r.then)r.then(render);else render();}
/* the PRESET LOOPER screen: knob 1 FROM, 2 TO (left = ALL), 3 BARS, 4 REPEAT (right = ENDLESS); jog press = START / STOP */
const LP_LAB=['FROM','TO','BARS','REPEAT'];
const lpVal=k=>{const L=presets.lp;return k===0?(L.to<0?'ALL':String(L.from+1).padStart(2,'0')):k===1?(L.to<0?'ALL':String(L.to+1).padStart(2,'0')):k===2?String(presets.main):L.rep>=10?'ENDLESS':L.rep+'X';};
function looperOpen(){ui.menu='looper';ui.pa=0;ui.confirm=null;ui.toast=null;render();}
function looperTurn(k,d){const L=presets.lp,s=Math.sign(d);if(!s||k>3)return;
  if(k===0){if(L.to<0)L.to=L.from;L.from=Math.max(0,Math.min(PRESET_N-1,L.from+s));}
  else if(k===1)L.to=Math.max(-1,Math.min(PRESET_N-1,(L.to<0&&s>0?L.from-1:L.to)+s));
  else if(k===2){const q=LOOP_BARS.indexOf(presets.main);presets.main=LOOP_BARS[Math.max(0,Math.min(LOOP_BARS.length-1,q+s))];}
  else L.rep=Math.max(1,Math.min(10,L.rep+s));
  preIdxSave();ui.toast=null;ui.touched=k;touchT=performance.now();render();}
/* INIT from the action list: a new INIT preset in an empty slot, saved at once under a random name, never over one (Lef 19 nov) */
function presetNewInit(){let e=-1;for(let k=0;k<PRESET_N;k++){const j=(ui.pi+k)%PRESET_N;if(!presets.names[j]){e=j;break;}}
  if(e<0){toast('NO EMPTY SLOT: DELETE OR CLEAN UP FIRST',2500);return;}
  initAll();const name=preName();preStore(e,name,preSnap());ui.act=e;ui.pi=e;ui.pa=0;preRef();ui.last={i:e,what:'SAVED'};
  bigMsg('INIT',['NEW PRESET '+String(e+1).padStart(2,'0'),name,'','SAVE CHANGES: OVERWRITE','UNDO = BACK'],1800);toast('INIT IN '+String(e+1).padStart(2,'0')+' '+name,2500);render();}
function presetAct(){if(ui.pa===LOOP_A&&!ui.delHeld){looperOpen();return;}
  if(ui.pa===SONG_A&&!ui.delHeld){songOpen();return;}
  if(ui.pa===REN_A&&!ui.delHeld){if(!presets.names[ui.pi]){toast('EMPTY SLOT',1500);return;}renameOpen(ui.pi);return;}
  if(ui.pa===INIT_A&&!ui.delHeld){presetNewInit();return;}
  const i=ui.pi,nm=presets.names[i],dh=ui.delHeld&&(ui.delUsed=true),a=dh?DEL_A:ui.pa<=2&&!nm?3:ui.pa;   /* SHIFT held: the action picked in the list runs on this slot (Lef 19 nov) */ /* DEL held + jog press = DELETE, with the same confirm (Lef 15 nov) */ /* a load on an empty slot saves there; SHIFT + press always saves, over an existing one at once */
  if(a===0&&!dh&&nm&&i===ui.act&&ui.pa===0){ui.ask={i,yes:async()=>{const name=presets.names[i]||preName();preStore(i,name,preSnap());ui.act=i;preRef();ui.last={i,what:'SAVED'};bigMsg('SAVED',['','PRESET '+String(i+1).padStart(2,'0'),name,'','OVERWRITTEN'],1200);toast('SAVED '+String(i+1).padStart(2,'0')+' '+name,2500);render();}};
    ui.menu='ask';ui.si=0;ui.toast=null;render();return;}   /* the active preset again: OVERWRITE? NO / YES (Lef 19 nov) */
  if(a<=2){toast('LOADING '+nm);const st=preGet(i);
    if(!st){toast('COULD NOT LOAD',2500);return;}ui.loop=null;ui.actRef=null;ui.actH=null;preQueue(a,st,nm);ui.act=i;ui.last={i,what:a?'LOADED '+PRE_ACTS[a].split(' ')[0]:'LOADED'};}  /* a load by hand ends LOOP ALL */
  else if(a===3){if(nm&&ui.confirm!=='ow'+i){ui.confirm='ow'+i;toast('PRESS AGAIN: OVERWRITE '+String(i+1).padStart(2,'0'),4000);return;}
    ui.confirm=null;ui.saveTo=false;const name=nm||preName();preStore(i,name,preSnap());ui.act=i;preRef();ui.last={i,what:'SAVED'};ui.pa=0;if(nm)bigMsg('SAVED',['','PRESET '+String(i+1).padStart(2,'0'),name,'','OVERWRITTEN'],1200);toast('SAVED '+String(i+1).padStart(2,'0')+' '+name,2500);}
  else if(a===EXP_A)presetExport();
  else if(a===IMP_A){ui.pa=0;importInput.click();}
  else if(a===CLEAN_A){if(ui.confirm!=='clean'){ui.confirm='clean';toast('PRESS AGAIN: CLOSE THE GAPS',4000);return;}
    ui.confirm=null;preClean();ui.pa=0;}
  else if(a===DEL_A){if(!nm){toast('EMPTY SLOT',1500);return;}
    if(ui.confirm!=='del'+i){ui.confirm='del'+i;toast('PRESS AGAIN: DELETE '+String(i+1).padStart(2,'0'),4000);return;}
    ui.confirm=null;const st=preGet(i);ui.preDel={i,name:nm,state:st,len:presets.lens[i]};preRemove(i);if(ui.act===i)ui.act=null;ui.pa=0;
    toast('DELETED '+String(i+1).padStart(2,'0')+' (UNDO = BACK)',3000);}
  render();}
/* CLEAN UP: the saved presets move up in their order, so there are no empty slots between them */
function preClean(){const list=presets.names.map((n,i)=>n?i:-1).filter(i=>i>=0);let moved=0;
  if(list.some((src,k)=>src!==k))loopStop();
  for(let k=0;k<list.length;k++){const src=list[k];if(src===k)continue;const st=preGet(src);if(!st)continue;
    const name=presets.names[src];preStore(k,name,st);preRemove(src);moved++;}
  presets.song.rows.forEach(r=>{const k=list.indexOf(r.p);if(k>=0)r.p=k;});preIdxSave();   /* SONG rows follow their presets */
  if(ui.act!=null){const k=list.indexOf(ui.act);ui.act=k<0?null:k;}ui.pi=0;ui.last=null;toast(moved?'CLEANED UP: '+list.length+' PRESETS, NO GAPS':'NO GAPS',2500);render();}
function presetExport(){const slots=[];for(let i=0;i<PRESET_N;i++)if(presets.names[i]){const st=preGet(i);if(st)slots.push({i,name:presets.names[i],state:st});}
  if(!slots.length){toast('NOTHING TO EXPORT');return;}
  const data=JSON.stringify({efs:'presets',v:1,slots}),filename='efos-presets.json';
  let dl=null;try{if(window.claude&&claude.use)dl=claude.use('downloads');}catch(e){}
  if(dl){try{dl.save({filename,data});toast('EXPORTED '+slots.length,2500);}catch(e){toast(e&&e.code==='declined'?'EXPORT CANCELLED':'EXPORT NOT POSSIBLE HERE',2500);}return;}
  const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'application/json'}));a.download=filename;a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),5000);toast('EXPORTED '+slots.length,2500);}
const importInput=document.createElement('input');importInput.type='file';importInput.accept='.json,application/json';importInput.style.display='none';
document.body.appendChild(importInput);
importInput.onchange=async()=>{const f=importInput.files[0];importInput.value='';if(!f)return;
  try{const d=JSON.parse(f.text());if(!d||d.efs!=='presets'||!Array.isArray(d.slots))throw 0;let n=0;
    for(const x of d.slots)if(x.i>=0&&x.i<PRESET_N&&typeof x.state==='string'){JSON.parse(x.state);preStore(x.i,String(x.name||preName()).toUpperCase().slice(0,14),x.state);n++;}
    if(ui.loadOne&&d.slots.length===1&&n===1){const x=d.slots[0];ui.pi=x.i;ui.act=x.i;ui.loop=null;ui.actRef=null;ui.actH=null;preQueue(0,x.state,presets.names[x.i]);ui.last={i:x.i,what:'LOADED'};}
    else toast('IMPORTED '+n,2500);}catch(e){toast('NOT AN EFOS PRESET FILE',2500);}ui.loadOne=false;render();};
setTimeout(presetInit); /* after the rest of the page has loaded */
/* nudge: shift the selected track's pattern one step later (+1) or earlier (-1) within its length */
function nudge(d){const t=tracks[ui.sel],n=t.len;pushUndo('nudge');
  const a=t.steps.slice(0,n);for(let s=0;s<n;s++)t.steps[(s+d+n)%n]=a[s];toast('NUDGE '+(d>0?'RIGHT':'LEFT'));render();}
/* SHIFT + DEL = INIT: back to the start, silent: no steps, the kit sounds, FX and sends neutral, no modulation,
   no mutes or solo, PERFORM knobs home. Tempo, GLOBAL and the volume stay. One UNDO brings it all back */
const PERF_START=perf.slice();
function initAll(){pushUndo();
  tracks.forEach((t,i)=>{const f=freshTrack(i);for(const k in f)if(k!=='slR'&&k!=='acR')t[k]=f[k];t.altT=0;t.fillT=0;t.rpt=0;audio.ready&&audio.send({rpt:[i,0]});t.pdeg=Array(128).fill(0);t.pcent=Array(128).fill(0);t.home=null;});   /* every knob back to its start value, then the defaults below */
  fxLib=FXLIB0();defSound();defFx();defGlitch();defChance();defLength();tracks.forEach(t=>t.pkey=null);   /* no melody: every track one pitch, RANGE 0 (Lef 13 nov) */
  tracks.forEach(t=>{t.gen=4;t.dens=0;t.rot=0;t.steps=Array(128).fill(false);t.v.pat=[0,0,0,127,0,0,lenV(t.len),64];
    t.routes.fill(0);t.mdst.fill(-1);t.modOff.fill(false);t.lanes=null;t.mute=false;t.solo=false;t.v.lis=[0];t.v.lch=[127];t.v.lm=[0];t.v.pan=[64];t.altT=0;t.fillT=0;t.v.chs=[0];t.v.sc=SC0();
    t.grv=null;t.tlink=false;if(t.smf||t.smn){t.smf=null;t.smn=null;(ui.smClear=ui.smClear||new Set()).add(tracks.indexOf(t));}});   /* VAR.1, VAR.2 and CHAOS off too (Lef 13 nov); GROOVE, TUNE link and a loaded sample too (Lef 19 nov) */
  for(let k=2;k<glob.length;k++)glob[k]=GLOB_START[k];ui.mlen=0;   /* master COMP and MASTER LENGTH back to the start; tempo, volume and MAIN SCALE / ROOT stay (Lef 19 nov) */
  PERF_START.forEach((v,k)=>perf[k]=v);ui.loop=null;ui.pending=null;ui.stepPage=0;stutAllOff();
  ui.rec=false;glanes=Array(LANES).fill(null);ui.sel=0;Object.keys(ui.enc).forEach(k=>ui.enc[k]=0);ui.cp=[0,0,0,0];goPage(0,0);ui.menu=false;ui.tpos.fill(-1);ui.ppos.fill(-1);ui.loops.fill(0);ui.pos=0;
  ui.cap=0;rptAllOff();sync();audio.ready&&audio.send({clear:1});  /* INIT also empties every tail: slots, stutters, sends, master delay, CAP */
  {const e=presets.names.findIndex(n=>!n);ui.act=e<0?null:e;ui.actRef=null;ui.actH=null;if(e>=0)ui.pi=e;}   /* the star and the cursor: the first empty slot (Lef 19 nov) */
  bigMsg('INIT',['< UNDO'],1800);ui.big.huge=1;   /* only a big INIT and < UNDO under it (Lef 22 nov: minimal) */
  toast('INIT: ALL CLEAR (UNDO = BACK)',2500);render();}
/* DEL: all modulation off for the selected track; the sound stays at its knob values. Undoable */
function delPress(){if(ui.shift)initAll();else clrModOpen();}
/* DEL: CLEAR MOD? first (Lef 19 nov): the jog picks what goes, a press clears it, < cancels */
const hasMod=t=>t.routes.some(r=>r)||t.mdst.some(d=>d!=null&&d>=0);
function clrModRows(){const t=tracks[ui.sel],rows=[],dl=destListAll(t);
  if(hasMod(t)){rows.push({nm:'ALL MOD',val:'T'+(ui.sel+1),go:()=>clearModOn([ui.sel])});
    SOURCES.forEach((src,b)=>{let d=t.mdst[b];if(d==null||d<0)d=t.routes.findIndex(r=>r>>b&1);if(d<0)return;const e=dl.find(x=>x.p===d);
      rows.push({nm:src,val:'> '+(e?e.lab:'?'),go:()=>{pushUndo();setDest(t,b,0);sync();toast('T'+(ui.sel+1)+' '+src+' CLEARED (UNDO = BACK)',2000);}});});}
  if(tracks.some(hasMod))rows.push({nm:'ALL TRACKS',val:'ALL MOD',go:()=>clearModOn(tracks.map((_,i)=>i))});
  return rows;}
function clrModOpen(){const r=clrModRows();if(!r.length){toast('NO MOD TO CLEAR');return;}ui.menu='clrmod';ui.si=0;ui.confirm=null;ui.toast=null;render();}
function clearModOn(list){pushUndo();
  list.forEach(i=>{tracks[i].routes.fill(0);tracks[i].mdst.fill(-1);tracks[i].modOff.fill(false);});sync();
  toast(list.length>1?'MOD CLEARED: ALL TRACKS (UNDO = BACK)':'MOD CLEARED: T'+(list[0]+1)+' (UNDO = BACK)',2000);}
function clearMod(){clearModOn([ui.sel]);render();}
/* DELETE menu (Lef 24 nov): DEL held + track pad; DEL held + SHIFT + pad = all tracks. Small to big; the engine always stays.
   The jog picks a line, a press deletes, < cancels, UNDO brings it back */
const isPl=(l,s)=>!!(l.pk&&l.pk[s]);   /* a lane step set by hand on a held step (P-LOCK); the rest came from REC */
function lanesDrop(t,pl){(t.lanes||[]).forEach((l,j)=>{if(!l)return;for(let s=0;s<l.v.length;s++)if(l.v[s]>=0&&isPl(l,s)===pl){l.v[s]=-1;l.u[s]=-1;if(l.pk)l.pk[s]=0;}
  if(l.v.every(x=>x<0))t.lanes[j]=null;});}
function trackInit(i){const t=tracks[i],e=t.eng,f=freshTrack(i);for(const k in f)if(k!=='slR'&&k!=='acR'&&k!=='mute'&&k!=='solo')t[k]=f[k];
  t.altT=0;t.fillT=0;t.rpt=0;audio.ready&&audio.send({rpt:[i,0]});t.pdeg=Array(128).fill(0);t.pcent=Array(128).fill(0);t.home=null;t.pkey=null;
  const o=only;only=i;try{defSound();defFx();defGlitch();defChance();defLength();}finally{only=o;}
  t.gen=4;t.dens=0;t.rot=0;t.steps=Array(128).fill(false);t.v.pat=[0,0,0,127,0,0,lenV(t.len),64];t.routes.fill(0);t.mdst.fill(-1);t.modOff.fill(false);t.lanes=null;
  t.v.lis=[0];t.v.lch=[127];t.v.lm=[0];t.v.pan=[64];t.v.chs=[0];t.v.sc=SC0();t.grv=null;t.tlink=false;if(t.smf||t.smn){t.smf=null;t.smn=null;(ui.smClear=ui.smClear||new Set()).add(i);}
  if(t.eng!==e)engApply(t,e);}
function soundInit(i){const t=tracks[i],e=t.eng,o=only;only=i;try{defSound();}finally{only=o;}if(t.eng!==e)engApply(t,e);}   /* SOUND: the engine's own default sound, the engine stays */
const DEL_ROWS=[['TRIGGERS',i=>{const t=tracks[i];t.steps=Array(128).fill(false);t.dens=0;t.v.pat[4]=0;t.altT=0;t.fillT=0;t.cond=[];}],
  ['NOTES',i=>{const t=tracks[i];t.pdeg=Array(128).fill(0);t.pcent=Array(128).fill(0);t.v.pitch[2]=0;t.pkey=null;}],
  ['MOD',i=>{const t=tracks[i];t.routes.fill(0);t.mdst.fill(-1);t.modOff.fill(false);}],
  ['P-LOCKS',i=>lanesDrop(tracks[i],true)],['REC-LOCKS',i=>lanesDrop(tracks[i],false)],
  ['SOUND',soundInit],['TRACK',trackInit]];
function delMenuOpen(c,all){ui.delUsed=true;ui.menu='del';ui.delT=all?-1:c;ui.si=0;ui.confirm=null;ui.toast=null;if(!all)selectTrack(c);render();}
function delMenuGo(){const R=DEL_ROWS[ui.si],T=ui.delT;ui.menu=false;if(!R)return;pushUndo();const list=T<0?tracks.map((_,i)=>i):[T];
  list.forEach(i=>R[1](i));sync();toast((T<0?'ALL TRACKS':'T'+(T+1))+' '+R[0]+' DELETED (UNDO = BACK)',2000);render();}
/* DEL acts when let go, unless a knob was turned while it was held (that clears the knob's recording) */
function delDown(){ui.delHeld=true;ui.delUsed=false;ui.delKid=null;}
function delUp(){if(!ui.delHeld)return;ui.delHeld=false;if(!ui.delUsed)delPress();}
fn.DEL.addEventListener('pointerdown',e=>{e.preventDefault();delDown();});fn.DEL.addEventListener('pointerup',delUp);fn.DEL.addEventListener('pointerleave',()=>{ui.delHeld=false;});
/* hold to repeat: first press acts at once, after 1 s it repeats and speeds up */
function holdRepeat(b,action){let t=null,start=0;
  const stop=()=>{clearTimeout(t);t=null;};
  const loop=()=>{action();const held=performance.now()-start;t=setTimeout(loop,held>3000?40:held>2000?80:150);};
  b.addEventListener('pointerdown',e=>{e.preventDefault();stop();start=performance.now();action();t=setTimeout(loop,1000);});
  b.addEventListener('pointerup',stop);b.addEventListener('pointerleave',stop);b.addEventListener('pointercancel',stop);
  b.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();e.stopPropagation();action();}});}
function stepPageBy(d){const t=tracks[ui.sel],np=Math.ceil((page().key==='pitch'?Math.max(t.len,pLen(t)):t.len)/16);ui.stepPage=Math.max(0,Math.min(np-1,ui.stepPage+d));
  toast('STEPS '+(ui.stepPage*16+1)+'-'+Math.min(t.len,ui.stepPage*16+16)+' ('+(ui.stepPage+1)+'/'+np+')',2000);render();}
/* < >: the step page of the selected track; SHIFT: nudge its pattern; SHIFT on every PERFORM page: MASTER LENGTH (Lef 14 nov) */
const ltKey=d=>swapArrow(d)?0:onGlobal()?mlenBy(d):ui.shift?nudge(d):stepPageBy(d);
holdRepeat(fn.PREV,()=>ltKey(-1));holdRepeat(fn.NEXT,()=>ltKey(1));
/* arrow keys: every press one page on (down = next), past the last page into the next layer;
   held over 1.5 s it jumps from layer to layer */
let arrowT0=0,arrowLast=0;
function arrowPage(d,rep){const now=performance.now();if(!rep){arrowT0=now;pageAll(d);return;}
  if(now-arrowT0<1500||now-arrowLast<450)return;arrowLast=now;layerJump(d);}
function layerJump(d){goPage((ui.cat+d+4)%4,0);toast(catName()+' / '+cpage().name,600);render();}
function pageAll(d){const v=pgVis(ui.cat),cur=v.indexOf(ui.cp[ui.cat])+d;
  if(cur>=0&&cur<v.length)goPage(ui.cat,v[cur]);else{const c=(ui.cat+d+4)%4,w=pgVis(c);goPage(c,d>0?w[0]:w[w.length-1]);}
  toast(catName()+' / '+cpage().name,600);render();}
/* + / - : encoder page; with Shift: track length */
/* GLOBAL is the page after PERF: + past the last PERF page opens it, - on GLOBAL goes back */
function pageBy(d){const v=pgVis(ui.cat),n=v.length,cur=ui.cp[ui.cat],next=v[(v.indexOf(cur)+d+n)%n];   /* wraps both ways (Lef 14 nov) */
  if(next!==cur){goPage(ui.cat,next);render();}}
holdRepeat(fn.PLUS,()=>plusMinus(1));holdRepeat(fn.MINUS,()=>plusMinus(-1));
const MLEN=[0,1/16,1/8,1/4,1/2,1,2,4,8,16];  /* bars; 0 = off; down to one 16th (Lef 18 nov) */
const mlShow=m=>m>=1?m+(m>1?' BARS':' BAR'):'1/'+Math.round(1/m);
function mlenBy(d){const k=MLEN.indexOf(ui.mlen||0);ui.mlen=MLEN[Math.max(0,Math.min(MLEN.length-1,k+d))];
  toast(ui.mlen?'MASTER LENGTH '+mlShow(ui.mlen):'MASTER LENGTH OFF',2000);render();}
const onGlobal=()=>ui.cat===3&&ui.shift;   /* v118: SHIFT + length keys / < > on PERFORM = MASTER LENGTH; snapshots are gone for now */
function lenBy(d){const t=tracks[ui.sel];setLen(t,Math.max(1,Math.min(MAXS,t.len+d)));t.v.pat[6]=lenV(t.len);
  ui.stepPage=Math.min(ui.stepPage,Math.ceil(t.len/16)-1);toast('LENGTH '+t.len);render();}
function togglePlay(){setPlaying(!ui.playing,true);}   /* with a MIDI clock: starts at once, on its ticks and tempo */
/* PLAY on / off; from an external MIDI clock the core has already started or stopped (send = false) */
function setPlaying(on,send){ui.playing=on;rptAllOff();startAudio();if(send&&audio.ready)audio.send({play:ui.playing?1:0});ui.cap=0;
  ui.tpos.fill(-1);ui.loops.fill(0);if(ui.playing){ui.pos=0;last=performance.now();acc=0;}
  if(ui.altOn.some(Boolean)||ui.fillOn.some(Boolean)){ui.altOn.fill(false);ui.fillOn.fill(false);sync();}   /* V1.INT / V2.INT: bar 1 plays as written */render();}
function selectTrack(c){ui.sel=c;ui.stepPage=0;}
function toggleMute(c){tracks[c].mute=!tracks[c].mute;}
/* linking: hold a knob on the MACRO page, then step 1-5 (or key 1-5) toggles a modulation source for it */
const linking=()=>false;   /* v118: the D knobs on MOD 1-3 pick destinations; holding a knob + step no longer links */
/* a macro's name as the SOUND page shows it for the selected track's engine */
const macName=k=>{const t=tracks[ui.sel];return rnd2(withCtx({layer:'track',enc:0,shift:0},()=>encLabels()[k]),t)||MACROS[k];},heldName=()=>macName(ui.heldM);
/* the sound knob (0-7, the MOD destinations) under a held knob, or null */
function heldMacro(k){if(typeof k!=='number')return null;if(cpage().src)return ui.layer==='track'&&page().key==='macros'?k:null;
  const s=kSpec(k);return s&&s.src&&s.src[0]==='track'&&s.src[1]===0&&s.shift==null?s.src[2]:null;}
/* MOD page row 4: the 8 sound knobs as destinations of the picked source (LFO1, LFO2, RND A, RND B; Shift + ENV knobs = ENV); Shift = all tracks */
const modSrcI=()=>ui.modEnv?2:[0,1,3,4][ui.modSrc];
const modLinked=(t,c)=>(t.routes[c]>>modSrcI()&1)===1;
function modDest(c){const b=modSrcI(),on=!modLinked(tracks[ui.sel],c),list=ui.shift?tracks:[tracks[ui.sel]];
  list.forEach(t=>{if(on)t.routes[c]|=1<<b;else t.routes[c]&=~(1<<b);});
  toast(`${SOURCES[b]} > ${macName(c)} ${on?'ON':'OFF'}${ui.shift?' ALL TRACKS':''}`);}
function toggleRoute(s){const t=tracks[ui.sel],k=ui.heldM;t.routes[k]^=1<<s;
  toast(`${macName(k)} ${t.routes[k]>>s&1?'+':'-'} ${SOURCES[s]}`);render();}
/* LOOP: on the MOD page with RND A/B chosen, repeats its last LEN values (Turing style) */
function loopPress(){const t=tracks[ui.sel];
  if(ui.layer==='track'&&page().key==='mod'&&ui.modSrc>=2){const w=ui.modSrc-2;t.rloop[w]=!t.rloop[w];toast(`RND ${'AB'[w]} LOOP ${t.rloop[w]?'ON':'OFF'}`);render();return;}
  if(ui.shift){loopToggle();return;}   /* SHIFT + LOOP: the PRESET LOOPER on / off */
  if(ui.menu==='looper'){ui.menu=false;render();return;}looperOpen();}   /* LOOP: its settings (again = close) */
/* VAR.S: each pattern loop the macros drift a little, more as VAR.S opens.
   The drift stays around a home sound: the sound when variation was opened, or a knob you turned since.
   PITCH, DECAY, ATTACK and LEVEL never move: pitch has its own variation (VAR.P, VAR.M). Back to 0 keeps what you hear. */
/* the macros that move the pitch besides PITCH itself (Core Principle: sound variation never moves pitch, Lef 19 nov):
   ENV.P (the pitch envelope) and the THUMP model knobs that tune the body: STACK RATIO (carriers 2, 3), WAVE PITCH.B, SKIN TENSN */
const PITCH_M=t=>{const a=[];const ep={0:4,[THUMP]:2,[SOPHIE]:4,[SNARE]:4,[SAMPLE]:4,[WDRUM]:4}[t.eng];if(ep!=null)a.push(ep);
  if(t.eng===THUMP){const al=thAlgo(t);if(al===1||al===3)a.push(4);if(al===2)a.push(5);}return a;};
const VAR_W=[2.5,4,8,14,14,10,12,0]; /* FILTER drifts less, DECAY only a little */
function soundVar(i){const t=tracks[i],a=t.v.pat[2]/127,m=t.v.macros;
  if(a<=0){t.home=null;t.bhome=null;return;}if(!t.home)t.home=m.slice();
  m[0]=t.home[0];   /* a pitch that drifted before goes back to its home */
  if(m[6]>=127&&![CHORD,SHARK,HIVE,NEBULA,THUMP,SOPHIE].includes(t.eng)){   /* NOISE 100 %: only the noise varies, nothing tonal (Lef 17 nov) */
    for(let k=1;k<7;k++)m[k]=t.home[k];
    if(t.noise===3){const b=t.black;if(!t.bhome)t.bhome=b.slice();[0,2,3].forEach(k=>{const d=(rnd()*2-1)*14*a+(t.bhome[k]-b[k])*.15*(1-a*.5);b[k]=Math.max(0,Math.min(127,Math.round(b[k]+d)));});}   /* BLACK: DENS, FMOD, SIZE */
    return;}
  if(t.bhome){t.black=t.bhome.slice();t.bhome=null;}
  const nz=![CHORD,SHARK,HIVE,NEBULA,THUMP,SOPHIE].includes(t.eng);   /* engines where macro 7 is NOISE: VAR.S never moves NOISE, FILTER drifts half (Lef 17 nov) */
  for(let k=1;k<7;k++){if(nz&&k===6){m[6]=t.home[6];continue;}const d=(rnd()*2-1)*VAR_W[k]*(nz&&k===2?.5:1)*a+(t.home[k]-m[k])*.15*(1-a*.5);m[k]=Math.max(0,Math.min(127,Math.round(m[k]+d)));}
  m[1]=t.home[1];PITCH_M(t).forEach(k=>m[k]=t.home[k]);}   /* DECAY stays where you set it (Lef 15 nov); decay variation is VAR.D; nothing that moves the pitch (Lef 19 nov) */
/* a fresh sound near the kit voice (vary=false) or a small nudge of the current sound; LEVEL stays; undoable.
   On NEW / VARY while the MACRO page is on screen */
function newSound(i,vary){const t=tracks[i],m=t.v.macros;
  if(!vary){const[n,c]=roleMacros(i);for(let k=0;k<7;k++)if(!(t.eng===NEBULA&&k===6))m[k]=n[k];t.v.col=[c];engRnd(t);return;}   /* NEBULA keeps its SOURCE */
  const nudge=v=>Math.max(0,Math.min(127,Math.round(v+(rnd()*2-1)*13)));
  for(let k=2;k<7;k++)if(!(t.eng===NEBULA&&k===6))m[k]=nudge(m[k]);t.v.col=[nudge(t.v.col[0])];}   /* DECAY stays (Core Principle) */
/* N = new sound, V = a small variation, for the selected track (SHIFT = all tracks), on every layer; UNDO = back */
function soundKey(vary){pushUndo();const list=ui.shift?tracks.map((_,i)=>i):[ui.sel];
  list.forEach(i=>{if(!vary)keepEngSound(i);else newSound(i,true);if(tracks[i].home)tracks[i].home=tracks[i].v.macros.slice();});
  toast((vary?'VARY SOUND ':'NEW SOUND ')+(ui.shift?'ALL TRACKS':'T'+(ui.sel+1)));render();}
/* what a knob of J60 / SHARK / ACID shows; null = the shared display */
function engShow(t,k,v,sh){
  if(t.eng===SAMPLE)return!sh&&k===0?(v===64?'0 ST':(v>64?'+':'')+Math.round((v-64)/63*24)+' ST'):null;   /* SAMPLE: the PITCH knob transposes, +-24 ST */
  if(t.eng===ACID)return sh&&k===3?PIC+'ACD:'+v:sh&&k===2?String(v):!sh&&k===4?timeShow(0.03*Math.pow(2,v/127*6.38)):null;
  if(!isSyn(t))return null;
  if(t.eng===THUMP){const K=TH_K[thAlgo(t)],own=x=>{if(x[0]==='----')return'';if(!x[2])return pct(v);const n=x[2][Math.round(v/127*(x[2].length-1))];return WAVE_PICS.has(n)?PIC+n:n;};
    if(sh)return k===1||k===3||k===6?pct(v):k===2?TH_ALGO[fromV(v,TH_NA)]:k===4||k===5?own(K[k-2]):null;
    return k===0&&!pRange(t)?Math.round(Math.max(30,Math.min(200,20*Math.pow(2,tuneP(t)*8))))+'HZ':k===1?timeShow(.05*Math.pow(30,v/127)):k===2||k===3||k===6?pct(v):k===4||k===5?own(K[k-4]):null;}
  if(t.eng===SOPHIE){if(sh)return k===2?SO_ALGO[fromV(v,6)]:k===3||k===4?pct(v):k===5?(v>=64?'SMOOTH':'RAW'):k===6?curveShow(v):null;
    return k===2||k===3||k===5||k===6?pct(v):k===4?(Math.abs(v-64)<=1?'0':(v>64?'+':'-')+Math.round(Math.abs(v-64)/63*100)):null;}
  if(t.eng===NEBULA){const s=nebSrc(t);
    if(sh)return k===2?NEB_ALGO[fromV(v,4)]:k===3||k===4?String(v):k===5?pct(v):k===6?curveShow(v):null;
    return k===2||k===3?String(v):k===4?(fromV(t.v.cv[0],4)===0?grDensShow(v):String(v)):k===5?(v>=GR_FRZ?'FREEZE':Math.round(v/GR_FRZ*100)+'%'):k===6?(s===8?'PING':'T'+(s+1)):null;}
  if(t.eng===SID){const nb=v=>Math.min(15,Math.floor(v/128*16));if(sh)return k===1?SID_ATK[nb(v)]:k===2?famtShow(v):k===3?pct(v):k===4?timeShow(decSec(v)):k===6?CH_VOICE[fromV(v,4)]:null;
    return k===1?SID_DEC[nb(v)]:k===2||k===3?String(v):k===4?timeShow(decSec(v)):k===5?pct(v):k===6?SID_WAVE[fromV(v,8)]:null;}
  if(t.eng===HIVE&&(sh?k===3||k===6:k===2))return sh?(k===3?(v<1?'OFF':timeShow(0.005+0.8*Math.pow(v/127,2))):HIVE_ALGO[fromV(v,8)]):filtShow(v);
  if(sh)return k===2?famtShow(v):k===3?(t.eng===SHARK?PIC+'SHK:'+v:String(v)):k===4?timeShow(decSec(v)):k===5?curveShow(v):k===6?(t.eng===CHORD?CH_VOICE[fromV(v,4)]:String(v)):null;
  return k===2?String(v):k===4?timeShow(decSec(v)):k===6&&t.eng===CHORD?CH_CHOR[fromV(v,4)]:null;}
/* the first time a track turns CHORD it gets a pad-like start: long decay, half-open filter, a little PWM, sub and envelope */
/* the first time a track turns MATTER: a long dark drone with whisper, some crackle and a little of everything else */
function handsSound(t){const m=t.v.macros;m[0]=70;m[1]=30;m[2]=64;m[3]=40;m[4]=30;m[5]=10;m[6]=30;m[7]=88;t.v.col=[50];}
function matterSound(t){const m=t.v.macros;m[1]=decN(110);m[2]=50;m[3]=80;m[4]=55;m[5]=45;m[6]=0;t.v.col=[60];t.v.att=[attN(30)];t.v.cv=[55];t.v.cc=[25];t.v.chp=[25];}
function chordSound(t,r){const m=t.v.macros;m[1]=decN(96);m[2]=60;m[3]=30;m[4]=70;m[5]=40;m[6]=48;t.v.col=[90];t.v.att=[attN(12)];t.v.fa=[0];t.v.pw=[30];t.v.crv=[0];t.v.cv=[48];if(!r){t.v.cha=[0];t.v.j6=J6_0();}   /* CHOR.A 0 (Lef 26 nov): CHORUS on, then turn it in */
  if(r){m[1]=rint(decN(80),decN(110));m[2]=rint(40,80);m[3]=rint(10,60);m[4]=rint(30,100);m[5]=rint(0,70);m[6]=pick([0,48,48,80,127]);t.v.col=[rint(64,115)];t.v.pw=[rint(0,90)];
    t.v.cv=[rnd()<.3?0:pick([48,80,127])];}}   /* now and then one voice: a lead */
/* HIVE: a STRING swarm, a little spread, the filter half open, a short PERC; SPRING in slot 1 (keeps its knobs when it is there already) */
function hiveSound(t,r){const m=t.v.macros;m[1]=70;m[2]=40;m[3]=50;m[4]=60;m[5]=25;m[6]=30;t.v.col=[90];t.v.att=[0];t.v.fa=[0];t.v.pw=[20];t.v.crv=[0];t.v.cv=[toV(1,8)];
  if(r){m[1]=rint(40,110);m[2]=rint(25,60);m[3]=rint(20,90);m[4]=rint(30,100);m[5]=rint(0,90);m[6]=rint(0,80);t.v.col=[rint(64,115)];t.v.pw=[rnd()<.5?0:rint(10,60)];t.v.cv=[toV(rint(0,7),8)];}
  if(t.slot[0]!==SPRING){t.slot[0]=SPRING;[64,70,64,50].forEach((v,j)=>t.v.fx[j]=v);if(t.v.gx)t.v.gx[1]=0;}}
/* NEBULA: grains of the first other track at its own pitch (PITCH 59 = C4), a long envelope, some feedback and reverb */
function nebSound(t,r){const m=t.v.macros;m[0]=59;m[1]=decN(100);m[2]=30;m[3]=64;m[4]=90;m[5]=20;m[6]=toV(0,8);t.v.col=[50];t.v.att=[0];t.v.fa=[40];t.v.pw=[80];t.v.crv=[0];t.v.cv=[toV(0,4)];
  if(r){m[1]=rint(decN(40),decN(115));m[2]=rint(0,90);m[3]=rint(20,110);m[4]=rint(20,120);m[5]=rint(0,90);t.v.col=[rint(20,110)];t.v.fa=[rint(0,90)];t.v.pw=[rint(30,120)];}}
/* THUMP: a 50 Hz PURE kick at Omega's defaults; a new ALGO starts from that model's own defaults */
function thumpDef(t){const d=TH_DEF[thAlgo(t)];t.v.macros[4]=d[0];t.v.macros[5]=d[1];t.v.col=[d[2]];t.v.fa=[d[3]];}
function thumpSound(t,r){const m=t.v.macros;m[0]=21;m[1]=80;m[2]=102;m[3]=64;m[6]=25;t.v.att=[64];t.v.pw=[64];t.v.crv=[64];t.v.cv=[toV(7,TH_NA)];   /* default (Lef 26 nov): the 808 (Plaits), a little distorted, a little long */
  if(r)t.v.cv=[toV(rint(0,TH_NA-1),TH_NA)];thumpDef(t);
  if(r){m[0]=rint(16,30);m[1]=rint(30,100);m[2]=rint(40,127);m[3]=rint(20,110);m[6]=pick([0,0,rint(10,80)]);t.v.att=[rint(20,100)];t.v.pw=[rint(20,110)];t.v.crv=[rint(0,127)];
    const a=thAlgo(t),lo=a<2;m[4]=lo?rint(0,50):rint(0,127);m[5]=lo?rint(0,50):rint(0,127);t.v.col=[rint(0,127)];t.v.fa=[rint(0,127)];}}
/* SOPHIE: Sophie's snare (SHARD, a little crush and drive, the filter open); random: any model in useful ranges */
function sophieSound(t,r){const m=t.v.macros;m[0]=46;m[1]=31;m[2]=127;m[3]=0;m[4]=81;m[5]=66;m[6]=97;t.v.col=[66];t.v.att=[0];t.v.pw=[23];t.v.fa=[0];t.v.crv=[0];t.v.cv=[toV(3,6)];t.v.tat=[0];t.v.gdr=[38];t.v.nf=[toV(0,5)];
  if(r){t.v.cv=[toV(rint(0,5),6)];m[0]=rint(30,70);m[1]=rint(15,60);m[2]=rint(90,127);m[3]=rint(0,50);m[4]=rint(54,110);m[5]=rint(40,90);m[6]=rint(40,127);t.v.col=[rint(20,127)];t.v.pw=[rint(0,80)];t.v.gdr=[pick([0,0,rint(10,70)])];t.v.fa=[pick([0,127])];}}
/* SNARE: ALGO = a full starting point (Lef 17 nov); PITCH, DECAY, ATTACK, CURVE, LEVEL stay.
   808: Plaits' 808 (resonator head and shell, rectified noise); 909: Plaits' 909 (two oscillators, noise with a hold); XXX and 000: see the top */
function snareAlgo(t,i){const p=SN_PRE[i],m=t.v.macros;t.v.cv=[toV(i,4)];t.v.cc=[toV(p[0],4)];t.v.chp=[toV(p[1],6)];t.v.st=[p[14]];
  t.v.tat=[p[2]];t.v.col=[p[3]];t.v.pw=[p[4]];t.v.fa=[p[5]];t.v.nf=[p[6]];t.v.gdr=[p[7]];t.v.pe=[p[8]];t.v.fo=[p[9]];m[3]=p[10];m[4]=p[11];m[5]=p[12];m[6]=p[13];
  if(t.home)[3,4,5,6].forEach(k=>t.home[k]=m[k]);}
/* the first time a track turns SNARE: the 808 snare at about 180 Hz; random: any ALGO, then the layers wander within useful ranges */
function snareSound(t,r){const m=t.v.macros;if(!r){m[0]=50;m[1]=58;m[2]=64;t.v.att=[0];t.v.crv=[0];}
  snareAlgo(t,r?rint(0,3):0);
  if(r){const a=snA(t);if(a===3)t.v.cc=[toV(rint(0,3),4)];t.v.chp=[toV(rint(0,5),6)];if(a===1||a===2)t.v.st=[rint(30,100)];t.v.tat=[rint(30,100)];t.v.col=[rint(40,90)];t.v.pw=[rint(20,100)];t.v.fa=[pick([0,rint(20,127)])];
    t.v.nf=[rint(40,100)];t.v.gdr=[rint(40,90)];t.v.pe=[rint(25,100)];t.v.fo=[rint(0,100)];m[3]=a>=2?pick([0,rint(0,90)]):0;m[4]=rint(0,90);m[5]=pick([0,rint(0,60)]);m[6]=rint(40,100);}}
/* WAVETABLE / WT DRUM: the start values (WT0); random = other tables and other interplay, never pitch, decay or level */
/* TANK: a sung ping with some grain; random = another character, never FDBK (feedback only by hand, Lef 13 nov), never pitch / decay / level */
function tkSound(t,r){const m=t.v.macros,fb=t.v.tk?t.v.tk[7]:0;t.v.tk=TK0();if(!r){t.v.att=[0];m[1]=70;m[2]=100;t.v.gdr=[25];return;}
  const v=t.v.tk;v[0]=rint(0,127);v[1]=rint(90,127);v[2]=rint(0,127);v[3]=rint(90,127);v[4]=pick([0,0,64,127,rint(0,127)]);v[5]=rint(0,127);v[6]=rint(0,127);v[7]=fb;
  v[8]=pick([0,0,rint(0,127)]);v[9]=rint(10,90);v[10]=pick([0,rint(0,60)]);v[11]=pick([0,0,rint(0,90)]);v[12]=pick([64,64,rint(0,127)]);v[13]=rint(20,110);v[14]=pick([64,rint(70,127),rint(70,127),rint(0,58)]);}
function wtSound(t,r){const m=t.v.macros;t.v.wt=WT0();if(!r)t.v.ww=WW0();   /* RND.S keeps WARP, UNISON and TUNE.O */
  if(t.eng===WDRUM){t.v.wtn=['FORMNT','SIN>SAW'];if(!r){t.v.att=[0];m[1]=50;m[2]=110;m[4]=60;}}else{t.v.wtn=['SIN>SAW','PWM'];if(!r){t.v.att=[0];m[2]=100;m[5]=0;}}
  if(r){const v=t.v.wt,l=wtList().filter(n=>n!==WT_BUF);t.v.wtn=[pick(l),pick(l)];v[1]=rint(0,127);v[3]=rint(0,127);v[4]=pick([64,64,52,76,40,88,rint(30,98)]);
    v[5]=pick([0,rint(0,50),rint(30,100)]);v[6]=pick([0,0,rint(0,90)]);v[7]=rint(20,100);
    if(t.eng===WDRUM){v[13]=rint(10,90);v[14]=rint(40,100);}else{v[8]=pick([0,rint(0,60)]);v[9]=pick([64,rint(20,108)]);v[10]=pick([0,rint(0,60)]);v[11]=pick([0,0,rint(0,50)]);v[12]=rint(54,74);}}}
/* SAMPLE: the whole slice plays (DECAY open = hold), no attack, filter open */
function smSound(t){const m=t.v.macros;m[0]=64;m[1]=127;m[2]=64;m[4]=0;t.v.att=[0];t.v.crv=[0];if(!t.v.sm)t.v.sm=SM0();}
/* SHARK: a round, snappy bass; the filter plucks with its own envelope */
/* SID: a classic C64 bass, pulse with some PWM through the 6581 low-pass; random = another wave, PW, filter and envelope, never DECAY, PITCH or LEVEL */
function sidSound(t,r){const m=t.v.macros,v=sidv(t);t.v.sid=SID0();m[2]=55;m[3]=50;m[4]=40;m[5]=0;m[6]=toV(2,8);t.v.col=[96];t.v.att=[0];t.v.fa=[0];t.v.pw=[64];t.v.crv=[0];t.v.cv=[toV(1,4)];t.v.sid[1]=30;
  if(r){const w=t.v.sid;m[2]=rint(25,90);m[3]=rint(0,110);m[4]=rint(15,70);m[6]=toV(pick([0,1,2,2,4,5,6]),8);t.v.col=[rint(70,120)];t.v.pw=[rint(20,108)];w[0]=rint(0,127);w[1]=pick([0,0,rint(10,90)]);w[3]=toV(pick([0,0,0,1,2]),4);w[4]=toV(pick([0,1]),2);void v;}}
function sharkSound(t,r){const m=t.v.macros;if(!r)t.v.cha=[0];m[1]=60;m[2]=40;m[3]=40;m[4]=30;m[5]=50;m[6]=30;t.v.col=[100];t.v.att=[0];t.v.fa=[0];t.v.pw=[42];t.v.crv=[0];t.v.cv=[0];
  if(r){m[1]=rint(40,85);m[2]=rint(25,60);m[3]=rint(15,75);m[4]=rint(15,55);m[5]=rint(0,80);m[6]=rint(0,60);t.v.col=[rint(80,118)];t.v.pw=[pick([0,42,85,rint(86,127)])];}}
/* a message on the whole screen for a moment: INIT, a preset saved over (Lef 19 nov) */
function bigMsg(t,l,ms){ui.big={t,l,until:performance.now()+ms};}
function flash(r,c){ui.flash={r,c};setTimeout(()=>{ui.flash=null;render();},160);}
/* ROW 1, the same on every page (keys 1-8 too):
           M off            M on (tap M = on / off, or hold M)
   tap     select track     mute on / off
   SHIFT   mute on / off    solo: only this track
   SHIFT + M held, then tracks: they blink and flip together when SHIFT or M is let go (group mute) */
function muteDown(){if(ui.muteHeld)return;ui.muteHeld=true;ui.muteUsed=false;ui.muteQueue.clear();render();}
function muteFlush(){const q=[...ui.muteQueue].sort();ui.muteQueue.clear();if(q.length)soloBake();q.forEach(toggleMute);
  if(q.length)toast('MUTE: '+q.map(c=>(tracks[c].mute?'-':'+')+'T'+(c+1)).join(' '));}
function muteUp(){if(!ui.muteHeld)return;ui.muteHeld=false;
  if(ui.muteUsed)muteFlush();
  else{ui.muteMode=!ui.muteMode;toast(ui.muteMode?'M ON: TAP = MUTE':'M OFF: TAP = SELECT');}
  render();}
/* SOLO is one track at a time; kept apart from the mutes */
const anySolo=()=>tracks.some(t=>t.solo);
const silent=t=>!t.solo&&(t.mute||anySolo()); /* a soloed track always sounds, also when it was muted */
/* SHIFT + track in mute mode: solo it alone; the same again on that track (also after tracks were added to the solo) = all tracks play */
function soloOnly(c){if(tracks[c].solo||ui.soloT===c){tracks.forEach(t=>{t.solo=false;t.mute=false;});ui.soloT=-1;toast('SOLO OFF: ALL');return;}
  tracks.forEach((t,i)=>t.solo=i===c);ui.soloT=c;toast('SOLO T'+(c+1));}
/* a mute while a solo is on would change nothing you hear: the solo first turns into plain mutes
   (what you hear stays the same), then the mute flips, so it always does what it says */
function soloBake(){if(!anySolo())return;tracks.forEach(t=>{t.mute=!t.solo;t.solo=false;});}
function muteOne(c){soloBake();toggleMute(c);toast((tracks[c].mute?'MUTE T':'UNMUTE T')+(c+1));}
/* a track key: pad row 1 or keys 1-8 */
/* COPY: hold COPY (key C), tap the source track, then one or more target tracks; one UNDO takes it all back.
   Still holding the source when the second track goes down = SWAP the two */
const held0=new Set(); /* row 1 pads / keys 1-8 held down now */
function copyDown(){if(ui.copyHeld)return;ui.copyHeld=true;ui.copySrc=null;ui.copyStep=null;
  if(ui.heldStep!=null&&ui.layer==='track'){ui.stepLk=ui.heldStep;stepCopy(ui.heldStep);render();return;}   /* a step held + COPY: that step is the source (Lef 22 nov) */
  toast('COPY: PICK THE SOURCE TRACK OR STEP',4000);render();}
/* COPY + steps (Lef 22 nov): the first step pressed (or the one held when COPY went down) is the source, every next one gets its trigger,
   its P-LOCKs and its melody note; same track */
function stepCopy(i){const t=tracks[ui.sel],s=ui.stepPage*16+i;if(s>=t.len){toast('BEYOND LENGTH');return;}
  if(!ui.copyStep){const L=(t.lanes||[]).map(l=>l&&{kid:l.kid,p:l.p,v:l.v[s],u:l.u[s]});
    ui.copyStep={sel:ui.sel,s,on:!!t.steps[s],deg:t.pdeg?t.pdeg[s]:null,cond:t.cond&&t.cond[s]||0,L};toast('STEP '+(s+1)+' COPIED: PICK TARGETS',4000);return;}
  const c=ui.copyStep;if(c.sel!==ui.sel){toast('COPY STEPS: SAME TRACK ONLY',2000);return;}if(s===c.s)return;
  pushUndo();t.steps[s]=c.on;if(c.cond||t.cond){t.cond=t.cond||[];t.cond[s]=c.cond;}if(c.deg!=null&&t.pdeg&&s<t.pdeg.length)t.pdeg[s]=c.deg;
  const L=lanesOf(t);L.forEach(l=>{if(l){l.v[s]=-1;l.u[s]=-1;}});
  c.L.forEach(x=>{if(!x||x.v<0)return;let l=L.find(l=>l&&l.p===x.p);if(!l){const j=L.indexOf(null);if(j<0)return;l=L[j]={p:x.p,kid:x.kid,v:Array(TRACK_STEPS).fill(-1),u:Array(TRACK_STEPS).fill(-1)};}l.v[s]=x.v;l.u[s]=x.u;});
  L.forEach((l,j)=>{if(l&&l.v.every(x=>x<0))L[j]=null;});sync();toast('STEP '+(c.s+1)+' > STEP '+(s+1),1500);render();}
function copyUp(){if(!ui.copyHeld)return;ui.copyHeld=false;ui.copySrc=null;ui.copyStep=null;ui.toast=null;render();}
function copyTrack(c){if(ui.copySrc==null){ui.copySrc=c;toast('COPY T'+(c+1)+': PICK TARGETS',4000);return;}
  if(c===ui.copySrc)return;
  pushUndo('copy');
  if(held0.has(ui.copySrc)){const a=ui.copySrc;swapTracks(a,c);ui.copySrc=null;sync();toast('SWAPPED T'+(a+1)+' AND T'+(c+1),2500);return;}
  const src=JSON.parse(JSON.stringify(tracks[ui.copySrc]));delete src.mute;delete src.solo;
  Object.assign(tracks[c],src);sync();toast('COPIED T'+(ui.copySrc+1)+' TO T'+(c+1),2500);}
/* two tracks change places: pattern, sound, effects; the mute and solo stay where they are */
function swapTracks(a,c){const A=JSON.parse(JSON.stringify(tracks[a])),B=JSON.parse(JSON.stringify(tracks[c]));
  [A,B].forEach(x=>{delete x.mute;delete x.solo;});Object.assign(tracks[a],B);Object.assign(tracks[c],A);}
/* TRACK SWAP (Lef 21 nov): hold a track pad, < > moves the target (no wrap), let go of the pad = the two swap; the selection goes along */
function swapArrow(d){if(held0.size!==1||ui.copyHeld||ui.muteHeld)return false;const a=[...held0][0];
  const b=Math.max(0,Math.min(7,(ui.swp&&ui.swp.a===a?ui.swp.b:a)+d));ui.swp={a,b};
  toast(b===a?'SWAP: PICK A TRACK WITH < >':'SWAP T'+(a+1)+' > T'+(b+1),60000);render();return true;}
function swapUp(c){const s=ui.swp;if(!s||s.a!==c)return;ui.swp=null;if(s.b===s.a){ui.toast=null;render();return;}
  pushUndo('swap');swapTracks(s.a,s.b);ui.sel=s.b;ui.stepPage=0;sync();toast('TRACK SWAPPED',2000);render();}
function trackKey(c){
  if(ui.copyHeld){copyTrack(c);return;}
  if(ui.delHeld){delMenuOpen(c,ui.shift);return;}   /* DELETE menu (Lef 24 nov) */
  if(ui.muteHeld&&ui.shift){ui.muteUsed=true;ui.muteQueue.has(c)?ui.muteQueue.delete(c):ui.muteQueue.add(c);return;} /* group */
  if(ui.muteHeld||ui.muteMode){if(ui.muteHeld)ui.muteUsed=true;if(ui.shift)soloOnly(c);else muteOne(c);return;}
  if(ui.shift)muteOne(c);else selectTrack(c);}
fn.MUTE.addEventListener('pointerdown',e=>{e.preventDefault();muteDown();});
fn.LOOP.addEventListener('pointerdown',e=>{e.preventDefault();loopPress();});
fn.MUTE.addEventListener('pointerup',muteUp);fn.MUTE.addEventListener('pointercancel',muteUp);

/* ---------- pads, per category (row 1 = the tracks everywhere) ----------
   pads = RND: a full new value at once (the VAR knobs vary a little); SHIFT = all tracks */
const PADS=[['VAR.1','VAR.2','V1.INT','V2.INT','FILL',null,'TURING+','TURING-'],['RND.M','RND.P',null,null,null,null,'TURING+','TURING-'],['RND.S','MUT.S',null,null,null,null,null,null]];
/* VAR.1: 0 = as written, 1-4 variants; VAR.2: 0, 1, 2 fuller; RPT.T (SHIFT + VAR.T): the last steps loop as heard */
const ALTS=5,FILLS=3,RPTS=[0,4,8,10,12,14,16,24,28,32,64,96,128];
const onTracks=f=>{only=ui.shift?null:ui.sel;try{return f();}finally{only=null;}};
const whoS=()=>ui.shift?' ALL TRACKS':' T'+(ui.sel+1);
/* RND.P: a new pitch (with a melody: a new octave, C2-C5) */
function rndPitch(){each(t=>{t.v.macros[0]=pRange(t)?toV(rint(1,4),P_OCTS):rint(10,115);if(t.home)t.home[0]=t.v.macros[0];});}
function rowPad(c){const n=PADS[ui.cat][c];if(!n)return;const T=tracks[ui.sel],idx=ui.shift?tracks.map((_,i)=>i):[ui.sel];
  if(n==='TURING+'||n==='TURING-'){const on=n==='TURING+';ui.tw={c:on?6:7,pad:c,list:idx,t0:performance.now()};
    idx.forEach(i=>turWrite(tracks[i],i,on));flash(1,c);toast((on?'TURING+: A HIT AND A NOTE':'TURING-: A REST')+whoS());return;}
  if(n==='FILL'){ui.fillPad=c;ui.fillHeld=idx.reduce((m,i)=>m|1<<i,0);sync();toast('FILL'+whoS());render();return;}   /* held: FILL trig conditions are met (Lef 25 nov) */
  if(n==='RND.M'){pushUndo();onTracks(()=>rndMelody());toast('RND.M: NEW MELODY'+whoS());}
  else if(n==='RND.P'){pushUndo();onTracks(()=>rndPitch());toast('RND.P: NEW PITCH'+whoS());}
  else if(n==='V1.INT'||n==='V2.INT'){const k=n==='V1.INT'?'altT':'fillT',e=k==='altT'?'altEv':'fillEv',N=T[k]?evOf(T,e)%4+1:1,off=!!T[k]&&evOf(T,e)===4;   /* OFF > EVERY BAR > 2 > 3 > 4 > OFF (Lef 24 nov) */
    pushUndo();idx.forEach(i=>{const u=tracks[i];if(off){u[k]=0;u[e]=1;}else{if(!u[k]){u[k]=1;if(k==='fillT')u.fillSeed=1+Math.floor(rnd()*1e9);}u[e]=N;}});
    toast((k==='altT'?'VAR.1':'VAR.2')+(off?' OFF':N===1?' EVERY BAR':' EVERY '+N+' BARS')+whoS());}
  else if(n==='VAR.1'||n==='VAR.2'){const k=n==='VAR.1'?'altT':'fillT',v=T[k]?0:1;   /* on / off; ALT and FILL may both run (Lef 24 nov) */idx.forEach(i=>{tracks[i][k]=v;if(k==='fillT'&&v)tracks[i].fillSeed=1+Math.floor(rnd()*1e9);});   /* VAR.2: a new fill every press */
    toast(n+' '+(v?'ON':'OFF: AS WRITTEN')+whoS());}
  flash(1,c);}
function rptAllOff(){tracks.forEach(t=>t.rpt=0);}
/* a stepping pad shows brighter while its value is not 0 */
const ROW2_COL={'VAR.1':'var(--v1a)','V1.INT':'var(--v1b)','VAR.2':'var(--v2a)','V2.INT':'var(--v2b)','FILL':'var(--fillp)'};
const padOn=(t,n)=>n==='VAR.1'||n==='V1.INT'?!!t.altT:n==='VAR.2'||n==='V2.INT'?!!t.fillT:false;
/* SAMPLE REC (ENGINE row 3 pad 1, only on a SAMPLE track): start, again = stop; every recording overwrites the buffer; SHIFT = every SAMPLE track */
function smDubPad(){const on=!((ui.smr||0)>>16+ui.sel&1),list=(ui.shift?tracks.map((_,i)=>i):[ui.sel]).filter(i=>tracks[i].eng===SAMPLE);   /* OVERDUB (row 3 pad 2): into the buffer, same length, round until pressed again */
  list.forEach(i=>{audio.ready&&audio.send({smr:[i,on?2:0]});ui.smr=on?(ui.smr||0)|1<<i|65536<<i:(ui.smr||0)&~(1<<i|65536<<i);});
  toast((on?'OVERDUB STARTED':'OVERDUB STOPPED')+whoS());render();}
/* LOAD (ALGO FILE, row 3 pad 1): a list of the Move's sample folder; JOG picks, PRESS JOG opens a folder or loads the WAV,
   < goes up a folder (Lef 18 nov). The files are read on the Move (efosFiles, move/src/samples.js); the web app has none. */
function smLoadPad(){const F=globalThis.efosFiles;if(!F){toast('LOAD: ONLY ON THE MOVE',2000);return;}
  if(ui.menu==='files'&&ui.fwt==null){ui.menu=false;render();return;}
  if(ui.fwt!=null)ui.fdir='';ui.fwt=null;ui.fdir=ui.fdir||'';ui.flist=F.list(ui.fdir);ui.fi=0;ui.menu='files';ui.toast=null;render();}
/* LOAD.A / LOAD.B (WAVETABLE, WT DRUM; row 3 pads 1-2): the same list, from the folder of the layer's table (else Wavetables);
   PRESS JOG opens a folder or puts the table in that layer; the list stays open to try the next one, < goes up / closes (Lef 20 nov) */
function wtLoadPad(L){const F=globalThis.efosFiles,W=globalThis.efosWt;if(!F||!W){toast('LOAD: ONLY ON THE MOVE',2000);return;}
  if(ui.menu==='files'&&ui.fwt===L){ui.menu=false;ui.fwt=null;render();return;}
  const p=W.pathOf(wtn(tracks[ui.sel])[L]),f=p&&p.split('/').pop();
  ui.fwt=L;ui.fdir=p?p.split('/').slice(0,-1).join('/'):'Wavetables';ui.flist=F.list(ui.fdir);
  if(!ui.flist.length&&!p){ui.fdir='';ui.flist=F.list('');}
  ui.fi=f?Math.max(0,ui.flist.findIndex(x=>!x.dir&&x.n===f)):0;ui.menu='files';ui.toast=null;render();}
function wtFilePick(rel){const W=globalThis.efosWt,t=tracks[ui.sel];if(!W||!wtE(t))return;const n=W.nameOf(rel);pushUndo('wtl');
  wtn(t)[ui.fwt]=n;W.now(n);sync();toast('T'+(ui.sel+1)+' TBL.'+'AB'[ui.fwt]+' '+n,1500);render();}
function smFilePick(){const F=globalThis.efosFiles,it=ui.flist&&ui.flist[ui.fi];if(!F||!it)return;
  if(it.up){ui.fdir=ui.fdir.split('/').slice(0,-1).join('/');ui.flist=F.list(ui.fdir);ui.fi=0;render();return;}
  if(it.dir){ui.fdir=(ui.fdir?ui.fdir+'/':'')+it.n;ui.flist=F.list(ui.fdir);ui.fi=0;render();return;}
  if(ui.fwt!=null){wtFilePick((ui.fdir?ui.fdir+'/':'')+it.n);return;}
  F.load(ui.sel,(ui.fdir?ui.fdir+'/':'')+it.n);ui.menu=false;render();}
/* MONITOR (row 3 pad 8, blue, Lef 22 nov): MON.L off at once; again = back on at the value it had; lit as bright as MON.L; SHIFT = every SAMPLE track */
function smMonPad(){const t=tracks[ui.sel],on=smv(t)[7]>0,list=(ui.shift?tracks:[t]).filter(x=>x.eng===SAMPLE);pushUndo('smmon');
  list.forEach(x=>{const v=smv(x);if(on){if(v[7]>0)x.smMon=v[7];v[7]=0;}else v[7]=x.smMon||64;});
  sync();toast((on?'MONITOR OFF':'MONITOR ON '+pct(smv(t)[7]))+whoS());render();}
/* PLAY pad on ENGINE (not SAMPLE): one hit of the selected track on its ROOT note, also when stopped (Lef 22 nov) */
/* a step held + the green PLAY pad: that step, as the sequencer plays it (Lef 22 nov) */
function prevStep(){const t=tracks[ui.sel],s=ui.stepPage*16+ui.heldStep;if(s>=t.len){toast('STEP '+(s+1)+' IS PAST THE LENGTH',1200);return;}
  ui.stepLk=ui.heldStep;   /* the held step stays as it was when you let go */
  startAudio();sync();audio.ready&&audio.send({prevs:[ui.sel,s]});ui.hit[ui.sel]=performance.now();flash(2,2);toast('PLAY T'+(ui.sel+1)+' STEP '+(s+1),1200);}
function prevPad(){const t=tracks[ui.sel];if(ui.heldStep!=null){prevStep();return;}startAudio();audio.ready&&audio.send({prev:[ui.sel,1]});ui.hit[ui.sel]=performance.now();flash(2,2);
  toast('PLAY T'+(ui.sel+1)+(pRange(t)?' ROOT '+NOTES[rootOf(t)]:''),1200);}
function smPlayPad(){if(ui.heldStep!=null){prevStep();return;}const on=!((ui.smr||0)>>24+ui.sel&1),list=(ui.shift?tracks.map((_,i)=>i):[ui.sel]).filter(i=>tracks[i].eng===SAMPLE);
  {const tk=list.filter(genNew);if(tk.length){ui.sgGot=ui.sgGot||[];tk.forEach(i=>{audio.ready&&audio.send({sgt:[i]});ui.sgGot[i]=(ui.sg||0)>>3;audio.ready&&audio.send({prev:[i,1]});});toast('TAKE LOADED, PLAY '+tk.map(i=>'T'+(i+1)).join(' '));render();return;}}   /* the newest Sample-button take: loaded and played in one press (Lef 22 nov) */   /* PLAY (row 3 pad 3): the whole buffer once, again = stop; SHIFT = all SAMPLE tracks */
  list.forEach(i=>{audio.ready&&audio.send({smp:[i,0]});audio.ready&&audio.send({prev:[i,1]});ui.hit[i]=performance.now();ui.smr=(ui.smr||0)&~(1<<24+i);});   /* every press = one hit from START, as PLAY on every engine; never start / stop (Lef 22 nov) */
  flash(2,2);toast('PLAY'+whoS(),1200);render();}
function smRecPad(){const on=!((ui.smr||0)>>ui.sel&1),list=(ui.shift?tracks.map((_,i)=>i):[ui.sel]).filter(i=>tracks[i].eng===SAMPLE);
  list.forEach(i=>{audio.ready&&audio.send({smr:[i,on?1:0]});ui.smr=on?(ui.smr||0)|1<<i:(ui.smr||0)&~(1<<i|65536<<i);});
  const sy=fromV(smv(tracks[ui.sel])[11],4);toast((on?(sy&&ui.playing?'REC WAIT: NEXT BAR':'REC STARTED'):'REC STOPPED')+whoS());render();}
/* SAMPLE: RND.S picks another slice, so the pad is called RND.I there (Lef 19 nov) */
const sndName=(n,t)=>n==='RND.S'&&t.eng===SAMPLE?'RND.I':n;
function soundPad(c){const n=PADS[2][c];if(!n)return;pushUndo();
  if(n==='MUT.S')onTracks(()=>each((_,i)=>newSound(i,true)));else onTracks(()=>rndSound());flash(1,c);toast(sndName(n,tracks[ui.sel])+whoS());}
/* row 4 on ENGINE: pads 1-4 = SEND A 10 / 15 / 25 / 50 %, pads 5-8 = SEND B; pad 1 or 5 again while lit = off (SHIFT: only when every track is already there); the other pads only set (Lef 13 nov) */
const SEND_STEPS=[6,13,25,44];   /* 5 10 20 35 % (Lef 15 nov) */
function sendPad(c){const k=c<4?'sA':'sB',ki=c<4?0:1,list=ui.shift?tracks:[tracks[ui.sel]];pushUndo('send'+k);
  const off=c%4===0&&list.every(t=>sendLvl(t,k)===0),vOf=t=>off?0:c%4===3?spv(t)[ki]:SEND_STEPS[c%4];
  list.forEach(t=>t.v[k][0]=vOf(t));toast('SEND '+(c<4?'A ':'B ')+(off?'OFF':Math.round(vOf(tracks[ui.sel])/127*100)+'%')+whoS());
  if(c%4===3){ui.sendEdit={ki,c,k};render();}}   /* pad 4 / 8 held: its own value on knob 1 (Lef 19 nov) */
const spv=t=>{if(!t.v.sp)t.v.sp=[44,44];return t.v.sp;};
function sendEditTurn(d){const E=ui.sendEdit,list=ui.shift?tracks:[tracks[ui.sel]];pushUndo('sp'+E.k);
  const v=Math.max(0,Math.min(127,spv(tracks[ui.sel])[E.ki]+d));list.forEach(t=>{spv(t)[E.ki]=v;t.v[E.k][0]=v;});sync();render();}
const sendPg=()=>ui.cat===3&&/^SEND [AB]$/.test(cpage().name);   /* PERF SEND A / SEND B: only row 4, the same send pads as ENGINE (Lef 13 nov) */
const sendLvl=(t,k)=>{const v=t.v[k][0];if(v>0&&v===spv(t)[k==='sA'?0:1])return 3;let i=-1;SEND_STEPS.slice(0,3).forEach((s,j)=>{if(v>=s-3)i=j;});if(i===2&&v>=SEND_STEPS[3]-3)i=3;return i;};   /* -1 = off; 3 = pad 4's own value */   /* -1 = off */
/* GRID FX LIBRARY (Lef 20 nov): a grid pad held 1 s: the screen shows only the pick, knob 1 turns through the library;
   the slot of that row plays the picked effect at once (from the middle of its safe range); let go = done */
function fxSet(t,r,c){const was=t.slot[r];t.slot[r]=c;if(c===was)return;fxFresh(t,r,c);}
function fxPickOpen(h){const t=tracks[ui.sel];if(page().key!=='fx')return;fxSet(t,h.r-1,padFx((h.r-1)*8+h.c));ui.fxPick={r:h.r,c:h.c};ui.fxAcc=0;sync();render();}
/* one effect per notch of about 8, like every knob that steps through a list; it stops at the first and the last (Lef 21 nov) */
function fxPickTurn(d){const P=ui.fxPick,t=tracks[ui.sel];ui.fxAcc=(ui.fxAcc||0)+d;const q=Math.trunc(ui.fxAcc/8);if(!q)return;ui.fxAcc-=q*8;
  const b=(P.r-1)*8,k=b+P.c,L=FX_LIB.filter(f=>f===padFx(k)||![0,1,2,3,4,5,6,7].some(c=>b+c!==k&&padFx(b+c)===f));   /* an effect sits on one pad of a row only: two pads with the same effect lit up together (Lef 22 nov) */
  const i=Math.max(0,L.indexOf(padFx(k))),j=Math.max(0,Math.min(L.length-1,i+q));if(j===i){ui.fxAcc=0;return;}
  pushUndo('fxlib'+k);fxLib[k]=L[j];fxSet(t,P.r-1,fxLib[k]);sync();render();}
function padDown(r,c){const t=tracks[ui.sel];
  if(r===0&&ui.repHeld!=null&&ui.repSet&&!(ui.muteMode||ui.muteHeld)){   /* M on: row 1 keeps muting while a REPEAT is held (Lef 19 nov) */const S=ui.repSet,on=!S.has(c);if(on)S.add(c);else S.delete(c);
    audio.ready&&audio.send({rept:[c,on?ui.repeat:-1]});toast('REPEAT '+REP_PADS[ui.repeat]+' '+[...S].sort().map(i=>'T'+(i+1)).join(' '));render();return;}
  if(r===0)trackKey(c); /* row 1 is always the tracks, the same on every page */
  else if(ui.cat===0){
    if(r===1)rowPad(c);
    else if(r===2)risePad(c);
    else if(r===3)repPad(c);}
  else if(ui.cat===1){if(r===1)rowPad(c);else if(r===3)pitchPad(c);}
  else if(sendPg()){if(r===3)sendPad(c);}
  else if(ui.cat===2){const pg=ui.cp[2];
    if(r===3)sendPad(c);
    else if(pg===FXPG){const pc=c,was=t.slot[r-1];c=padFx((r-1)*8+c)===was?FX_OFF:padFx((r-1)*8+c);t.slot[r-1]=c;
      const hk={r,c:pc,was};ui.fxHold=hk;setTimeout(()=>{if(ui.fxHold===hk)fxPickOpen(hk);},1000);   /* held 1 s: pick this pad's effect from the library (Lef 20 nov) */
      if(c!==was)fxFresh(t,r-1,c);  /* a new effect starts from the middle of its safe range */
      const hot=(c===GRAIN||c===NEBFX)&&was!==c&&ui.cpu!=null&&ui.cpu>=CPU_WARN;toast(hot?`CPU HIGH: ${Math.round(ui.cpu*100)}%`:`T${ui.sel+1} SLOT ${r} ${FX[c][0]}`,hot?2000:1200);}
    else if(r===1)soundPad(c);
    else if(r===2&&c<2&&wtE(t))wtLoadPad(c);
    else if(r===2&&c===0&&smFile(t))smLoadPad();
    else if(r===2&&c===0&&t.eng===SAMPLE)smRecPad();
    else if(r===2&&c===1&&t.eng===SAMPLE&&!smFile(t))smDubPad();
    else if(r===2&&c===2&&t.eng===SAMPLE)smPlayPad();
    else if(r===2&&c===2)prevPad();
    else if(r===2&&c===7&&t.eng===SAMPLE)smMonPad();
    else if(r===2&&c===3&&smRadio(t)){audio.ready&&audio.send({rr:1});ui.radioT=performance.now();toast('RND.R: SEARCHING A STATION',2500);flash(r,c);}}
  else if(ui.layer==='param'){
    if(r===1){ui.param=c;toast('ALL '+rnd2(page().labels[c],tracks[ui.sel]));}
    else if(r===3&&c===1&&page().key==='macros'){ui.param=ALL_VD;toast('ALL VAR.D');}
    else if(r===2){pushUndo();const p=page(),list=ui.shift?tracks.map((_,k)=>k):[c];
      list.forEach(k=>{if(allVD(p))tracks[k].v.vd[0]=Math.floor(rnd()*128);else setVal(tracks[k],p.key,pdi(p,allPar()),Math.floor(rnd()*128));});flash(r,ui.shift?-1:c);toast((ui.shift?'ALL: ':'')+'T'+(c+1)+' '+rnd2(allLab(p),tracks[c])+' '+allValS(tracks[c]),2500);}
    else if(r===3&&c===0){pushUndo();const p=page(),safe=p.key==='macros'?SAFE_SOUND:SAFE_PAT;
      tracks.forEach(t=>safe.forEach((g,i)=>{if(!(p.key==='macros'&&i===1))setVal(t,p.key,i,g());}));flash(r,c);toast('RANDOM '+p.name+' ALL TRACKS (UNDO = BACK)');   /* ALL ENGINE: DECAY stays (Lef) */}}
  else{
    if(r===1){pushUndo();const tr=tracks[c];if(ui.shift)mutate(c,.15,true);else keepEngSound(c);   /* MUTATE: a new sound, same engine, LEVEL stays (= RND.S on ENGINE); SHIFT: only the triggers, a few steps */
      if(tr.home)tr.home=tr.v.macros.slice();ui.sel=c;ui.stepPage=0;ui.patUntil=performance.now()+2000;setTimeout(render,2050);
      flash(r,c);toast((ui.shift?'NEW PATTERN T':'MUTATE SOUND T')+(c+1));}
    else if(r===2&&c<MUT_BTN.length){pushUndo();onTracks(()=>MUT_BTN[c][1]());flash(r,c);toast(catNow(c),2500);}
    else if(r===3&&c===7&&ui.shift){pushUndo();allRandom();sync();flash(r,c);toast('ALL RANDOM: ALL TRACKS (UNDO = BACK)',2500);}   /* SHIFT + ALL = ALL RANDOM (Lef 24 nov) */
    else if(r===3&&c<DEF_BTN.length){pushUndo();onTracks(()=>DEF_BTN[c][1]());flash(r,c);toast(catNow(c),2500);}}
  render();}
/* MUTATE / DEFAULT pads: the new value of the selected track on the bottom line, ALL in front with SHIFT (Lef 22 nov) */
function catNow(c){const t=tracks[ui.sel],P=v=>Math.round(v/127*100)+'%',T='T'+(ui.sel+1)+' ';
  const v=c===0?'NEW SOUND':c===1?(t.gen===4?'ALG.G '+(t.grv==null?'----':GROOVES[t.grv][0]):ALGO_N[algoOf(t)]+(t.gen===6?' LEN.R '+rlenOf(t):''))+' DENS '+Math.round(t.dens/7*100)+'%'
    :c===2?'PITCH RANGE '+(pRange(t)?(pRange(t)===36?'FULL':pRange(t)):'OFF'):c===3?'LENGTH '+t.len:c===4?'FX '+FX[t.slot[0]][0]+' + '+FX[t.slot[1]][0]
    :c===5?'PROB '+P(t.v.pat[3]):c===6?'CHAOS '+P(t.v.chs[0]):'ALL DEFAULT';
  return(ui.shift?'ALL: ':'')+(c===7?v:T+v);}
/* ALL ENGINE / ALL TRIGGERS: a track's value of the picked parameter, as the page shows it */
function allValS(tr){const p=page(),v=(([a,i])=>a[i])(allArr(tr,p));
  return p.key==='pat'?patShow(tr,pdi(p,allPar()),v):allVD(p)?(v===64?'0':(v>64?'+':'-')+Math.round(Math.abs(v-64)/63*100)+'%'):p.key==='macros'&&ui.param===2?filtShow(v):String(v);}
/* GLOBAL ALL pages: one value of a track, the way a turned knob sets it */
function setVal(t,key,i,v){t.v[key][i]=v;if(key==='pat'&&i>=4&&i<=6)patKnob(t,i);if(key==='macros'&&t.home)t.home[i]=v;}
/* row 4 pad 1 on ALL ENGINE / ALL TRIGGERS: the whole page at random, in ranges that keep every track audible and finite */
const rr=(a,b)=>()=>a+Math.floor(rnd()*(b-a+1));
const SAFE_SOUND=[rr(0,127),rr(20,100),rr(20,107),rr(0,127),rr(0,127),rr(0,90),rr(0,80),rr(80,120)];
const SAFE_PAT=[rr(0,60),rr(0,60),rr(0,60),rr(80,127),rr(30,110),rr(0,80),()=>lenV(rint(4,128)),()=>[56,72,88][Math.floor(rnd()*3)]];
/* PITCH row 4: melody variations, on / off, one at a time; off brings the melody back (SHIFT = all tracks) */
function pitchPad(c){const v=ui.pv,all=ui.shift?' ALL TRACKS':'';
  if(v){v.keep.forEach(([i,d])=>tracks[i].pdeg=d);ui.pv=null;if(v.c===c){toast(PVARS[c]+' OFF');return;}}
  const on=(ui.shift?tracks.map((_,i)=>i):[ui.sel]).filter(i=>pRange(tracks[i]));if(!on.length){toast('RANGE OFF: MELODY OFF');return;}
  ui.pv={c,keep:on.map(i=>[i,tracks[i].pdeg.slice()])};on.forEach(i=>pitchVary(tracks[i],c));toast(PVARS[c]+' ON'+all);}
/* TURING+ / TURING-: the coming step gets a hit with a new random note, or a rest; like the write switch of a Turing machine */
function turWrite(t,i,on){const s=((ui.tpos[i]??-1)+1)%t.len,L=pLen(t),q=((ui.ppos[i]??-1)+1)%L,R=pRange(t);
  if(s<0||s>=t.len)return;t.steps[s]=on;if(on&&R){t.pdeg[q]=Math.floor(rnd()*(R+1));t.pcent[q]=(rnd()*2-1)*50;}}
/* TURING knob: each lane step that has just played turns into a new random note with this chance; at 0 the melody is locked */
/* TURING on TRIGGERS (ALGO TURING, knob 2): each step that has just played becomes a new random hit or rest at the density, with this chance;
   0 = locked. LINK: one machine for both, a step that changes also gets a new note (the PITCH TURING then waits) */
function trgTur(t,a,b){if(t.gen!==2||a==null||a<0||a===b)return;const p=Math.pow(t.v.rtu[0]/127,2);if(p<=0)return;const R=pRange(t),L=pLen(t);
  for(let s=a,k=0;s!==b&&k<MAXS;s=(s+1)%t.len,k++)if(s<t.len&&rnd()<p){t.steps[s]=rnd()<Math.max(.05,t.dens/7);if(t.tlink&&R){const q=s%L;t.pdeg[q]=Math.floor(rnd()*(R+1));t.pcent[q]=(rnd()*2-1)*50;}}}
function turStep(t,a,b){const p=turP(t),R=pRange(t),L=pLen(t);if(p<=0||!R||a==null||a<0||a===b||t.tlink&&t.gen===2)return;
  for(let s=a,k=0;s!==b&&k<MAXS;s=(s+1)%L,k++)if(s<L&&rnd()<p){t.pdeg[s]=Math.floor(rnd()*(R+1));t.pcent[s]=(rnd()*2-1)*50;}}
/* melody variations on the lane degrees 0..RANGE, over the pitch length */
function pitchVary(t,c){const R=pRange(t),L=pLen(t),sc=SCALES[scaleOf(t)],n=sc[2]?sc[2].length:7,d=t.pdeg,a=d.slice(0,L),cl=x=>Math.max(0,Math.min(R,x));
  if(c===0||c===1){const k=c?1:-1;for(let s=0;s<L;s++){const x=a[s]+k;d[s]=cl(x<0?x+n:x>R?x-n:x);}}   /* the whole line one scale step; a note past the edge folds an octave back */
  else if(c===2)for(let s=0;s<L;s++)d[s]=R-a[s];
  else if(c===3)for(let s=0;s<L;s++)d[s]=a[L-1-s];
  else if(c===4){for(let s=L-1;s>0;s--){const j=Math.floor(rnd()*(s+1));[a[s],a[j]]=[a[j],a[s]];}for(let s=0;s<L;s++)d[s]=a[s];}
  else if(c===5){for(let s=0;s<L;s++)if(rnd()<.3){const u=a[s]+n<=R,w=a[s]-n>=0;d[s]=u&&(!w||rnd()<.5)?a[s]+n:w?a[s]-n:a[s];}}   /* some notes jump an octave */
  else if(c===6)for(let s=0;s<L;s++){const o=Math.floor(a[s]/n)*n,r=a[s]-o,ch=[0,2,4,n].reduce((b,x)=>Math.abs(x-r)<Math.abs(b-r)?x:b,0);d[s]=cl(o+ch);}   /* only the chord notes: root, third, fifth */
  else{const h=Math.floor(L/2);if(h<1)return;for(let s=0;s<h;s++)d[h+s]=a[s];d[L-1]=a[0]>=n?a[0]-a[0]%n:0;}   /* the second half repeats the first and comes home on the root */
}
/* hold a step on the PITCH page, then + / - (or the jog) moves that note one scale step */
const pitchStep=()=>ui.layer==='track'&&page().key==='pitch'&&ui.heldStep!=null;
function degBy(d){const t=tracks[ui.sel],R=pRange(t),s=ui.stepPage*16+ui.heldStep;if(!R){toast('RANGE OFF: MELODY OFF');return;}
  if(s>=pLen(t)){toast('BEYOND PITCH LENGTH');return;}pushUndo('pstep'+s);t.pdeg[s]=Math.max(0,Math.min(R,t.pdeg[s]+d));
  toast(`STEP ${s+1} ${noteName(t,s)}`);render();}
function plusMinus(d){if(ui.menu==='looper')return;
  if(ui.menu==='rename'||ui.menu==='song'){if(ui.menu==='song'&&ui.shift&&ui.sr<presets.song.rows.length){songTurn(1,d);return;}menuMove(-d);return;}if(ui.menu==='type'){typeBy(d);return;}
  else if(ui.menu==='presets')preActBy(d);
  else if(ui.menu==='main'||ui.menu==='screensaver'||ui.menu==='midi'||ui.menu==='ctl'||ui.menu==='ctlmap'||ui.menu==='files'||ui.menu==='cond'||ui.menu==='clrmod'||ui.menu==='del'||ui.menu==='ask'||ui.menu==='power'||ui.menu==='buffer'||ui.menu==='bufsave'||ui.menu==='buffiles')menuMove(-d);else if(ui.menu==='mirror'){}else if(ui.menu)engBy(-d);   /* + = up the list */else if(pitchStep())degBy(d);else if(ui.shift)lenBy(d);else pageBy(-d);}   /* + = up: the page before */
function padUp(r,c){if(r===1&&ui.fillPad===c){ui.fillPad=null;ui.fillHeld=0;sync();render();}if(r===0)swapUp(c);if(ui.fxHold&&ui.fxHold.r===r&&ui.fxHold.c===c)ui.fxHold=null;if(ui.fxPick&&ui.fxPick.r===r&&ui.fxPick.c===c){const P=ui.fxPick;ui.fxPick=null;toast(`ROW ${P.r+1} PAD ${P.c+1}: ${FX[padFx((P.r-1)*8+P.c)][0]}`);render();}if(r===3&&ui.sendEdit&&ui.sendEdit.c===c){ui.sendEdit=null;render();}if(r===1&&ui.tw&&ui.tw.pad===c)ui.tw=null;if(r===3&&ui.repHeld===c){ui.repHeld=null;if(ui.repeat===c)repOff();}}
/* TRIGGERS row 3 (Lef 15 nov): pads 1-4 RISE (a held REPEAT swells in from silence), pads 5-8 SWEEP (it moves the stutter LFO DEST from 0 to full); one of each, again = off */
function risePad(c){const k=c<4?10:11,v=c%4+1;stutShared[k]=stutShared[k]===v?0:v;sync();if(ui.repHeld!=null)audio.ready&&audio.send({swr:1});   /* holding a REPEAT: start RISE / SWEEP again with the new time */
  toast(c<4?'RISE '+(stutShared[k]?RISE_L[c]:'OFF'):'SWEEP '+(stutShared[k]?SWEEP_L[c-4]+' > '+ST_DESTS[fromV(tracks[ui.sel].v.stu[9],8)][1]:'OFF'));}
/* REPEAT while the pad is held (row 4 on TRIGGERS and PERF): the selected track; SHIFT = all tracks (the master); while held, row 1 adds or drops tracks */
function repPad(c){ui.repHeld=c;if(ui.repeat!=null)repOff();ui.repeat=c;
  if(ui.shift){ui.repSet=null;audio.ready&&audio.send({rep:c});toast('REPEAT '+REP_PADS[c]+' ALL');}
  else{ui.repSet=new Set([ui.sel]);audio.ready&&audio.send({rept:[ui.sel,c]});toast('REPEAT '+REP_PADS[c]+' T'+(ui.sel+1));}}
function repOff(){if(ui.repSet)ui.repSet.forEach(i=>audio.ready&&audio.send({rept:[i,-1]}));else audio.ready&&audio.send({rep:-1});ui.repeat=null;ui.repSet=null;}
/* live safety: a lost pointer-up (window switch) must not leave a pad held */
function stutAllOff(){ui.repHeld=null;ui.tw=null;if(ui.repeat!=null)repOff();}
/* steps: on PERFORM 2 they hold snapshots; on every other page they are the sequencer */
const snapSteps=()=>false;
function stepClick(i){const t=tracks[ui.sel];if(ui.stepLk===i){ui.stepLk=null;ui.slk=null;return;}
  if(ui.copyHeld&&ui.layer==='track'){stepCopy(i);return;}   /* COPY held: steps copy and paste */   /* a knob was turned while it was held: the step stays as it was */
  if(linking()){if(i<5)toggleRoute(i);return;}
  if(ui.layer==='track'&&page().key==='pitch'&&t.eng===ACID){const s=ui.stepPage*16+i;if(s<pLen(t))acidStep(t,s);else toast('BEYOND PITCH LENGTH');render();return;}
  if(ui.layer==='track'&&page().key==='pitch'){const s=ui.stepPage*16+i; /* the pitch lane: show the note; hold + / - to change it */
    toast(s>=pLen(t)?'BEYOND PITCH LENGTH':pRange(t)?`STEP ${s+1} ${noteName(t,s)}  HOLD + / -`:'RANGE OFF: MELODY OFF');return;}
  if(ui.layer==='track'&&page().key==='mod'){
    const q=ui.modSrc;
    if(q<2){if(i<7){t.waves[q]=i;toast(`LFO${q+1} ${WAVES[i]}`);}}
    else if(ui.shift){t.rsmooth[q-2]=!t.rsmooth[q-2];toast(`RND ${'AB'[q-2]} ${t.rsmooth[q-2]?'SMOOTH':'STEPPED'}`);}
    else{t.rlen[q-2]=i+1;toast(`RND ${'AB'[q-2]} LOOP LENGTH ${i+1}`);}
    render();return;}
  if(snapSteps()){if(ui.shift){ui.snaps[i]=JSON.stringify({tracks,perf});ui.lastSnap=i;toast('SAVED SNAP '+(i+1));}
    else if(ui.snaps[i]){pushUndo();ui.lastSnap=i;const s=JSON.parse(ui.snaps[i]);migTracks(s.tracks).forEach((x,k)=>Object.assign(tracks[k],x));perfMig(s);s.perf.forEach((v,k)=>perf[k]=v);toast('SNAP '+(i+1));}
    else toast('SNAP '+(i+1)+' EMPTY');render();return;}
  const s=ui.stepPage*16+i;if(s>=t.len){toast('BEYOND LENGTH');return;}
  if(ui.stepT0&&performance.now()-ui.stepT0>STEP_HOLD)return;   /* held longer than a tap: the step stays as it was (Lef 22 nov) */
  pushUndo();t.steps[s]=!t.steps[s];
  if(!t.steps[s]&&t.cond&&t.cond[s]){t.cond[s]=0;sync();}   /* a step turned off loses its trig condition */
  if(!t.steps[s]&&t.lanes){t.lanes.forEach((l,j)=>{if(!l)return;l.v[s]=-1;l.u[s]=-1;if(l.v.every(x=>x<0))t.lanes[j]=null;});sync();}   /* a step turned off loses its P-locks (UNDO brings them back) */
  render();}
const STEP_HOLD=300;
/* TRIG CONDITIONS (Lef 25 nov), as on Elektron boxes: hold a step, press the jog. The index is the code the core reads (efs_core.c cond_pass) */
const COND_PCT=[1,2,4,6,9,13,19,25,33,41,50,59,67,75,81,87,91,94,96,98,99],
  COND_N=['OFF',...COND_PCT.map(p=>p+'%'),...[2,3,4,5,6,7,8].flatMap(b=>Array.from({length:b},(_,a)=>(a+1)+':'+b)),'FILL','NOT FILL','PRE','NOT PRE','NEI','NOT NEI','1ST','NOT 1ST','LAST','NOT LAST'];
const condOk=()=>ui.heldStep!=null&&ui.layer==='track'&&!ui.menu&&!ui.delHeld&&!ui.copyHeld&&!linking()&&!snapSteps()&&ui.stepPage*16+ui.heldStep<tracks[ui.sel].len&&['mod'].indexOf(page().key)<0;
function condHint(){if(condOk()&&!ui.slkIn){const t=tracks[ui.sel],c=t.cond&&t.cond[ui.stepPage*16+ui.heldStep]||0;toast(c?COND_N[c]+', JOG: CONDITIONS':'PRESS JOG FOR TRIG CONDITIONS',1500);}}
function condOpen(){const t=tracks[ui.sel],s=ui.stepPage*16+ui.heldStep;ui.condS={t:ui.sel,s};ui.stepLk=ui.heldStep;ui.menu='cond';ui.si=t.cond&&t.cond[s]||0;ui.toast=null;render();}
function condSet(){const C=ui.condS;ui.menu=false;ui.condS=null;if(!C){render();return;}const t=tracks[C.t],c=ui.si;pushUndo();t.cond=t.cond||[];t.cond[C.s]=c;
  if(c&&!t.steps[C.s])t.steps[C.s]=true;   /* a condition on an empty step puts the step there, like a P-lock (Lef 24 nov) */
  sync();toast('STEP '+(C.s+1)+': '+(c?COND_N[c]:'NO CONDITION'),1500);render();}
/* a step held: every knob on the page shows that step's P-LOCK value at once (Lef 22 nov) */
function slkView(){const t=tracks[ui.sel];if(ui.heldStep==null||!t||!t.lanes||ui.layer!=='track'||page().key==='pitch'||cpage().src)return;
  const s=ui.stepPage*16+ui.heldStep;if(s>=t.len)return;const base=snapAll();holdRender++;
  try{for(let k=0;k<8;k++){const sp=kSpec(k);if(!sp||sp.off&&sp.off(t))continue;const o=sp.own&&OWN[sp.own];if(o&&o.lab(t)==='----')continue;
      const ctx=o?null:ctxOf(sp),kid=o?'own/'+sp.own+'/'+(ui.shift?1:0):withCtx(ctx,()=>recKid(sp.src[2]));
      const ex=t.lanes.find(l=>l&&l.kid===kid&&l.u[s]>=0);if(!ex)continue;
      if(o)ownPut(o,t,ex.u[s]);else withCtx(ctx,()=>encSet(sp.src[2],ex.u[s]));
      ui.slkShow=ui.slkShow||{};ui.slkShow[k]=knobInfo(k,{});applySnap(base);}}
  finally{applySnap(base);holdRender--;}
  ui.slkStep=s;ui.slkPg=slkPgKey();}
const slkPgKey=()=>ui.sel+'/'+ui.cat+'/'+ui.cp[ui.cat]+'/'+ui.shift;

/* the Shift value of knob k on J60 / SHARK (knobs 3-7) and ACID (knob 4 = WAVE) lives in t.v[synV(t,k)] */
const synX=(t,k)=>(isSyn(t)&&k>=2&&k<=6)||(t.eng===ACID&&k===3),synV=(t,k)=>(t.eng===NEBULA||t.eng===THUMP||t.eng===SOPHIE?NEB_X:SYN_X)[k-2];   /* THUMP: ALGO, C.DEC, two of the model, C.TONE */
function encRef(k){const p=page();
  if(ui.layer==='glob')return[glob,ui.shift&&k===5?8:k];
  if(ui.layer==='perf'&&p.key==='stut')return k===0?[tracks[ui.sel].v.sauto,0]:[tracks[ui.sel].v.stu,ui.shift&&STK_SH[k]!=null?STK_SH[k]:STK[k]];   /* SHIFT: encSet passes it on to all tracks */
  if(ui.layer==='perf'&&k===0)return[tracks[chT()].v.chs,0];   /* CHAOS: all tracks; a held track pad = only that track (encSet, Lef 22 nov) */
  if(ui.layer==='perf')return[perf,ui.shift&&k===1?7:k];
  if(p.key==='macros'&&ui.shift&&k===1)return[tracks[ui.sel].eng===ACID?tracks[ui.sel].v.gate:tracks[ui.sel].v.att,0]; /* ACID: GATE instead of ATTACK */
  if(p.key==='macros'&&ui.shift&&k===7)return[tracks[ui.sel].v.pan,0];
  if(p.key==='macros'&&ui.shift&&synX(tracks[ui.sel],k))return[tracks[ui.sel].v[synV(tracks[ui.sel],k)],0];
  if(p.key==='macros'&&ui.shift&&k>=3&&k<=5&&X3(tracks[ui.sel]))return[tracks[ui.sel].v[['cv','cc','chp'][k-3]],0];
  if(p.key==='macros'&&ui.shift&&k===2)return[tracks[ui.sel].v.col,0];
  if(p.key==='macros'&&ui.shift&&k===3&&hasCurve(tracks[ui.sel]))return[tracks[ui.sel].v.crv,0];
  if(p.key==='macros'&&ui.shift&&k===4&&isTex(tracks[ui.sel]))return[tracks[ui.sel].v.pe,0];
  if(p.key==='macros'&&ui.shift&&k===4&&tracks[ui.sel].eng===0)return[tracks[ui.sel].v.st,0];
  if(p.key==='macros'&&ui.shift&&k===5&&isFm(tracks[ui.sel]))return[tracks[ui.sel].v.fo,0];
  if(p.key==='macros'&&ui.shift&&k===0&&hasTune(tracks[ui.sel])&&!pRange(tracks[ui.sel]))return[tracks[ui.sel].v.tn,0];
  if(p.key==='macros'&&ui.shift&&k===6){const t=tracks[ui.sel];if(!t.v.nc||fromV(t.v.nc[0],4)!==t.noise)t.v.nc=[toV(t.noise,4)];return[t.v.nc,0];} /* SHIFT + NOISE = noise colour: the knob keeps its own value, so small turns add up */
  if(p.key==='pitch'&&k===0)return[tracks[ui.sel].v.fol,0];
  if(p.key==='pitch'&&k===1)return[tracks[ui.sel].v.hrm,0];
  if(p.key==='pitch'&&ui.shift&&k===5)return[tracks[ui.sel].v.ac,0];
  if(p.key==='pitch'&&ui.shift&&k===6)return[tracks[ui.sel].v.sl,0];
  if(ui.layer==='param')return allArr(tracks[k],p);
  if((p.key==='sA'||p.key==='sB')&&k===3&&tapeF(p.key==='sA'?0:1))return[sendShared[p.key==='sA'?0:1],8];
  if((p.key==='sA'||p.key==='sB')&&k!==0&&k!==6)return[sendShared[p.key==='sA'?0:1],k];
  if(p.key==='mod'&&ui.shift&&k>=6)return[tracks[ui.sel].env,k-6];
  if(p.key==='fx'&&ui.shift&&eqK(tracks[ui.sel],k))return[tracks[ui.sel].v.eq,k>>2];
  if(p.key==='fx'&&k===scK(tracks[ui.sel]))return[tracks[ui.sel].v.sc,ui.shift?0:1];
  if(p.key==='fx'&&isGrainShift(tracks[ui.sel],k))return[tracks[ui.sel].v.gx,gxIdx(k)];
  if(p.key==='mod'&&ui.shift&&k===5)return[tracks[ui.sel].v.edp,0];          /* mod envelope depth */
  if(p.key==='mod'&&ui.shift&&(k===0||k===2))return[tracks[ui.sel].v.hz,k/2]; /* LFO free in Hz, 0 = on the clock */
  return[tracks[ui.sel].v[p.key],pdi(p,k)];}
/* CHAOS works on all tracks like the rest of PERFORM; hold one track pad (row 1) and turn = only that track (Lef 22 nov) */
const chT=()=>held0.size===1?[...held0][0]:ui.sel;
function encGet(k){if(k==='vol')return volume;if(k==='jog')return bpm;const[a,i]=encRef(k);return a[i];}
function encSet(k,v){v=Math.max(0,Math.min(127,v));if(k==='vol'){volume=v;return;}
  if(ui.layer!=='param'&&page().key==='macros'&&ui.shift&&k===6){encRef(k)[0][0]=v;tracks[ui.sel].noise=fromV(v,4);return;}const[a,i]=encRef(k);const o=a[i];a[i]=v;
  if(ui.layer==='perf'&&page().key!=='stut'&&k===0&&held0.size!==1)tracks.forEach(t=>t.v.chs[0]=v);
  if(ui.layer==='perf'&&page().key==='stut'&&ui.shift){if(k===0)tracks.forEach(t=>t.v.sauto[0]=v);else if(STK_SH[k]!=null)stutShared[i]=v;else{tracks.forEach(t=>t.v.stu[i]=v);stutShared[i]=v;}}   /* SHIFT: all tracks and the master repeat; ENV DEST and LFO SPEED: this track and the master */
  const th=tracks.find(t=>t.eng===THUMP&&t.v.cv===a);if(th&&fromV(o,TH_NA)!==fromV(v,TH_NA))thumpDef(th);   /* a new kick model starts from its own defaults */
  const t=tracks.find(t=>t.v.pat===a);if(t&&i>=4&&i<=6)patKnob(t,i);
  if(t&&i===7&&ui.shift&&ui.layer==='track')tracks.forEach(o=>o.v.pat[7]=v);  /* SHIFT + CLOCK: all tracks */
  const h=tracks.find(t=>t.v.macros===a);if(h&&h.home)h.home[i]=v; /* a turned macro becomes the new home of VAR.S */
  const q=tracks.find(t=>t.v.pitch===a);if(q&&i===2&&folSrc(q)<0){const key=String(pRange(q));if(key!==q.pkey){q.pkey=key;pitchGen(q);}}}
/* PATTERN knobs DENS / ROTATE / LENGTH drive the same values as the density and rotate pads and Shift + / - */
function patKnob(t,i){const v=t.v.pat[i];
  if(i===4){const q=Math.round(v/127*16);if(q!==Math.round(t.dens/7*16)){t.dens=q/16*7;t.steps=gen(t);}}
  else if(i===5){} /* RND.V: read by the core */
  else{const n=1+v;if(n!==t.len){setLen(t,n);if(t===tracks[ui.sel])ui.stepPage=Math.min(ui.stepPage,Math.ceil(n/16)-1);}}}
/* how a PATTERN value reads on screen */
/* ACID slides and accents: each step has a fixed random number; a step slides / has an accent when its number is under
   SLIDE / ACCENT (Shift + GLIDE / TURING on PITCH). A new melody rolls new numbers */
function acidRoll(t){t.slR=[...Array(128)].map(()=>rnd());t.acR=[...Array(128)].map(()=>rnd());}
/* ACID per step: a tapped step is fixed on (-1) or off (2), outside the 0..1 range the SLIDE / ACCENT knobs pick from */
const acOn=(t,s)=>t.acR[s]<t.v.ac[0]/127,slOn=(t,s)=>t.slR[s]<t.v.sl[0]/127;
function acidStep(t,s){const st=(acOn(t,s)?1:0)+(slOn(t,s)?2:0),nx=[1,2,3,0][st];
  t.acR[s]=nx&1?-1:2;t.slR[s]=nx&2?-1:2;sync();toast(`STEP ${s+1} `+['PLAIN','ACCENT','SLIDE','ACCENT + SLIDE'][nx]);}
function acidMask(r,v){const w=[0,0,0,0],a=v/127;for(let i=0;i<MAXS;i++)if(r&&r[i]<a)w[i>>5]|=1<<(i&31);return w;}
function pitchShow(t,i,v){if(ui.shift&&ui.layer==='track'&&(i===5||i===6))return pct(v);return i===0?folShow(t):i===1?HARMS[hrmOf(t)]:i===2?(folSrc(t)>=0?(folOff(t)?'OFF':folRange(t)?'+-'+folRange(t):'FULL'):pRange(t)===36?'FULL':pRange(t)?String(pRange(t)):'OFF'):i===3?(pMode(t)?'B':'A'):
  i===4?String(pLen(t)):i===5?(v?String(v).padStart(3,'0'):'LOCK'):i===6?(v?timeShow(2*Math.pow(v/127,2)):'OFF'):i===7?(pOct(t)>0?'+':'')+pOct(t):String(v).padStart(3,'0');}   /* PORTA: 0..2 s */
function patShow(t,i,v){return i===4?Math.round(t.dens/7*100)+'%':i===6?String(t.len):i===7?cdiv(v):String(v).padStart(3,'0');}
const LONG_PG={glob:{TYPE:'COMPRESSOR TYPE: GLUE PUNCH SMASH',MIX:'COMPRESSOR MIX: DRY < > COMPRESSED',SAT:'COMPRESSOR SATURATION'},sA:{TYPE:'SEND A EFFECT TYPE'},sB:{TYPE:'SEND B EFFECT TYPE'},pat:{LENGTH:'TRACK LENGTH'},pitch:{LENGTH:'LANE LENGTH'},stut:{RAMP:'RAMP: 1-3 STEPS FASTER OVER THE STUTTER',BREAK:'BREAK: REPEATS REVERSED OR SKIPPED',SHAPE:'SHAPE: EACH REPEAT OPEN TO TIGHT','VAR.C':'VARIATION CLOCK: LEFT SLOWER, RIGHT FASTER, ON THE GRID',LFO:'LFO OVER THE STUTTER, SHIFT: SPEED, HOLD + PAD: DEST',DEST:'DESTINATION',SPEED:'LFO SPEED: STUTTER LENGTH, THEN CLOCK DIVS',MIX:'STUTTER MIX',PROB:'PROB: CHANCE THAT A HIT STUTTERS',LENGTH:'STUTTER LENGTH: ONE REPEAT, 1/128 TO 1 BAR'},fx:{SIZE:'SIZE'},sA:{SIZE:'SIZE'},sB:{SIZE:'SIZE'}};   /* the same label means something else on these pages */
const long=l=>(page().key==='macros'&&tracks[ui.sel].eng===THUMP&&thLong(tracks[ui.sel],l))||(LONG_PG[page().key]||{})[l]||LONG[l]||dn(l);
/* SHIFT on a knob that has no Shift function of its own: the value goes to every track (FX slots: every track with the same effect there) */
function shiftFree(k){if(!ui.shift||typeof k!=='number'||(ui.layer!=='track'&&ui.layer!=='fx'))return false;
  const a=encRef(k);ui.shift=false;const b=encRef(k),lab=encLabels()[k];ui.shift=true;
  return a[0]===b[0]&&a[1]===b[1]&&lab!=='----'&&Object.keys(tracks[ui.sel].v).some(n=>tracks[ui.sel].v[n]===a[0]);}
function applyAll(k,eng){const t=tracks[ui.sel],[a,i]=encRef(k),key=Object.keys(t.v).find(n=>t.v[n]===a),v=a[i];   /* eng: only tracks with the same engine */
  tracks.forEach(u=>{if(u===t)return;if(key==='fx'&&u.slot[i>>2]!==t.slot[i>>2])return;if(eng&&u.eng!==t.eng)return;if(!u.v[key])u.v[key]=[0];u.v[key][i]=v;if(key==='nc')u.noise=fromV(v,4);
    if(key==='pat'&&i>=4&&i<=6)patKnob(u,i);if(key==='macros'&&u.home)u.home[i]=v;
    if(key==='pitch'&&i===2&&folSrc(u)<0){const kk=String(pRange(u));if(kk!==u.pkey){u.pkey=kk;pitchGen(u);}}});}
function encName(k){if(k==='vol')return'VOLUME';if(k==='jog')return'TEMPO';
  if(shiftFree(k))return'ALL TRACKS '+long(encLabels()[k]);
  if(ui.layer==='param')return`${ui.shift?'ALL TRACKS':'T'+(k+1)} ${long(allLab(page()))}`;
  if(ui.layer==='perf'||ui.layer==='glob')return(page().key==='stut'?(ui.shift?'ALL: ':`T${ui.sel+1} `):page().key==='perf'?(k===0?(ui.shift?'ALL: ':`T${ui.sel+1} `):'ALL TRACKS '):'')+long(encLabels()[k]);   /* PERFORM knobs act on all tracks */if(page().key==='fx'&&typeof k==='number')return`T${ui.sel+1} SLOT ${(k>>2)+1} ${FX[tracks[ui.sel].slot[k>>2]][0]}: ${long(encLabels()[k])}`;
  if((page().key==='sA'||page().key==='sB')&&typeof k==='number'){const n=page().name;
    return k===0?`T${ui.sel+1}: ${n} AMOUNT`:k===6?`T${ui.sel+1}: ${n} PRE / POST`:`${n}, ALL TRACKS: ${long(encLabels()[k])}`;}return`T${ui.sel+1} ${long(encLabels()[k])}`;}
const globShow=(i,v)=>i===0?(mainOn()?SCALES[gScale()][0]:'OFF'):i===1?(mainOn()?NOTES[fromV(v,12)]:'----'):i===2?COMP_TYPES[fromV(v,3)]:
  i===3?Math.round(-40+v/127*40)+'DB':i===4?(v>=126?'LIMIT':(1+19*(v/127)**2).toFixed(1)):i===5?(ui.shift?Math.round(10*Math.pow(2,v/127*7.2))+'MS':(0.1*Math.pow(2,v/127*10)).toFixed(1)):num(v);
/* a knob on a category page: an own knob, or the v106 knob it comes from (in its own page, with SHIFT as the page wants it) */
let holdRender=0;
/* a step held + a knob: the value goes to that step only (a P-LOCK, on the REC lanes); the knob itself stays (Lef 19 nov) */
const stepLockOn=k=>!ui.slkIn&&ui.heldStep!=null&&typeof k==='number'&&!ui.menu&&!ui.delHeld&&!ui.sendEdit&&ui.layer==='track'&&page().key!=='pitch'&&!cpage().src&&!linking();
function stepLock(k,d){const t=tracks[ui.sel],s=ui.stepPage*16+ui.heldStep,sp=kSpec(k);if(s>=t.len||!sp||sp.off&&sp.off(t))return;
  const o=sp.own&&OWN[sp.own];if(o&&o.lab(t)==='----')return;
  const ctx=o?null:ctxOf(sp),kid=o?'own/'+sp.own+'/'+(ui.shift?1:0):withCtx(ctx,()=>recKid(sp.src[2]));
  if(!o&&NOREC.has(kid)){toast('THIS KNOB CANNOT BE SET PER STEP');return;}
  let st=ui.slk;if(!st||st.s!==s||st.kid!==kid||st.sel!==ui.sel){
    pushUndo('slk'+ui.sel+'/'+s+kid);const base=snapAll(),b=probe(),ex=(t.lanes||[]).find(l=>l&&l.kid===kid&&l.u[s]>=0);
    if(ex){if(o)ownPut(o,t,ex.u[s]);else withCtx(ctx,()=>encSet(sp.src[2],ex.u[s]));}
    st=ui.slk={s,kid,sel:ui.sel,base,b,start:snapAll(),acc:0};}
  st.acc+=d;ui.stepLk=ui.heldStep;
  const nU=ui.undos.length,rec=ui.rec;ui.rec=false;ui.slkIn=true;let after,uv,info;
  try{applySnap(st.start);turn(k,st.acc);after=probe().p[ui.sel];uv=o?ownVal(o,t):withCtx(ctx,()=>encGet(sp.src[2]));info=knobInfo(k,{});}
  finally{ui.slkIn=false;ui.rec=rec;applySnap(st.base);ui.undos.length=Math.min(ui.undos.length,nU);}
  ui.slkShow=ui.slkShow||{};ui.slkShow[k]=info;ui.slkStep=s;ui.slkPg=slkPgKey();   /* the knob's cell shows the step's value while the step is held (Lef 19 nov) */
  const L=lanesOf(t),was=st.b.p[ui.sel];let full=false;
  after.forEach((v,i)=>{let l=L.find(l=>l&&l.p===i);const same=Math.abs(v-was[i])<=1e-6;
    if(same){if(l&&l.kid===kid){l.v[s]=-1;l.u[s]=-1;}return;}
    if(!l){const j=L.indexOf(null);if(j<0){full=true;return;}l=L[j]={p:i,kid,v:Array(TRACK_STEPS).fill(-1),u:Array(TRACK_STEPS).fill(-1)};}
    l.kid=kid;l.v[s]=v;l.u[s]=uv;(l.pk||(l.pk=Array(TRACK_STEPS).fill(0)))[s]=1;});   /* pk: set by hand, a P-LOCK (DELETE menu tells them from REC) */
  L.forEach((l,j)=>{if(l&&l.v.every(x=>x<0))L[j]=null;});
  if(!t.steps[s]&&!full)t.steps[s]=true;   /* an empty step that gets a P-lock plays (Lef 24 nov) */
  toast(full?'REC FULL: 16 KNOBS, SHIFT + REC CLEARS':`STEP ${s+1}  ${rnd2(info.lab,t)} ${info.txt}`,1500);ui.touched=k;touchT=performance.now();sync();render();}
function turn(k,d){if(stepLockOn(k)){stepLock(k,d);return;}
  if(ui.menu==='looper'&&typeof k==='number'){looperTurn(k,d);return;}
  if(ui.menu==='song'&&typeof k==='number'){songTurn(k,d);return;}
  if((ui.menu==='rename'||ui.menu==='type')&&typeof k==='number')return;
  if(ui.sendEdit&&k===0){sendEditTurn(d);return;}
  if(ui.fxPick){if(k===0)fxPickTurn(d);return;}
  if(typeof k!=='number'||cpage().src||ui.delHeld){turnOld(k,d);return;}
  {const s=kSpec(k);if(s&&s.src&&s.src[0]==='track'&&s.src[1]===1&&s.src[2]===6){   /* LENGTH: one step per click, on from the length it has (Lef 17 nov); SHIFT = all tracks */
    const T0=tracks[ui.sel],L0=T0.len,L1=lenStep(L0,d);if(L1===L0){ui.touched=k;touchT=performance.now();render();return;}
    pushUndo('len');(ui.shift?tracks:[T0]).forEach(t=>setLen(t,t===T0?L1:lenMove(t.len,L1-L0)));
    const t=tracks[ui.sel];ui.stepPage=Math.min(ui.stepPage,Math.ceil(t.len/16)-1);ui.touched=k;touchT=performance.now();sync();render();return;}}
  const s=kSpec(k),sh=ui.shift;if(!s||s.off&&s.off(tracks[ui.sel]))return;ui.toast=null;
  if(s.src&&s.src[0]==='track'&&s.src[1]===3&&s.src[2]===4){const t=tracks[ui.sel],v0=t.v.pitch[4],L0=pLen(t),L1=lenStep(L0,d);   /* PITCH LENGTH: the same as TRIGGERS (Lef 24 nov) */
    if(L1===L0){ui.touched=k;touchT=performance.now();render();return;}
    d=lenV(L1)-v0;}
  if(s.own){const o=OWN[s.own],kid='own/'+s.own+'/'+(ui.shift?1:0),rec=ui.rec&&ui.playing&&catName()==='ENGINE',before=rec?probe():null;   /* the newer knobs are recorded too (Lef 19 nov) */
    ownTurn(s.own,k,d);if(rec)recDiff(k,before,kid,ownVal(o,tracks[ui.sel]));}
  else withCtx(ctxOf(s),()=>{turnOld(s.src[2],d);if(s.all&&sh&&ui.layer==='track')applyAll(s.src[2],s.eng);});   /* a knob without a SHIFT job: SHIFT sets every track (ENGINE: whatever its engine, Lef 13 nov; ENGINE 2: the same engine only) */
  ui.touched=k;touchT=performance.now();render();}
function turnOld(k,d){ui.toast=null;
  if(ui.delHeld&&typeof k==='number'){ui.delUsed=true;const s=cpage().src?{src:[ui.layer,ui.enc[ui.layer],k]}:kSpec(k);if(!s)return;
    if(s.own){const kid=ownKid(s.own);if(ui.delKid!==kid){ui.delKid=kid;ownClear(s.own);}return;}   /* own knobs too (Lef 22 nov) */
    withCtx(ctxOf(s),()=>{const kk=s.src[2];if(ui.delKid!==recKid(kk)){ui.delKid=recKid(kk);recClearKnob(kk);}});return;}
  const rec=ui.rec&&ui.playing&&typeof k==='number'&&!NOREC.has(recKid(k)),before=rec?probe():null;
  if(k==='jog'&&ui.menu){menuMove(Math.sign(d));return;}
  if(k==='jog'&&pitchStep()){degBy(Math.sign(d));return;}
  if(k==='jog'){bpm=Math.max(40,Math.min(240,ui.shift?Math.round((bpm+Math.sign(d)*.1)*10)/10:Math.round(bpm)+Math.sign(d)));ui.touched='jog';}   /* whole BPM per click; SHIFT = 0.1 (Lef 13 nov) */
  else if(ui.layer==='param'&&ui.shift&&typeof k==='number'){const key=allVD(page())?'vd':page().key,i=allVD(page())?0:pdi(page(),allPar());
    tracks.forEach(t=>{const a=t.v[key];a[i]=Math.max(0,Math.min(127,a[i]+d));if(key==='pat'&&i>=4&&i<=6)patKnob(t,i);if(key==='macros'&&t.home)t.home[i]=a[i];});ui.touched=k;}
  else if(shiftFree(k)){encSet(k,encGet(k)+d);applyAll(k);ui.touched=k;}
  else{if(encLabels()[k]==='----'&&k!=='vol')return;encSet(k,encGet(k)+d);ui.touched=k;}
  if(rec)recDiff(k,before);touchT=performance.now();render();}
let touchT=0;
function bindEnc(b,k){let y0=null,acc0=0,moved=false,enterT=0;
  b.addEventListener('pointerdown',e=>{e.preventDefault();b.setPointerCapture(e.pointerId);y0=e.clientY;acc0=0;moved=false;ui.touched=k;ui.held=k;ui.heldM=heldMacro(k);
    if(ui.layer==='track'&&page().key==='mod'&&typeof k==='number'){if(ui.shift&&k>=5)ui.modEnv=true;else{ui.modEnv=false;ui.modSrc=k>>1;}}ui.toast=null;touchT=Infinity;render();});
  b.addEventListener('pointermove',e=>{if(y0==null)return;if(e.pointerType==='mouse'&&e.buttons===0){drop();return;}   /* the button was let go somewhere we did not hear: no turning on a mere hover */
    acc0+=(y0-e.clientY)*(ui.shift&&!(k==='jog'&&ui.menu)?.25:1);y0=e.clientY;
    const q=k==='jog'&&ui.menu?8:2,d=Math.trunc(acc0/q);if(d){acc0-=d*q;moved=true;turn(k,d);touchT=Infinity;}}); /* in a menu the jog needs a clear turn, so a tap is a press */
  const up=()=>{if(y0==null)return;y0=null;ui.held=null;ui.heldM=null;touchT=performance.now();if(k==='jog'&&!moved&&ui.menu)jogPress();render();};
  const drop=()=>{if(y0==null)return;y0=null;ui.held=null;ui.heldM=null;touchT=performance.now();render();};
  b.addEventListener('pointerup',up);b.addEventListener('pointercancel',drop);b.addEventListener('lostpointercapture',drop);
  b.addEventListener('pointerenter',()=>{enterT=performance.now();});
  b.addEventListener('wheel',e=>{if(performance.now()-enterT<300)return;   /* a scroll that only passes over the knob scrolls the page */
    e.preventDefault();turn(k,e.deltaY<0?(ui.shift?1:4):(ui.shift?-1:-4));},{passive:false});
  b.tabIndex=0;}
document.addEventListener('keydown',e=>{
  if(e.code==='Space'){e.preventDefault();if(!e.repeat)togglePlay();}
  else if(e.key==='Shift'&&!ui.shift)setShift(true);
  else if((e.key==='m'||e.key==='M')&&!e.repeat)muteDown();
  else if(e.code==='NumpadAdd'||e.code==='NumpadSubtract'){e.preventDefault();const d=e.code==='NumpadAdd'?1:-1;pitchStep()?degBy(d):pageBy(d);}
  else if(['Digit9','Digit0','Minus','Equal'].includes(e.code)&&!e.repeat&&!/INPUT|TEXTAREA/.test(e.target.tagName)){e.preventDefault();if(ui.menu)menuToggle(false);catPress(['Digit9','Digit0','Minus','Equal'].indexOf(e.code));render();}   /* 9 0 - = : TRIGGERS PITCH ENGINE PERF, also out of the menu */
  /* web app only: left / right = knob pages like + / -, with Shift = step pages like < > */
  /* web app: up / down = knob pages (like + / -), left / right = track length, Shift + left / right = nudge, [ ] = step pages (like < >), comma = MENU, period = PRESETS */
  else if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();const d=e.key==='ArrowUp'?1:-1;
    if(ui.menu)menuMove(-d);else if(pitchStep())degBy(d);else arrowPage(-d,e.repeat);}
  else if(e.key==='Enter'&&ui.menu){e.preventDefault();if(!e.repeat)jogPress();}
  else if(e.key==='Escape'&&ui.menu){e.preventDefault();menuBack();}
  else if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();const d=e.key==='ArrowLeft'?-1:1;onGlobal()?mlenBy(d):ui.shift?nudge(d):lenBy(d);}
  else if((e.code==='Comma'||e.code==='Period')&&!e.repeat){e.preventDefault();   /* , = MENU, . = PRESETS (again = close) */
    if(e.code==='Period'){presetKey(e.shiftKey||ui.shift);return;}if(ui.menu==='main')menuToggle(false);else{ui.menu='main';ui.confirm=null;ui.toast=null;render();}}
  else if(e.code==='BracketLeft'||e.code==='BracketRight'){e.preventDefault();stepPageBy(e.code==='BracketLeft'?-1:1);}
  else if(/^[1-5]$/.test(e.key)&&linking()){toggleRoute(+e.key-1);}
  else if((e.key==='l'||e.key==='L')&&!e.repeat)loopPress();
  else if((e.key==='c'||e.key==='C')&&!e.repeat)copyDown();
  else if((e.key==='k'||e.key==='K')&&!e.repeat)capDown();
  else if(e.code==='KeyU'&&!e.repeat)undoPress(ui.shift);
  else if(e.code==='KeyR'&&!e.repeat)recPress();
  else if((e.code==='KeyN'||e.code==='KeyV')&&!e.repeat)soundKey(e.code==='KeyV');
  else if((e.key==='Delete'||e.key==='Backspace')&&!e.repeat){e.preventDefault();delDown();}
  /* track keys 1-8; Shift + 1-8 = solo (Shift turns the digit into a symbol, so read the key position) */
  else if((/^[1-8]$/.test(e.key)||((ui.muteHeld||e.shiftKey)&&/^Digit[1-8]$/.test(e.code)))&&!e.target.closest('.enc')){const c=/^Digit/.test(e.code)?+e.code.slice(5)-1:+e.key-1;if(!e.repeat){trackKey(c);held0.add(c);}render();}});
document.addEventListener('keyup',e=>{if(e.key==='Delete'||e.key==='Backspace')delUp();if(/^Digit[1-8]$/.test(e.code)){held0.delete(+e.code.slice(5)-1);swapUp(+e.code.slice(5)-1);}if(e.key==='Shift')setShift(false);if(e.key==='m'||e.key==='M')muteUp();if(e.key==='c'||e.key==='C')copyUp();if(e.key==='k'||e.key==='K')capUp();});
window.addEventListener('blur',()=>{ui.delHeld=false;ui.shift&&setShift(false);ui.muteHeld&&muteUp();copyUp();held0.clear();stutAllOff();});

/* ---------- fallback clock (visual only, used when the browser has no AudioWorklet) ---------- */
let last=performance.now(),acc=0;
function tick(now){
  if(ui.playing&&!audio.ready){acc+=now-last;const stepMs=60000/bpm/4; /* visual clock only when there is no sound */
    while(acc>=stepMs){acc-=stepMs;ui.pos++;
      tracks.forEach((t,i)=>{ui.tpos[i]=ui.pos%t.len;ui.ppos[i]=ui.pos%pLen(t);if(ui.pos%t.len===0){const v=t.v.pat[0]/127;varySteps(i);soundVar(i);pitchVar(i);}});}
    render();}
  last=now;
  if(ui.touched!=null&&touchT!==Infinity&&now-touchT>900){ui.touched=null;draw();}
  if(ui.toast&&now-ui.toastT>(ui.toastMs||1200)){ui.toast=null;draw();}
  if(ui.big&&now>ui.big.until){ui.big=null;draw();}
  requestAnimationFrame(tick);}
requestAnimationFrame(tick);

/* ---------- render ---------- */
function rot(e,v){e.querySelector('i').style.transform=`rotate(${180+(v/127)*300-150}deg)`;}
/* the wordmark cursor blinks on the beat: on the playhead while playing, at the tempo while stopped */
function curBeat(){const c=document.querySelector('.wm .cur');if(!c)return;c.style.setProperty('--beat',(60/bpm).toFixed(3)+'s');
  if(ui.playing&&ui.pos>=0){c.classList.add('sync');c.style.opacity=ui.pos%4<2?'1':'0';}else{c.classList.remove('sync');c.style.opacity='';}}
function render(){if(holdRender)return;curBeat();
  const t=tracks[ui.sel],p=page(),own=!cpage().src,K=own?knobInfos():null,labels=own?K.map(k=>dn(k.lab,t)):encLabels().map(l=>rnd2(l,t));
  pills.forEach((b,i)=>b.classList.toggle('on',i===ui.cat));
  fn.SHIFT.classList.toggle('held',ui.shift);fn.PLAY.classList.toggle('on',ui.playing);
  {const np=Math.ceil(t.len/16);fn.PREV.classList.toggle('on',ui.shift||ui.stepPage>0);fn.NEXT.classList.toggle('on',ui.shift||ui.stepPage<np-1);}   /* < > lit = there is a step page that way (SHIFT: nudge / MASTER LENGTH) */
  fn.MUTE.classList.toggle('on',ui.muteMode&&!ui.muteHeld);fn.CAP.classList.toggle('on',!!ui.cap);fn.REC.classList.toggle('on',!!((ui.sg||0)&5));fn.RECB.classList.toggle('on',ui.rec);{const q=ui.modSrc;fn.LOOP.classList.toggle('on',!!ui.loop||ui.layer==='track'&&p.key==='mod'&&q>=2&&t.rloop[q-2]);}fn.MUTE.classList.toggle('held',ui.muteHeld);
  encs.forEach((e,i)=>{const s=own&&kSpec(i),m=own?(s&&s.src&&s.src[0]==='track'&&s.src[1]===0?s.src[2]:-1):ui.layer==='track'&&p.key==='macros'?i:-1;
    rot(e,own?K[i].val:encGet(i));pix(encL[i],labels[i],3);e.style.opacity=labels[i]==='----'?'.35':'1';
    const rc=own?!!K[i].rec:recMark(i);leds[i].classList.toggle('on',m>=0&&t.routes[m]!==0&&!t.modOff[m]);leds[i].classList.toggle('rec',rc);   /* knob LED (Lef 26 nov): steady = modulation, blinking = a REC recording (wins) */
    encs[i].classList.toggle('mot',rc);});
  rot(vol,volume);
  pads.forEach((row,r)=>row.forEach((b,c)=>{let bg='',op='1',ol='';
    if(r===0){bg=hitLit(c)?'var(--lit)':TC(c);op=silent(tracks[c])?'.18':'1'; /* a silent track stays faintly visible (pulsing when a solo silences it); a hit flashes */
      if(c===ui.sel&&!ui.muteMode&&!ui.muteHeld)ol='2px solid var(--lit)';}
    else{const fl=ui.flash&&ui.flash.r===r&&(ui.flash.c===c||ui.flash.c===-1),lit=v=>{bg=v?'var(--lit)':bg;if(v)op='1';},nm=(ui.cat<3?PADS[ui.cat]:[])[c];
    if(ui.cat===0){
      if(r===1&&ROW2_COL[nm]){const on=nm==='FILL'?ui.fillPad===c:padOn(t,nm);bg=ROW2_COL[nm];op=on?'1':'.3';lit(fl&&nm!=='FILL');}   /* VAR.1 + V1.INT one colour, VAR.2 + V2.INT another, FILL its own; on = bright (Lef 25 nov) */
      else if(r===1&&nm){bg='var(--ink-muted)';op=padOn(t,nm)?'1':'.45';lit(fl||ui.tw&&ui.tw.pad===c);}
      else if(r===2){const on=stutShared[c<4?10:11]===c%4+1;bg='var(--track-7)';op=on?'1':'.3';}   /* RISE / SWEEP: purple */
      else if(r===3){bg='var(--track-6)';op='.45';lit(ui.repeat===c);}}   /* REPEAT: blue */
    else if(ui.cat===1){const R=pRange(t);
      if(r===1&&nm){bg='var(--ink-muted)';op=padOn(t,nm)?'1':'.45';lit(fl||ui.tw&&ui.tw.pad===c);}
      else if(r===3){bg='var(--ink-muted)';op=R?'.45':'.2';lit(ui.pv&&ui.pv.c===c);}}
    else if(ui.cat===2||sendPg()){const pg=ui.cp[2];
      if(r===3){const k=c<4?'sA':'sB',l=sendLvl(t,k),on=l===c%4;bg=l<0?(c%4===0?'var(--lit)':''):c%4<=l?TC(ui.sel):'';op=on||l<0?'1':'.45';   /* send off: pad 1 white */
        if(c%4===3){bg=spv(t)[c<4?0:1]!==44?'var(--snd4c)':'var(--snd4)';op=on?'1':'.3';}}   /* pad 4 / 8: its own colour, another when its value is not the default */
      else if(ui.cat!==2){}
      else if(pg===FXPG){const on=t.slot[r-1]===padFx((r-1)*8+c);bg=on?'var(--lit)':TC(ui.sel);op=on?'1':'.28';}
      else if(r===1&&nm){bg=TC(ui.sel);op=nm==='MUT.S'?'.45':'1';lit(fl);}   /* MUT.S dimmer than RND.S */
      else if(r===2&&c===0&&smFile(t)){bg='var(--track-4)';op=ui.menu==='files'?'1':'.45';}   /* LOAD: green (Lef 18 nov), bright while the file list is open */
      else if(r===2&&c<2&&wtE(t)){bg='var(--track-4)';op=ui.menu==='files'&&ui.fwt===c?'1':'.45';}   /* LOAD.A / LOAD.B: green like LOAD (Lef 20 nov) */
      else if(r===2&&c===0&&t.eng===SAMPLE){bg='var(--rec)';op=(ui.smr||0)>>ui.sel&1?'1':'.45';}   /* SAMPLE REC: red, bright while recording */
      else if(r===2&&c===1&&t.eng===SAMPLE&&!smFile(t)){bg='var(--track-2)';op=(ui.smr||0)>>16+ui.sel&1?'1':'.45';}   /* OVERDUB: orange, bright while it runs */
      else if(r===2&&c===7&&t.eng===SAMPLE){const m=smv(t)[7];bg='var(--track-6)';op=m>0?String(0.35+0.65*m/127):'.12';}   /* MONITOR: blue, as bright as MON.L (Lef 22 nov) */
      else if(r===2&&c===2&&t.eng===SAMPLE){bg='var(--track-4)';op=(ui.smr||0)>>24+ui.sel&1?'1':'.45';}   /* PLAY: green, bright while it plays (Lef 18 nov) */
      else if(r===2&&c===2){bg='var(--track-4)';op='.45';lit(fl);}   /* PLAY on every other engine: one hit on the ROOT note (Lef 22 nov) */
      else if(r===2&&c===3&&smRadio(t)){bg='var(--track-7)';op='1';lit(fl);}   /* RND.R: purple, only on ALGO RADIO */
}
    else if(ui.layer==='param'){
      if(r===1){bg=c===ui.param?'var(--lit)':'var(--ink-muted)';op=c===ui.param?'1':'.25';}
      else if(r===2){bg=TC(c);op='.35';lit(fl);}
      else if(r===3&&c===0){bg='var(--ink-muted)';op='.6';lit(fl);}
      else if(r===3&&c===1&&p.key==='macros'){bg=ui.param===ALL_VD?'var(--lit)':'var(--ink-muted)';op=ui.param===ALL_VD?'1':'.25';}}
    else{
      if(r===1){bg=TC(c);op='.6';lit(fl);}
      else if(r===2&&c<MUT_BTN.length||r===3&&c<DEF_BTN.length){bg=DEF_COL[c];op=r===2?'.55':'.35';lit(fl);}}}
    b.classList.toggle('blink',r===0&&ui.muteQueue.has(c)||r===2&&c===2&&bg==='var(--track-4)'&&genNew(ui.sel)||r===2&&c===0&&bg==='var(--rec)'&&((ui.smr||0)>>8+ui.sel&1)===1);   /* SAMPLE REC waits for the bar: blinks */
    b.classList.toggle('soloff',r===0&&!tracks[c].mute&&anySolo()&&!tracks[c].solo&&!ui.muteQueue.has(c));
    b.style.background=bg||'var(--raised)';b.style.opacity=bg?op:'1';b.style.outline=ol;b.style.outlineOffset=ol?'2px':'';}));
  steps.forEach((b,i)=>{let on=false,head=false,ol='';b.style.setProperty('--tc',TC(ui.sel));
    if(linking()){on=i<5&&(t.routes[ui.heldM]>>i&1)===1;b.style.setProperty('--tc','var(--lit)');b.style.opacity=i<5?'1':'.3';}
    else if(ui.layer==='track'&&p.key==='mod'){const q=ui.modSrc;b.style.setProperty('--tc','var(--lit)');
      if(q<2){on=t.waves[q]===i;b.style.opacity=i<7?'1':'.3';}else{on=i<t.rlen[q-2];b.style.opacity='1';}}
    else if(ui.layer==='track'&&p.key==='pitch'){const s=ui.stepPage*16+i,n=pLen(t),R=pRange(t);
      on=s<n;head=ui.playing&&s===ui.ppos[ui.sel];b.style.setProperty('--tc',TC(ui.sel));
      b.style.opacity=s>=n?'.3':R?String(.3+.7*t.pdeg[s]/R):'.5';
      if(t.eng===ACID&&s<n){if(acOn(t,s)){b.style.setProperty('--tc','var(--lit)');b.style.opacity='1';}if(slOn(t,s))ol='2px solid var(--lit)';}}
    else if(snapSteps()&&!(ui.patUntil>performance.now())){on=!!ui.snaps[i];if(ui.lastSnap===i)b.style.setProperty('--tc','var(--lit)');else{b.style.setProperty('--tc','var(--ink-muted)');}b.style.opacity='1';}
    else{const s=ui.stepPage*16+i;on=s<t.len&&(t.gen===8?!!(ui.oh&&ui.oh[ui.sel]&&ui.oh[ui.sel][s]):t.steps[s]);head=ui.playing&&s===ui.tpos[ui.sel];b.style.opacity=s<t.len?'1':'.3';}
    b.classList.toggle('st',on);b.classList.toggle('head',head);b.style.outline=ol;b.style.outlineOffset=ol?'2px':'';});
  helpRender();draw();sync();}

/* ---------- OLED (128x64, 1-bit), drawn in font4x5 ---------- */
const cv=document.getElementById('oled'),x=cv.getContext('2d');
/* a click on the screen picks a row of the open list; a click on the picked row presses it */
cv.addEventListener('pointerdown',e=>{if(!ui.menu||ui.saver)return;const r=cv.getBoundingClientRect(),py=(e.clientY-r.top)/r.height*64,row=Math.floor((py-11)/8);
  if(row<0||row>4||!ui.rows)return;const i=ui.rows.top+row;if(i>=ui.rows.n)return;e.preventDefault();
  if(i===ui.rows.cur){jogPress();return;}
  if(ui.menu==='main')ui.mi=i;else if(ui.menu==='presets'){if(ui.rows&&ui.rows.acts)ui.pa=ui.rows.vis?ui.rows.vis[i]:i;else ui.pi=i;ui.confirm=null;}else if(ui.menu==='engine'){if(ENG_ROWS[i].h)return;engBy(engPos(ENG_ROWS[i].e)-engPos(tracks[ui.sel].eng));}else ui.si=i;ui.toast=null;render();});
const txt=(s,X,Y)=>glyphs(x,s,X,Y);
const num=v=>String(Math.round(v)).padStart(3,'0');
function fit128(s){while(s.length&&tw(s)>126)s=s.slice(0,-1);return s;}
function bar(X,Y,w,v,bi){const f=Math.round(v/127*w);for(let k=0;k<w;k+=2)x.fillRect(X+k,Y+1,1,1);
  if(!bi){x.fillRect(X,Y,f,3);return;}
  /* bipolar (PAN, FILTER): grows from the middle; in the centre zone only a 2 px mark */
  const c=w/2;if(v>=bi[0]&&v<=bi[1])x.fillRect(X+c-1,Y,2,3);else if(v<bi[0])x.fillRect(X+f,Y,Math.max(2,c-f),3);else x.fillRect(X+c,Y,Math.max(2,f-c),3);}
function header(l,r){if(capt)return;x.fillStyle='#fff';x.fillRect(0,0,128,9);x.fillStyle='#000';txt(l,2,2);txt(r,126-tw(r),2);x.fillStyle='#fff';}
/* 2 rows of 4 cells; the knob being turned is shown inverted, the page itself stays put */
let capt=null;   /* set: cells() and header() keep what they would draw, per knob, instead of drawing it */
function cells(labels,vals,mods,fmt,bip){const t=tracks[ui.sel];labels=labels.map(l=>rn(l,t));
  if(capt){for(let i=0;i<8;i++){const rv=recShow(i),v=rv!=null?rv:vals[i];capt[i]={lab:labels[i],val:v,rec:recMark(i),bip:bip&&bip(i),
    txt:labels[i]==='----'?'':(fmt?fmt(i,v):num(v))+(mods&&mods[i]?' ~':'')};}return;}
  for(let i=0;i<8;i++){const cx=(i%4)*32,cy=12+Math.floor(i/4)*21;
  const hot=ui.touched===i&&labels[i]!=='----';
  if(hot){x.fillRect(cx,cy-2,31,20);x.fillStyle='#000';}
  txt(dn(labels[i],t),cx+1,cy);if(recMark(i))x.fillRect(cx+29,cy-2,2,2);  /* REC: this knob has a recording */
  const rv=recShow(i);if(rv!=null)vals=Object.assign([],vals,{[i]:rv});   /* playing: the knob follows its recording */
  if(labels[i]!=='----'){valTxt((fmt?fmt(i,vals[i]):num(vals[i]))+(mods&&mods[i]?' ~':''),cx+1,cy+7);bar(cx+1,cy+14,28,vals[i],bip&&bip(i));}
  x.fillStyle='#fff';}
}
/* option knobs: a short line on what the picked option does, on the bottom line while the knob is touched (Lef 22 nov) */
const KDESC={MODE:{A:'NOTES RUN ON EVERY STEP',B:'NEXT NOTE ON EVERY HIT'},
  ALGO:{EUCL:'HITS SPREAD EVENLY',TURING:'CHANGES BY ITSELF','ALG.G':'ONE OF 16 GROOVES',ROLL:'RUNS OF 16THS',
    808:'BODY + WHITE NOISE',909:'TWO OSCS + NOISE',XXX:'FM SNARE, X.MOD','000':'FREE MIX OF ALL',MIC:'THE MOVE INPUT',RADIO:'RANDOM WEB RADIO',FILE:'A WAV FROM SAMPLES'},
  HARM:{UNI:'ONE NOTE','3RD':'A 3RD UP IN THE SCALE','4TH':'A 4TH UP IN THE SCALE','5TH':'A 5TH UP IN THE SCALE','6TH':'A 6TH UP IN THE SCALE',OCT:'AN OCTAVE UP',
    '-3RD':'A 3RD DOWN','-5TH':'A 5TH DOWN','-OCT':'AN OCTAVE DOWN',ANSWER:'NOTE BEFORE, 3RD UP'},
  VOICE:{SINGLE:'ONLY THE ROOT',TRIAD:'CLOSE CHORD',SPREAD:'ROOT, 5TH, 3RD UP',DEEP:'SPREAD, ROOT OCT DOWN'},
  CLOCK:{'/8':'8X SLOWER','/4':'4X SLOWER','/3':'3X SLOWER','/2':'HALF SPEED',1:'MASTER SPEED',X2:'TWICE AS FAST',X3:'3X FASTER',X4:'4X FASTER'},
  CHORUS:{OFF:'NO CHORUS',I:'JUNO CHORUS I',II:'JUNO CHORUS II','I+II':'BOTH AT ONCE'},
  'LIST.T':{OFF:'ONLY ITS OWN HITS'},'LIST.M':{POST:'ONLY HITS THAT PASS THE SOURCE PROB',PRE:'EVERY STEP OF THE SOURCE'},'LOOP.N':{OFF:'NO LOOP'}};
const destCatLab=e=>(e.cat?e.cat+' ':'')+e.lab+(e.real?' '+e.real:'');   /* GRID FX FX1.1 FREQ: the slot knob's own name after it (Lef 24 nov) */   /* a destination with its category, as the screen shows it (Lef 22 nov) */
function knobDesc(lab,val){if(typeof val!=='string')return null;let d=(KDESC[lab]||{})[val];
  if(!d&&/\.D$/.test(lab)&&/^(LFO|RND|ENV)/.test(lab)&&val!=='OFF'){const e=destListAll(tracks[ui.sel]).find(x=>x.lab===val);if(e){const r=lab+' > '+destCatLab(e);return tw(r)<=126?r:destCatLab(e);}}
  if(!d&&lab==='SCALE'){const S=SCALES.find(x=>x[0]===val);if(S&&S[1]!==S[0])d=S[1];}
  if(!d&&lab==='LIST.T'&&/^T\d$/.test(val))d='ALSO ON THE HITS OF '+val;
  if(!d&&lab==='LOOP.N'&&/ ST$/.test(val))d='LOOPS THE LAST '+val.replace(' ST',' STEPS');
  if(!d&&lab==='LEN.R')d=val.replace(' ST','')+' 16THS IN A ROW';
  if(!d)return null;for(const r of[lab+' '+val+': '+d,val+': '+d,d])if(tw(r)<=126)return r;return fit128(d);}   /* too wide: the knob's name is on its cell already */
/* the bottom line; a knob of a category page reads like the knob it comes from */
function status(){const k=ui.touched,t=tracks[ui.sel];
  if(!ui.toast&&typeof k==='number'&&ui.slkShow&&ui.slkShow[k]&&ui.heldStep!=null&&ui.slkStep===ui.stepPage*16+ui.heldStep&&ui.slkPg===slkPgKey()){const I=ui.slkShow[k];return`STEP ${ui.stepPage*16+ui.heldStep+1}  ${rnd2(I.lab,t)} ${I.txt}`;}
  if(ui.toast||cpage().src||typeof k!=='number'||linking())return statusOld();
  const s=kSpec(k),idle=()=>{ui.touched=null;try{return statusOld();}finally{ui.touched=k;}};   /* an empty knob: the page's own line */
  if(!s||knobInfo(k,{}).lab==='----')return idle();
  {const K=knobInfo(k,{}),D=knobDesc(K.lab,K.txt);if(D)return D;}
  if(s.own){const o=OWN[s.own],l=o.lab(t),v=ownVal(o,t);
    return(o.glob?'':ui.shift&&o.shAll?'ALL TRACKS ':`T${ui.sel+1} `)+(o.stat||o.long||l)+' '+o.show(t,v);}   /* stat: a short full name, so the value fits on the line */
  const ki=knobInfo(k,{});
  return withCtx(ctxOf(s),()=>{ui.touched=s.src[2];try{let r=statusOld();if(s.lab)r=r.replace(long(encLabels()[s.src[2]]),LONG[s.lab]||dn(s.lab));   /* a knob with a new name says its new name */
    r=s.all&&ui.shift?r.replace(/^T\d /,'ALL TRACKS '):r;
    /* the full name of the knob as the screen shows it (Lef 18 nov: never only the short name), with the value as its cell shows it */
    if(typeof ki.txt==='string'&&ki.txt[0]!==PIC&&ki.txt!==''){const m=r.match(/^(T\d+:? |ALL TRACKS |ALL: )/);return(m?m[1]:'')+long(ki.lab)+' '+ki.txt;}
    return r;}finally{ui.touched=k;}});}
function statusOld(){const t=tracks[ui.sel];
  if(ui.toast)return ui.toast;
  if(ui.copyHeld)return ui.copyStep?'COPY STEP '+(ui.copyStep.s+1)+': PICK TARGETS':ui.copySrc==null?'COPY: PICK THE SOURCE TRACK OR STEP':'COPY T'+(ui.copySrc+1)+': PICK TARGETS';
  if(ui.muteHeld)return ui.shift?'GROUP: PICK, LET GO = FLIP':'TAP = MUTE, SHIFT = SOLO';
  if(ui.loop&&ui.loop.song&&ui.touched==null){const L=ui.loop,S=L.song[Math.max(0,L.k)];return`SONG ${S.r+1}/${S.n} ${(presets.names[L.list[Math.max(0,L.k)]]||'').slice(0,8)} ${S.t}/${S.T} < STOPS`;}   /* SONG MODE runs: row, preset, time */
  if(ui.loop&&ui.touched==null){const L=ui.loop;return`LOOP ${Math.max(1,L.k+1)}/${L.list.length}  ${L.left} BAR${L.left>1?'S':''}  ${L.rep<10?'ROUND '+L.round+'/'+L.rep:'ENDLESS'}`;}   /* the PRESET LOOPER runs: preset, bars left, round */
  if(linking()){const m=t.routes[ui.heldM],l=SOURCES.filter((_,s)=>m>>s&1);return heldName()+': '+(l.length?l.join(' '):'STEP 1-5 LINKS');}
  if(ui.touched==null&&ui.layer==='track'&&page().key==='mod'){const q=ui.modSrc;
    if(ui.modEnv){const l=MACROS.filter((_,c)=>modLinked(t,c));return'ENV > '+(l.length?l.join(' '):'ROW 4 LINKS');}
    if(q<2)return`LFO${q+1} ${WAVES[t.waves[q]]}`;const w=q-2;return`RND ${'AB'[w]} ${t.rloop[w]?'LOOP':'FREE'} ${t.rlen[w]} ${t.rsmooth[w]?'SMOOTH':'STEPPED'}`;}
  if(ui.touched!=null){const k=ui.touched,pk=page().key,v=k==='jog'?0:encGet(k);
    const f=k==='jog'?bpm.toFixed(1):ui.layer==='param'&&pk==='pat'&&typeof k==='number'?patShow(tracks[k],pdi(page(),ui.param),v):ui.layer==='glob'?globShow(k,v)+(k>=2&&k<=5?(k===3?'':k===4?(v>=126?'':':1'):k===5?(ui.shift?'':'MS'):''):''):typeof k!=='number'?num(v):ui.layer==='perf'&&pk==='stut'?stutShow(k,v):ui.layer==='perf'||ui.layer==='param'?num(v):
      pk==='macros'&&engShow(t,k,v,ui.shift)!=null?engShow(t,k,v,ui.shift):pk==='macros'&&ui.shift&&k===1&&t.eng!==ACID?timeShow(decSec(v)):pk==='macros'&&ui.shift&&k===3&&hasCurve(t)?curveShow(v):pk==='macros'&&ui.shift&&k===0&&hasTune(t)&&!pRange(t)?TUNES[fromV(v,2)]:pk==='macros'&&ui.shift&&k===4&&t.eng===0?stShow(v):pk==='macros'&&!ui.shift&&k===1&&t.eng!==ACID?decShow(t,v):pk==='macros'&&!ui.shift&&k===0&&t.eng===HANDS?toneShow(v)+'HZ':pk==='macros'&&!ui.shift&&k===3&&t.eng===HANDS?handsN(v)+(handsN(v)>1?' CLAPS':' CLAP'):pk==='macros'&&ui.shift&&k===7?panShow(v):pk==='macros'&&ui.shift&&k===6?NOISES[fromV(v,4)]:pk==='macros'&&!ui.shift&&k===2&&t.eng!==ACID&&!isSyn(t)?filtShow(v):pk==='mod'&&ui.shift&&(k===0||k===2)?hzShow(v):pk==='mod'&&k%2===0&&!(ui.shift&&k>=6)?rate(v):pk==='pat'?patShow(t,pdi(page(),k),v):pk==='pitch'?pitchShow(t,k,v):pk==='sA'||pk==='sB'?sendFmt(pk==='sA'?0:1,k,v):num(v);
    return encName(k)+' '+plain(f);}
  if(ui.layer==='track'&&page().key==='pitch'&&folSrc(t)>=0)return`LIST.N T${folSrc(t)+1} `+(folOff(t)?'SAME NOTE':`${HARMS[hrmOf(t)]} ${folRange(t)?'+-'+folRange(t)+' ST':'FULL RANGE'}`);
  if(ui.layer==='track'&&page().key==='pitch')return pRange(t)?`${SCALES[scaleOf(t)][0]} ${NOTES[rootOf(t)]}  ${noteName(t,Math.max(0,ui.ppos[ui.sel]))}`:'RANGE OFF: FREE PITCH';
  if(ui.layer==='track')return(ui.cat===2?'':ALGO_N[algoOf(t)]+'  ')+`LEN ${t.len}  CLOCK ${cdiv(t.v.pat[7])}  `+(lisSrc(t)>=0?'HEARS '+lisShow(t):ui.cat===2&&encLabels().some(l=>l==='NOISE'||l==='TYPE.N')?NOISES[t.noise]:'');   /* noise colour only on ENGINE pages with a NOISE knob (Lef 22 nov) */
  if(ui.layer==='param')return'ROW 2 PADS: PICK THE VALUE';   /* ALL ENGINE / ALL TRIGGERS: say how to pick (Lef 20 nov) */
  if(ui.layer==='glob')return`${COMP_TYPES[fromV(glob[2],3)]} GR ${(ui.gr||0).toFixed(1)}  `+(mainOn()?SCALES[gScale()][0]+' '+NOTES[fromV(glob[1],12)]:'MAIN OFF');
  if(ui.layer==='perf'&&page().key==='stut')return(ui.stutter.size||ui.repeat!=null?'STUTTERING  ':'')+(ui.shift?'SHIFT: ALL TRACKS + MASTER':`T${ui.sel+1} ${stutShow(1,t.v.stu[0])} LFO > ${ST_DESTS[fromV(t.v.stu[9],8)][0]}  PROB ${pct(t.v.sauto[0])}`);
  if(ui.layer==='perf')return'TEMPO '+bpm.toFixed(1);
  if(page().key==='sA'||page().key==='sB'){const k=page().key,sl=k==='sA'?0:1;return`T${ui.sel+1} SEND ${t.v[k][0]} ${t.v[k][6]>=64?'PRE':'POST'}, ${SEND_TYPES[sType(sl)][0]} SHARED`;}
  return`T${ui.sel+1} SEND A ${t.v.sA[0]}`;}
/* a list of 5 rows scrolls only when the pick leaves it, so a row stays under the mouse */
/* scrollbar on the right of a list longer than the screen: the block shows where you are and how long the list is (Lef 22 nov) */
function sbar(top,n){if(capt||n<=5)return;const H=41,h=Math.max(3,Math.round(H*5/n)),y=11+Math.round((H-h)*top/(n-5));x.fillStyle='#000';x.fillRect(125,11,3,H);x.fillStyle='#fff';for(let q=11;q<11+H;q+=2)x.fillRect(127,q,1,1);x.fillRect(126,y,2,h);}
const tops={};function keepTop(k,cur,n){let t=tops[k]??Math.max(0,cur-2);if(cur<t)t=cur;if(cur>t+4)t=cur-4;return tops[k]=Math.max(0,Math.min(Math.max(0,n-5),t));}
/* the knobs of a v106 page, as that page draws them (or into capt, see cells) */
function pageCells(t,p,pos){const play=ui.playing?'> ':'';
  const patFmt=(i,v)=>patShow(t,PAT_ORD[i],v);
  const pitFmt=(i,v)=>pitchShow(t,i,v);
  if(ui.layer==='track'){const hl=`T${ui.sel+1} `+(p.key==='macros'?`${ENGINES[t.eng]} | ${t.len} STEPS`:p.name);
    header(hl,tw(hl)+tw(pos)+6<=126?pos:'');
    const sh=p.key==='mod'&&ui.shift; /* Shift on MOD: knobs 7/8 = mod envelope */
    const vals=p.key==='macros'&&ui.shift?t.v.macros.map((v,k)=>k===1?(t.eng===ACID?t.v.gate[0]:t.v.att[0]):k===2&&t.eng!==NEBULA&&t.eng!==THUMP&&t.eng!==SOPHIE?t.v.col[0]:synX(t,k)?t.v[synV(t,k)][0]:k===0&&hasTune(t)&&!pRange(t)?t.v.tn[0]:k===3&&hasCurve(t)?t.v.crv[0]:k===4&&isTex(t)?t.v.pe[0]:k===4&&t.eng===0?t.v.st[0]:k===5&&isFm(t)?t.v.fo[0]:k===6?toV(t.noise,4):k===7?t.v.pan[0]:X3(t)&&k>=3&&k<=5?t.v[['cv','cc','chp'][k-3]][0]:v):p.key==='pat'?PAT_ORD.map(i=>ui.shift&&i===4?t.v.lis[0]:t.v.pat[i]):p.key==='pitch'?t.v.pitch.map((v,k)=>k===0?t.v.fol[0]:k===1?t.v.hrm[0]:ui.shift&&k===5?t.v.ac[0]:ui.shift&&k===6?t.v.sl[0]:v):t.v[p.key];
    cells(encLabels(),sh?[t.v.hz[0],t.v.mod[1],t.v.hz[1],t.v.mod[3],t.v.mod[4],t.v.edp[0],...t.env]:vals,p.key==='macros'?t.routes.map((m,k)=>m!==0&&!t.modOff[k]):null,
      p.key==='pat'?patFmt:p.key==='pitch'?pitFmt:p.key==='macros'?(i,v)=>engShow(t,i,v,ui.shift)??(ui.shift?(i===1&&t.eng===ACID?gateShow(v):i===1?timeShow(decSec(v)):i===0&&hasTune(t)&&!pRange(t)?TUNES[fromV(v,2)]:i===4&&t.eng===0?stShow(v):i===3&&hasCurve(t)?curveShow(v):i===7?panShow(v):i===6?NOISES[fromV(v,4)]:num(v)):i===2&&t.eng!==ACID&&!isSyn(t)?filtShow(v):i===0&&t.eng===HANDS?toneShow(v):i===3&&t.eng===HANDS?String(handsN(v)):i===0&&pRange(t)?NOTES[rootOf(t)]+(pitchOct(t)+1+pOct(t)):i===1&&t.eng!==ACID?decShow(t,v,1):num(v)):p.key==='mod'?(i,v)=>sh&&(i===0||i===2)?hzShow(v):sh&&i>=6?timeShow(decSec(v)):i%2===0?rate(v):num(v):null,
      p.key==='macros'?i=>ui.shift?(i===7||i===2&&isSyn(t)&&t.eng!==NEBULA&&t.eng!==THUMP&&t.eng!==SOPHIE?[64,64]:null):i===2&&t.eng!==ACID&&(!isSyn(t)||t.eng===HIVE)?FILT_MID:null:null);}
  else if(ui.layer==='param'){header('ALL '+rnd2(allLab(p),tracks[ui.sel]),pos);
    cells(tracks.map((_,i)=>'T'+(i+1)+(tracks[i].mute?' M':tracks[i].solo?' S':'')),tracks.map(tr=>(([a,i])=>a[i])(allArr(tr,p))),null,p.key==='pat'?(i,v)=>patShow(tracks[i],pdi(p,allPar()),v):allVD(p)?(i,v)=>v===64?'0':(v>64?'+':'-')+Math.round(Math.abs(v-64)/63*100)+'%':p.key==='macros'&&ui.param===2?(i,v)=>filtShow(v):null,
      p.key==='macros'&&ui.param===2?()=>FILT_MID:null);}
  else if(ui.layer==='glob'){header('GLOBAL | '+(ui.mlen?'LEN '+mlShow(ui.mlen):'LEN OFF')+(ui.cpu!=null?' | '+Math.round(ui.cpu*100)+'%':''),pos);cells(encLabels(),glob.map((v,k)=>k===5&&ui.shift?glob[8]:v).slice(0,8),null,globShow);}
  else if(ui.layer==='perf'&&p.key==='stut'){header(ui.shift?'ALL STUTTER':`T${ui.sel+1} STUTTER`,pos);
    cells(encLabels(),STK.map((j,k)=>k===0?t.v.sauto[0]:t.v.stu[ui.shift&&STK_SH[k]!=null?STK_SH[k]:j]),null,(k,v)=>stutShow(k,v),i=>i===5?[64,64]:null);}
  else if(ui.layer==='perf'){header('PERFORM',play+bpm.toFixed(1)+'  '+(ui.enc.perf+1)+'/2');const mc=ui.shift;cells(encLabels(),perf.map((v,k)=>k===0?tracks[chT()].v.chs[0]:mc&&k===1?perf[7]:v),null,(k,v)=>k===3?swingShow(v):mc&&k===1?pct(v):num(v),i=>i===2?FILT_MID:i===1&&!mc?[58,69]:null);}
  else{header(p.key==='fx'?fxHead(t,pos):p.key==='sA'||p.key==='sB'?p.name+' '+SEND_TYPES[sType(p.key==='sA'?0:1)][0]+': ALL':`T${ui.sel+1} `+p.name,pos);
    const sl=p.key==='sA'?0:p.key==='sB'?1:-1;
    cells(p.key==='fx'||sl>=0?encLabels():p.labels,sl>=0?sendShared[sl].slice(0,8).map((v,k)=>k===0||k===6?t.v[p.key][k]:k===3&&tapeF(sl)?sendShared[sl][8]:v):p.key==='fx'?t.v.fx.map((v,k)=>eqK(t,k)&&ui.shift?t.v.eq[k>>2]:k===scK(t)?t.v.sc[ui.shift?0:1]:isGrainShift(t,k)?t.v.gx[gxIdx(k)]:v):t.v[p.key],null,
      sl>=0?(k,v)=>sendFmt(sl,k,v):p.key==='fx'?(k,v)=>fxShow(t,k,v):null,sl>=0&&isRev(sl)?i=>i===4?FILT_MID:null:sl>=0&&isShim(sl)?i=>i===5?FILT_MID:null:null);}
}
/* knob i of a page that picks its knobs: what the screen shows, from the v106 page it comes from (or its own) */
function knobInfo(i,cache){const s=kSpec(i),t=tracks[ui.sel];if(!s||s.off&&s.off(t))return{lab:'----',val:0,txt:''};
  if(s.own){const o=OWN[s.own],l=o.lab(t);let v=l==='----'?0:ownVal(o,t);const rv=l!=='----'&&ownShow(s.own);if(rv!=null&&!ownStep(o,t))v=rv;return{lab:l,val:v,txt:l==='----'?'':o.show(t,v),bip:o.bip,rec:l!=='----'&&ownRec(s.own)};}
  const c=ctxOf(s),key=c.layer+c.enc+'/'+(c.shift==null?+ui.shift:c.shift);
  if(!cache[key])withCtx(c,()=>{capt=[];try{pageCells(t,page(),'');cache[key]=capt;}finally{capt=null;}});
  const r=cache[key][s.src[2]];return Object.assign({},r,{lab:s.lab&&r.lab!=='----'?s.lab:r.lab});}
function knobInfos(){const cache={};return[...Array(8)].map((_,i)=>knobInfo(i,cache));}
function knobCells(t,pos){const p=cpage(),K=knobInfos();
  if(ui.heldStep!=null&&ui.slkPg!==slkPgKey()&&!holdRender){ui.slkShow=null;slkView();}   /* another page or SHIFT while the step is held: its values */
  if(ui.slkShow&&ui.heldStep!=null&&ui.slkStep===ui.stepPage*16+ui.heldStep&&ui.slkPg===slkPgKey())for(const k in ui.slkShow)K[k]=Object.assign({},K[k],ui.slkShow[k]);
  const eng=ui.cat===2&&CATS[2].pages[ui.cp[2]].eng!=null,all=ui.shift&&(eng||allKnob(ui.touched));   /* SHIFT on ENGINE (or on a knob that sets all tracks): the header says so */
  const hl=all?(eng&&ui.cp[2]>=1?'ALL '+ENGINES[t.eng]:'ALL TRACKS')+' | '+p.name:`T${ui.sel+1} `+(eng?'ENGINE | '+ENGINES[t.eng]:ui.cat===0&&ui.cp[0]===0?p.name+' | '+t.len+' STEPS':p.name);
  const cpu=ui.cat===3&&ui.cp[3]<2&&ui.cpu!=null?' | CPU '+Math.round(ui.cpu*100)+'%':'';   /* PERFORM: how hard the engine works */
  const ml=ui.cat===3&&ui.cp[3]===0&&ui.shift?'MASTER LEN '+(ui.mlen?mlShow(ui.mlen):'OFF'):null;   /* SHIFT on PERFORM: the master length, before < > change it */
  const left=ml||(ui.cat===3&&!all?p.name+cpu:hl);header(left,tw(left)+tw(pos)+6<=126?pos:'');
  if(p.name==='COMP'&&!ml&&!capt){const x0=tw(left)+6,x1=126-tw(pos)-6,w=x1-x0;   /* GR meter in the header bar: how much the compressor pulls down, 0..20 dB (Lef 15 nov) */
    if(w>8){x.fillStyle='#000';x.fillRect(x0,4,w,1);const g=Math.min(1,Math.abs(ui.gr||0)/20);if(g>0)x.fillRect(x0,2,Math.max(1,Math.round(g*w)),5);x.fillStyle='#fff';}}
  for(let i=0;i<8;i++){const k=K[i],cx=(i%4)*32,cy=12+Math.floor(i/4)*21,hot=ui.touched===i&&k.lab!=='----';
    if(hot){x.fillRect(cx,cy-2,31,20);x.fillStyle='#000';}
    txt(dn(k.lab,t),cx+1,cy);if(k.rec)x.fillRect(cx+29,cy-2,2,2);
    if(k.lab!=='----'){valTxt(k.txt,cx+1,cy+7);bar(cx+1,cy+14,28,k.val,k.bip);}
    x.fillStyle='#fff';}
  if(p.name==='TRIGGERS'&&t.gen===8&&ui.touched>=1&&ui.touched<=3&&!capt)otoDraw();}
/* the OTOMAT field in the lower half: 8 x 8 squares of 3 px, a cell as a dot with a tick toward where it goes, the picked square framed */
function otoDraw(){x.fillStyle='#000';x.fillRect(0,31,128,24);x.fillStyle='#fff';const X0=52,Y0=30,F=ui.playing&&ui.otoSim?ui.otoSim.F:otoCells(),C=ui.otoC||[0,0];
  x.fillRect(X0-1,Y0-1,26,1);x.fillRect(X0-1,Y0+24,26,1);x.fillRect(X0-1,Y0-1,1,26);x.fillRect(X0+24,Y0-1,1,26);
  x.fillRect(X0+C[0]*3,Y0+C[1]*3,3,3);x.fillStyle='#000';x.fillRect(X0+C[0]*3+1,Y0+C[1]*3+1,1,1);x.fillStyle='#fff';
  for(const c of F){const px=X0+c[0]*3,py=Y0+c[1]*3;x.fillRect(px+1,py+1,1,1);const d=[[1,0],[2,1],[1,2],[0,1]][c[2]];x.fillRect(px+d[0],py+d[1],1,1);}
}
function draw(){if(holdRender)return;
  if(ui.saver){drawSaver();return;}
  x.fillStyle='#000';x.fillRect(0,0,128,64);x.fillStyle='#fff';
  if(ui.big&&ui.big.huge){const F=ui.big;glyphs(x,F.t,64-Math.round(tw(F.t,5)/2),6,5);glyphs(x,F.l[0],64-Math.round(tw(F.l[0],2)/2),42,2);return;}
  if(ui.big){const F=ui.big;header(F.t,'');F.l.forEach((l,i)=>txt(l,64-Math.round(tw(l)/2),14+i*8));return;}   /* INIT and the like: the whole screen for a moment */
  if(ui.fxPick){const P=ui.fxPick,f=padFx((P.r-1)*8+P.c),i=FX_LIB.indexOf(f),nm=FX[f][0];   /* a grid pad held: the library on knob 1 */
    header('ROW '+(P.r+1)+' PAD '+(P.c+1),(i+1)+'/'+FX_LIB.length);txt('KNOB 1: EFFECT',1,16);
    txt(nm,64-tw(nm)/2,28);const pv=FX[FX_LIB[(i-1+FX_LIB.length)%FX_LIB.length]][0],nx=FX[FX_LIB[(i+1)%FX_LIB.length]][0];txt('< '+pv,1,40);txt(nx+' >',127-tw(nx+' >'),40);
    x.fillRect(0,54,128,1);const kl=FX[f][1].filter(l=>l!=='----').join(' ');txt(kl,1,58);return;}
  if(ui.sendEdit){const E=ui.sendEdit,v=spv(tracks[ui.sel])[E.ki],dv=v===44;   /* send pad 4 / 8 held: its value on knob 1 */
    header('SEND '+'AB'[E.ki]+' PAD '+(E.ki?8:4),ui.shift?'ALL':'T'+(ui.sel+1));txt('KNOB 1: AMOUNT',1,16);
    const pc=Math.round(v/127*100)+'%';txt(pc,64-tw(pc)/2,28);x.fillRect(4,38,120,1);x.fillRect(4,45,120,1);x.fillRect(4,38,1,8);x.fillRect(123,38,1,8);x.fillRect(4,38,Math.round(120*v/127),8);
    x.fillRect(0,54,128,1);txt(dv?'DEFAULT 35%':'OWN VALUE (DEFAULT 35%)',1,58);return;}
  const t=tracks[ui.sel],p=page(),play=ui.playing?'> ':'';
  const pv=pgVis(ui.cat),pos=play+(pv.indexOf(ui.cp[ui.cat])+1)+'/'+pv.length;
  const menuStat=()=>{   /* MENU top right: CPU, then the battery as an icon and %; drawn by header() after the text, so the icon goes in afterwards */
    const b=ui.bat&&ui.bat.p!=null?ui.bat:null,ac=ui.bat&&ui.bat.ac&&!b,bt=b?(b.chg?'+':'')+b.p+'%':'',c=ui.cpu!=null?'CPU '+Math.round(ui.cpu*100)+'%':'';
    if(b)ui.batIcon={p:b.p,w:tw(bt)};else ui.batIcon=null;return (play+c+(b?'      '+bt:ac?' PSU':'')).trim();};
  const list=(title,right,items,cur,foot)=>{header(title,right);if(title==='MENU'&&ui.batIcon){const I=ui.batIcon,bx=126-I.w-14;x.fillStyle='#000';x.fillRect(bx,2,10,5);x.fillRect(bx+10,3,1,3);x.fillStyle='#fff';x.fillRect(bx+1,3,8,3);x.fillStyle='#000';x.fillRect(bx+1,3,Math.max(I.p>0?1:0,Math.round(8*I.p/100)),3);x.fillStyle='#fff';}const top=keepTop(ui.menu,cur,items.length);ui.rows={top,n:items.length,cur};
    for(let r=0;r<Math.min(5,items.length);r++){const i=top+r,y=12+r*8;if(i===cur){x.fillRect(0,y-1,128,8);x.fillStyle='#000';}
      txt(items[i][0],3,y);if(items[i][1])txt(items[i][1],(items.length>5?123:125)-tw(items[i][1]),y);x.fillStyle='#fff';}
    sbar(top,items.length);x.fillRect(0,54,128,1);txt(fit128(ui.toast||foot),1,58);};
  if(ui.menu==='mirror'){const M=ui.mir,q=M&&M.qr;   /* the QR as big as the screen allows (Lef 19 nov): a white field of 62 px, the modules spread over 58 px */
    if(q){const fit=q.size*2+8<=64,S=fit?2:58/q.size,B=fit?4:2,W=fit?q.size*2+8:62,o=Math.floor((64-W)/2),e=v=>o+B+Math.round(v*S);   /* 2 px a module with a quiet zone of 2 modules, centred; a longer address: spread */x.fillRect(o,o,W,W);x.fillStyle='#000';
      for(let yy=0;yy<q.size;yy++)for(let xx=0;xx<q.size;xx++)if(q.dark(xx,yy))x.fillRect(e(xx),e(yy),e(xx+1)-e(xx),e(yy+1)-e(yy));x.fillStyle='#fff';}
    const host=M.url.replace(/^http:\/\//,'').replace(/:7700\/.*$/,''),hl=tw(host)<=60?[host]:[host.split('.').slice(0,2).join('.')+'.',host.split('.').slice(2).join('.')];
    const lines=['SCAN WITH','YOUR PHONE','',...hl,'','SAME WIFI'];
    lines.forEach((l,i)=>txt(l,66,2+i*6));return;}
  if(ui.menu==='del'){list(ui.delT<0?'DELETE ALL TRACKS':'DELETE T'+(ui.delT+1),'',DEL_ROWS.map(r=>[r[0],'']),ui.si,'PRESS JOG: DELETE, < CANCEL');return;}
  if(ui.menu==='cond'&&ui.condS){const t=tracks[ui.condS.t],cur=t.cond&&t.cond[ui.condS.s]||0;list('TRIG CONDITIONS','T'+(ui.condS.t+1)+' STEP '+(ui.condS.s+1),COND_N.map((n,i)=>[n,i===cur?'NOW':'']),ui.si,'PRESS JOG: SET, < CANCEL');return;}
  if(ui.menu==='clrmod'){list('CLEAR MOD?','T'+(ui.sel+1),clrModRows().map(r=>[r.nm,r.val]),ui.si,'PRESS JOG: CLEAR, < CANCEL');return;}
  const N2=i=>String(i+1).padStart(2,'0');
  if(ui.menu==='buffer'){list('BUFFER','',BUF_ACTS,ui.si,'SAMPLES/RECORDINGS');return;}
  if(ui.menu==='bufsave'){const R=bufSrcRows(),r=R[ui.si];list('SAVE WHICH?','',R.map(q=>[q.nm,'']),ui.si,r?r.d:'');return;}
  if(ui.menu==='buffiles'){const F=ui.bufFiles||[];list(ui.bufAct+' WHICH?',(ui.si+1)+'/'+F.length,F.map(n=>[n,'']),ui.si,ui.confirm?'PRESS AGAIN: DELETE':'PRESS JOG: '+ui.bufAct+', < BACK');return;}
  if(ui.menu==='rename'&&ui.rnFile!=null){list('RENAME',ui.rnFile.slice(0,12),[...RN_LIST.map(n=>[n,'']),['TYPE','LETTER BY LETTER']],ui.ri,'PRESS JOG: PICK, < BACK');return;}
  if(ui.menu==='rename'){const i=ui.rnI;list('RENAME '+N2(i),presets.names[i]||'',[...RN_LIST.map(n=>[n,'']),['TYPE','LETTER BY LETTER']],ui.ri,'PRESS JOG: PICK, < BACK');return;}
  if(ui.menu==='type'){header(ui.rnFile!=null?'RENAME FILE':'RENAME '+N2(ui.rnI),(ui.tc+1)+'/'+RN_MAX);const S=typeStr();
    for(let c=0;c<S.length;c++){const cx=4+c*8;if(c===ui.tc){x.fillRect(cx-1,22,7,9);x.fillStyle='#000';}txt(S[c]===' '?'_':S[c],cx,24);x.fillStyle='#fff';}
    x.fillRect(0,54,128,1);txt(fit128(ui.toast||'PRESS: NEXT LETTER, < DONE'),1,58);return;}
  if(ui.menu==='song'&&ui.shift){const R=presets.song.rows,r=R[Math.min(ui.sr,R.length-1)],L=ui.loop&&ui.loop.song;   /* SHIFT held: what the knobs do, with the values of this row (Lef 20 nov) */
    header('SONG MODE | '+(r&&ui.sr<R.length?'ROW '+(ui.sr+1):'KNOBS'),L?'ON':'');const lab=['PRESET','TIMES','BARS','','','','','LOOP'],val=k=>k===7?(presets.song.end?'ON':'OFF'):!r||ui.sr>=R.length||k>2?'':k===0?N2(r.p):k===1?r.x+'X':String(r.b);
    for(let k=0;k<8;k++){const cx=(k%4)*32,cy=12+Math.floor(k/4)*21;txt(lab[k]||'----',cx+1,cy);if(lab[k])txt(val(k),cx+1,cy+7);}
    x.fillRect(0,54,128,1);txt(fit128(ui.toast||(r&&ui.sr<R.length?N2(r.p)+' '+(presets.names[r.p]||'EMPTY'):'SHIFT + JOG: TIMES')),1,58);return;}
  if(ui.menu==='song'){const R=presets.song.rows,L=ui.loop&&ui.loop.song?ui.loop:null,cur=L&&L.k>=0?L.song[L.k].r:-1;
    const r=R[ui.sr],hk=typeof ui.held==='number'?ui.held:null,end='K8 LOOP '+(presets.song.end?'ON':'OFF');   /* the knobs set the row: the bottom line says so, a touched knob says what it does (Lef 20 nov) */
    const foot=hk===7?'K8 LOOP: '+(presets.song.end?'ON, FROM THE TOP':'OFF, LAST PLAYS ON'):hk!=null&&hk<3&&r?['K1 ROW '+(ui.sr+1)+' PRESET: '+N2(r.p),'K2 ROW '+(ui.sr+1)+' TIMES: '+r.x+'X (SHIFT+JOG)','K3 ROW '+(ui.sr+1)+' BARS EACH TIME: '+r.b][hk]:hk!=null?'KNOB '+(hk+1)+': NOTHING HERE':
      ui.sr>=R.length?'PRESS JOG: ADD A ROW':'K1 PRESET  K2 TIMES  K3 BARS';
    list('SONG MODE',L?'JOG: STOP':ui.sr<R.length?'JOG: START':'',[...R.map((r,k)=>[(k===cur?'> ':'')+N2(r.p)+' '+(presets.names[r.p]||'EMPTY').slice(0,11),r.x+'X '+r.b+'B']),['+ ADD ROW',end]],ui.sr,foot);return;}
  if(ui.menu==='ask'){const A=ui.ask;list('OVERWRITE '+String(A?A.i+1:0).padStart(2,'0')+'?',A?presets.names[A.i]||'':'',[['NO','KEEP AS SAVED'],['YES','SAVE OVER IT']],ui.si,'PRESS JOG: CONFIRM, < CANCEL');return;}
  if(ui.menu==='power'){const R=ui.pw&&ui.pw.length?ui.pw:[['NOTHING FOUND','']];list('POWER TEST',(ui.si+1)+'/'+R.length,R,Math.min(ui.si,R.length-1),'JOG SCROLLS, < BACK');return;}
  if(ui.menu==='main'){const v0=[ENGINES[t.eng],presets.names.filter(Boolean).length+' SAVED','KEEP','FILE','TO SLOT',WAITS[set.wait]?SAVERS[set.saver]+' '+waitShow():'OFF',midi.acc&&set.midiIn?'IN ON':'SETTINGS',set.tips?'ON':'OFF','',typeof EFOS_VERSION==='string'?EFOS_VERSION:'WEB APP'];
    list('MENU',menuStat(),MENU_ITEMS.map(nm=>[nm,v0[MENU_ALL.indexOf(nm)]]),ui.mi,'JOG PICKS, PRESS JOG OPENS');return;}
  if(ui.menu==='files'){const L=ui.flist||[],W=ui.fwt!=null&&globalThis.efosWt,cur=W&&W.pathOf(wtn(t)[ui.fwt]),
      it=L.map(f=>[f.up?'..':f.dir?f.n.toUpperCase()+'/':f.n.replace(/\.wav$/i,'').toUpperCase(),cur&&!f.dir&&cur===(ui.fdir?ui.fdir+'/':'')+f.n?'*':'']);   /* * = the table that plays now */
    if(!L.length)it.push(['NO WAV FILES HERE','']);
    list(ui.fdir?ui.fdir.split('/').pop().toUpperCase():'SAMPLES','T'+(ui.sel+1)+(ui.fwt!=null?' '+'AB'[ui.fwt]:''),it,L.length?ui.fi:0,'PRESS JOG: '+(L[ui.fi]&&(L[ui.fi].dir||L[ui.fi].up)?'OPEN':'LOAD')+', < BACK');return;}
  if(ui.menu==='ctlmap'){list('LEARNED','CONTROLLER',ctlMapRows().map(r=>[r.nm,r.val()]),ui.si,'DEL + JOG PRESS: REMOVE, < BACK');return;}
  if(ui.menu==='screensaver'||ui.menu==='midi'||ui.menu==='ctl'){const rows=setRows();list(ui.menu==='midi'?'MIDI':ui.menu==='ctl'?'CONTROLLER':'SCREENSAVER',ui.menu==='ctl'?'MIDI':'MENU',rows.map(r=>[r.nm,r.val()]),ui.si,'SHIFT + JOG CHANGES, < BACK');return;}
  const n2=i=>String(i+1).padStart(2,'0');
  if(ui.menu==='presets'&&ui.shift&&!ui.saveTo){header('PRESETS | '+n2(ui.pi),fit128(presets.names[ui.pi]||'----').slice(0,10));   /* SHIFT held: the actions as a list, jog picks, jog press does it on this slot (Lef 19 nov) */
    const V=paVis(),cq=Math.max(0,V.indexOf(ui.pa)),top=keepTop('pacts',cq,V.length);ui.rows={top,n:V.length,cur:cq,acts:1,vis:V};
    for(let r=0;r<5&&top+r<V.length;r++){const i=V[top+r],y=12+r*8;if(i===ui.pa){x.fillRect(0,y-1,128,8);x.fillStyle='#000';}
      txt(i<=2&&!presets.names[ui.pi]?PRE_ACTS[i]+' (SAVE)':PRE_ACTS[i],3,y);x.fillStyle='#fff';}
    sbar(top,V.length);x.fillRect(0,54,128,1);txt(fit128(ui.toast||'PRESS JOG: DO IT, LET GO SHIFT: CANCEL'),1,58);return;}
  if(ui.menu==='presets'){const L=ui.loop;header(ui.saveTo?'SAVE TO':'PRESETS',L?(L.song?'SONG '+(L.song[Math.max(0,L.k)].r+1)+'/'+L.song[0].n:'LOOP '+Math.max(1,L.k+1)+'/'+L.list.length):ui.saveTo?'':ui.pa<=2&&!presets.names[ui.pi]?'SAVE':PRE_ACTS[ui.pa]);   /* the action the jog press does here */const top=keepTop('presets',ui.pi,PRESET_N);ui.rows={top,n:PRESET_N,cur:ui.pi};
    const dirty=preDirty();
    for(let r=0;r<5;r++){const i=top+r,y=12+r*8,cur=i===ui.pi;if(cur){x.fillRect(0,y-1,128,8);x.fillStyle='#000';}
      if(ui.act===i){x.fillStyle=cur?'#000':'#fff';x.fillRect(2,y-1,tw(n2(i))+2,7);x.fillStyle=cur?'#fff':'#000';txt(n2(i),3,y);x.fillStyle=cur?'#000':'#fff';}   /* the active preset: its number inverted (Lef 19 nov) */
      else txt(n2(i),3,y);
      txt((presets.names[i]||'----')+(ui.act===i&&dirty?' *':''),3+tw(n2(i)+' '),y);   /* *: changed since it was loaded or saved */
      if(L&&L.list[L.k]===i)txt('>',123-tw('>'),y); /* the slot the PRESET LOOPER plays now */x.fillStyle='#fff';}
    sbar(top,PRESET_N);x.fillRect(0,54,128,1);const nx=L&&L.list[(L.k+1)%L.list.length];
    txt(fit128(ui.toast||(L?(L.song?'< STOPS THE SONG':'NEXT: '+presets.names[nx]+', < STOPS'):ui.pending?'NEXT BAR: '+ui.pending.name:ui.pa<=2&&!presets.names[ui.pi]?'EMPTY SLOT, PRESS JOG: SAVE':ui.pa===CLEAN_A?'PRESS JOG: CLOSE THE GAPS':ui.pa===3?(presets.names[ui.pi]?'PRESS JOG: OVERWRITE':'PRESS JOG: SAVE'):ui.pa<=2&&ui.last&&ui.last.i===ui.pi?ui.last.what+' '+n2(ui.pi):'HOLD SHIFT: ACTIONS')),1,58);return;}
  if(ui.menu==='looper'){const L=ui.loop,n=lpList().length;header('PRESET LOOPER',L?'ON':n+' PRESETS');   /* knobs 1-4 like a page: label, value */
    for(let k=0;k<4;k++){const cx=k*32;txt(LP_LAB[k],cx+2,14);txt(lpVal(k),cx+2,24);}
    if(L){const i=L.list[Math.max(0,L.k)];txt(fit128('PLAYS '+n2(i)+' '+(presets.names[i]||'')),2,38);}
    x.fillRect(0,54,128,1);txt(fit128(ui.toast||(L?'PRESS JOG: STOP':'PRESS JOG: START')+', < BACK'),1,58);
    if(L&&L.k>=0){const done=L.tot-L.left+((ui.pos%16)+1)/16;x.fillRect(0,53,Math.round(128*Math.min(1,done/L.tot)),2);}return;}
  if(ui.menu){const c=engPos(t.eng),cr=engRow(t.eng),N=ENG_ROWS.length;{const L=`T${ui.sel+1} ENGINE | ${engGrp(t.eng)}`,P=(c+1)+'/'+ENG_ORD.length;header(L,tw(L)+tw(P)+6<=126?P:'');}
    const top=keepTop('engine',cr,N);ui.rows={top,n:N,cur:cr,eng:1}; /* 5 rows, scrolling like PRESETS; heading rows in between */
    for(let r=0;r<Math.min(5,N);r++){const i=top+r,y=12+r*8,R=ENG_ROWS[i];
      if(R.h){const w=tw(R.h);txt(R.h,64-(w>>1),y);for(let q=2;q<60-(w>>1);q+=2){x.fillRect(q,y+2,1,1);x.fillRect(126-q,y+2,1,1);}continue;}   /* heading: dotted line, name in the middle */
      if(i===cr){x.fillRect(0,y-1,128,8);x.fillStyle='#000';}txt(ENGINES[R.e],3,y);x.fillStyle='#fff';}
    sbar(top,N);x.fillRect(0,54,128,1);txt(fit128(ui.toast||'JOG / + - PICK, MENU CLOSES'),1,58);return;}
  if(cpage().src)pageCells(t,p,pos);else knobCells(t,pos);
  x.fillRect(0,54,128,1);txt(fit128(status()),1,58);
  if(ui.loop&&!ui.toast&&ui.loop.k>=0){const L=ui.loop,done=L.tot-L.left+((ui.pos%16)+1)/16;x.fillRect(0,53,Math.round(128*Math.min(1,done/L.tot)),2);}  /* LOOP: how far this preset is */
  if(ui.layer==='track'&&p.key==='mod'&&ui.modSrc<2&&!ui.toast&&ui.touched==null)drawWave(t.waves[ui.modSrc],101,57,24,6);
  if(ui.layer==='track'&&p.key==='pitch'&&pRange(t)&&folSrc(t)<0&&!ui.toast&&ui.touched==null)drawLane(t,94,57,32,6);
  smDraw(t);}
/* SAMPLE (Lef 18 nov): the buffer as a wave on the bottom line while it holds audio; touching START END SLICE INDEX
   marks it in that strip; only while recording it is big, a bar fills (y 52) and the wave grows. ui.smw comes from the Move's core (get_param wave<N>) */
const SM_BIG=['SM.START','SM.END','SM.SLICE','SM.INDEX','SM.ING'];
function smDraw(t){const w=ui.smw;if(t.eng!==SAMPLE||!w||w.t!==ui.sel||ui.cat===3||ui.layer!=='track'&&ui.cat!==2)return;
  if(w.st===2)x.fillRect(0,52,Math.max(1,Math.round(128*w.fill/1000)),2);   /* REC: the bar fills up to TIME.M */
  const sp=typeof ui.touched==='number'?kSpec(ui.touched):null;
  if(w.st===2){x.fillStyle='#000';x.fillRect(0,10,128,41);x.fillStyle='#fff';smWave(t,w,0,11,128,39,1);}   /* big only while recording: it runs and how far (Lef 19 nov) */
  if(sp&&SM_BIG.includes(sp.own)&&w.ms&&w.st!==2){x.fillStyle='#000';x.fillRect(0,55,128,9);x.fillStyle='#fff';smWave(t,w,0,56,128,8,1);return;}   /* START LENGTH SLC.L INDEX: the strip at the bottom shows it, no full screen (Lef 19 nov) */
  if(ui.toast||ui.touched!=null||ui.copyHeld||ui.muteHeld||linking())return;
  x.fillStyle='#000';x.fillRect(0,55,128,9);x.fillStyle='#fff';
  if(w.st===1){txt('REC WAIT: NEXT BAR',1,58);return;}
  if(w.st===2){const l=((ui.smr||0)>>16+ui.sel&1?'DUB ':'REC ')+(smRadio(t)?'RADIO ':'MIC ')+(w.ms/1000).toFixed(1)+'S';txt(l,1,58);smWave(t,w,tw(l)+4,56,124-tw(l),8,0);return;}
  if(!w.ms){txt('EMPTY: ROW 3 PAD 1 = REC',1,58);return;}
  smWave(t,w,0,56,128,8,1);}   /* with START, the end, the slice lines and the slice that plays */
/* the wave in W x H: peaks around the middle; outside START..END dotted; slice lines and the chosen slice (big only); the play position */
function smWave(t,w,X,Y,W,H,big){const v=smv(t),rec=w.st===2&&!((ui.smr||0)>>16+ui.sel&1),P=smPart(t);let a=v[1]/127,b=P?(P.s0+P.len)/P.L:1;
  const n=P?P.n:1,k=Math.min(n-1,Math.floor(v[4]/128*n)),mid=Y+(H>>1),half=(H-1)/2,gdb=(v[15]-64)/63*24,sw=P?P.sl/P.L:(b-a);
  for(let c=0;c<W;c++){const f=(c+.5)/W,pc=w.pk[Math.min(127,Math.floor(f*128))]||0,db=pc?pc*60/63-60+gdb:-99,h=Math.round(Math.max(0,Math.min(1,(db+48)/48))*half*2);   /* dB: quiet audio shows too; GAIN makes it bigger */
    const inside=rec||f>=a&&f<=b,todo=rec&&f>w.fill/1000;
    if(todo){}else if(inside)x.fillRect(X+c,mid-(h>>1),1,Math.max(1,h));else if(c%2===0)x.fillRect(X+c,mid-(h>>1),1,1),h>2&&x.fillRect(X+c,mid+(h>>1)-1,1,1);
    if(rec&&f>w.fill/1000&&c%2===0)x.fillRect(X+c,mid,1,1);}   /* REC: the rest of the bar, dotted */
  if(rec)return;
  const px=f=>X+Math.min(W-1,Math.round(f*W));
  if(big){for(let i=1;i<n&&n<=32;i++){const sx=px(a+sw*i);for(let y=Y;y<Y+H;y+=3)x.fillRect(sx,y,1,1);}   /* slice lines */
    x.fillRect(px(a),Y,1,H);x.fillRect(px(b),Y,1,H);   /* START and the end of LENGTH */
    const s0=px(a+sw*k),s1=px(a+sw*(k+1));x.fillRect(s0,Y+H-2,Math.max(1,s1-s0),2);}   /* the chosen slice (INDEX) */
  else{const s0=px(a+sw*k),s1=px(a+sw*(k+1));if(n>1)x.fillRect(s0,Y,Math.max(1,s1-s0),1);}
  if(w.pp>=0)x.fillRect(px(w.pp/1000),Y,1,H);}   /* where it plays */
/* a value on the screen: text, or the picture of a waveform */
function valTxt(s,X,Y){if(typeof s!=='string'||s[0]!==PIC){txt(s,X,Y);return;}const[n,v]=s.slice(1).split(':');if(n==='LFO')drawWave(+v,X,Y,14,5);else wavePic(n,+v,X,Y,14,5);}
/* one period of a waveform, W x H pixels; SHK and ACD morph with the knob value v */
function waveY(n,v,ph){const saw=2*ph-1,sq=ph<.5?1:-1,shk=ph<.85?-1+2*Math.pow(ph/.85,.6):1-2*(ph-.85)/.15,pul=ph<.15?1:-1;
  if(n==='SINE')return Math.sin(ph*2*Math.PI);if(n==='TRI')return 1-4*Math.abs(ph-.5);if(n==='SAW')return saw;if(n==='SQUARE')return sq;
  if(n==='FOLD')return Math.sin(2.2*Math.sin(ph*2*Math.PI));if(n==='DIGI')return Math.round(saw*2)/2;
  if(n==='ACD'){const a=v/127;return saw*(1-a)+sq*a;}
  if(n==='SHK'){const w=v/127*3,k=Math.min(2,Math.floor(w)),f=w-k,S=[saw,shk,sq,pul];return S[k]*(1-f)+S[k+1]*f;}return 0;}
function wavePic(n,v,X,Y,W,H){let prev=null;for(let i=0;i<W;i++){const py=Y+Math.round((1-waveY(n,v,i/W))/2*(H-1));
  if(prev!=null&&Math.abs(py-prev)>1){const a=Math.min(py,prev),b=Math.max(py,prev);x.fillRect(X+i,a,1,b-a+1);}else x.fillRect(X+i,py,1,1);prev=py;}}
/* the first 16 notes of the pitch lane as a small line, the playing note brighter */
function drawLane(t,X,Y,W,H){const n=Math.min(16,pLen(t)),R=pRange(t);for(let s=0;s<n;s++){const y=Y+H-1-Math.round(t.pdeg[s]/R*(H-1));
  x.fillRect(X+s*2,y,s===ui.ppos[ui.sel]%16?2:1,1);}}
/* small picture of an LFO waveform */
function drawWave(w,X,Y,W,H){let r=.37,prev=null;for(let i=0;i<W;i++){const ph=i/W;let y;
  if(w===0)y=Math.sin(ph*2*Math.PI);else if(w===1)y=1-4*Math.abs(ph-.5);else if(w===2)y=2*ph-1;else if(w===3)y=1-2*ph;
  else if(w===4)y=ph<.5?1:-1;else{if(i%6===0)r=Math.sin(i*12.9898+w)*43758.5453%1;y=w===5?r*2-1:Math.sin(i*.7+w)*.8;}
  const py=Y+Math.round((1-y)/2*(H-1));if(prev!=null&&Math.abs(py-prev)>1){const a=Math.min(py,prev),b=Math.max(py,prev);x.fillRect(X+i,a,1,b-a+1);}else x.fillRect(X+i,py,1,1);prev=py;}}
/* ---------- dynamic manual (right of the screen) ---------- */
/* each entry: [title, [section, line, line, ...], ...]; '#' starts a section */
var ROW1='ROW 1: SELECT TRACK (SHIFT = MUTE)';
var MOD_D=['#DESTINATION (D)','TURN THROUGH THE KNOBS OF THE','ENGINE PAGES (AND TUNE: STEPLESS','PITCH, +-12 ST AT FULL AMOUNT),','SEND A AND SEND B (THIS TRACK),','MIX.1 MIX.2 (FX SLOT MIX),','FX.1 FX.2 (SLOT TYPE, ON A HIT);','SAMPLE: REC (A NEW CYCLE RECORDS),','LET GO = PICKED (OR 2 S STILL)','OFF = NO DESTINATION'];
var LINK_L=['#LINK','HOLD AN ENGINE KNOB + STEP 1-5:','LFO1 LFO2 ENV RND A RND B','LED UNDER KNOB = LINKED','MODULATION NEVER TURNS DRONE ON'];
var REC_L=['#REC','DOT ON SCREEN, DASHED KNOB =','RECORDED (REC); HOLD DEL +','TURN = CLEAR IT'];
var ROW2_HELP=['3 V1.INT, 4 V2.INT: HOW OFTEN','VAR.1 / VAR.2 PLAY: EVERY BAR, OR','THE LAST BAR OF EVERY 2 / 3 / 4','5 FILL: HOLD = THE STEPS WITH','TRIG CONDITION FILL PLAY','7 TURING+: A HIT AND A NEW NOTE ON','THE NEXT STEP; 8 TURING-: A REST','(HOLD = EVERY STEP)'];
var TRG_PADS=['#PADS',ROW1,'ROW 2 (SHIFT = ALL TRACKS):','1 VAR.1: A VARIANT WITH AS MANY','HITS AS THE TRIGGERS, ON / OFF','2 VAR.2: FULLER, ON / OFF',...ROW2_HELP,'ROW 4: REPEAT 1/32 1/16 1/8 3/16','1/4 1/2 1 BAR REV, WHILE HELD;','1-7 STRIKE THE ENGINE AGAIN,','REV = THE AUDIO BACKWARDS;','THIS TRACK, SHIFT = ALL (AUDIO);','HOLD + ROW 1 ADDS OR DROPS TRACKS'];
var SND_PADS=['#PADS',ROW1,'ROW 2 PAD 1: RND.S: NEW SOUND,','SAME ENGINE','PAD 2: MUT.S: THE SOUND A LITTLE','SAMPLE: ROW 3 PAD 1 = REC (RED),','LOAD (GREEN) ON ALGO FILE,','PAD 2 = OVERDUB (ORANGE),','PAD 3 = PLAY (GREEN): HEAR IT ALL,','PAD 4 = RND.R, NEW STATION (RADIO)','ROW 4: SEND A 5 10 20 35 %,','SEND B THE SAME; PAD 1 TWICE = OFF','(SHIFT = ALL TRACKS)'];
var PRF_PADS=['#PADS',ROW1,'ROW 2: MUTATE T1-8: A NEW SOUND','FOR THAT TRACK (= RND.S)','(SHIFT = ONLY A NEW PATTERN)','ROW 3: MUTATE (AT RANDOM): SOUND','TRIGGERS PITCH LENGTH FX PROB','CHAOS','ROW 4: DEFAULT, THE SAME SEVEN,','BUT PAD 4: RANDOM LENGTH 4-128;','PAD 8: ALL BACK TO DEFAULT','ROW 3-4: THE SELECTED TRACK,','SHIFT = ALL TRACKS, UNDO = BACK'];
var HELP={
  'TRIGGERS/TRIGGERS':['TRIGGERS',['#KNOBS','ALGO: EUCL, TURING, ALG.G (GROOVES), ROLL','KNOB 2: TURING = CHANCE A STEP','CHANGES, 0 = LOCKED,','ALG.G = GROOVE: PICKS ONE OF 16,','ROLL = LEN.R: 16THS IN A ROW','ROTATE: THE PATTERN MOVES RIGHT','DENS: HITS (ROLL: THE EVEN BASE),','ROLL + SHIFT + DENS = DENS.R:','HOW OFTEN A ROLL COMES','PROB: CHANCE PER STEP','VAR.T: TRIGGERS CHANGE EACH LOOP','VAR.V: VELOCITY VARIATION','LENGTH: TRACK LENGTH 1-128','SHIFT + KNOB = ALL TRACKS'],
    TRG_PADS,['#STEPS','SET / CLEAR STEPS'],REC_L],
  'TRIGGERS/TRIGGERS 2':['TRIGGERS 2',['#KNOBS','CLOCK: /8 TO X4','LIST.T: ALSO PLAY ON THE HITS OF','ANOTHER TRACK (OFF, T1-T8)','LOOP.N: LOOP THE LAST 4 TO 128','STEPS AS HEARD','SHIFT + KNOB = ALL TRACKS']],
  'TRIGGERS/STUT.LFO':['TRIGGERS / STUT.LFO',['#KNOBS','LFO.S: STUTTER LFO SPEED, LEFT =','THE STUTTER LENGTH, FURTHER = CLOCK DIVS','LFO.D: WHERE IT GOES (AND SWEEP):','LP OPEN, LP CLOSE, HP OPEN, BP SWEEP,','PITCH DOWN, PITCH UP, VOLUME, PAN','SHIFT + TURN: ALL TRACKS AND','THE MASTER REPEAT']],
'TRIGGERS/STUTTER':['TRIGGERS / STUTTER',['#KNOBS (THIS TRACK)','PROB: CHANCE THAT A HIT STUTTERS,','2 4 OR 8 16THS OF THAT HIT','LENGTH: 1/128 TO 1 BAR, ONE REPEAT','RAMP: 1-3 STEPS, EACH TWICE AS FAST,','SPREAD OVER THE STUTTER, MAX 1/64','BREAK: REVERSE, SKIP','SHAPE: EACH REPEAT OPEN TO TIGHT','VAR.C: NOW AND THEN ANOTHER CLOCK,','MIDDLE OFF, LEFT SLOWER (/2 /4),','RIGHT FASTER (X2 X4), ON THE GRID','LFO: ONE LFO OVER THE STUTTER,','ITS SPEED AND DEST ON STUT.LFO (+)','MIX: STUTTER MIX','SHIFT + TURN: ALL TRACKS AND','THE MASTER REPEAT'],
    TRG_PADS],
  'PITCH/PITCH':['PITCH',['#KNOBS','PITCH: RANGE OFF = FREE PITCH,','RANGE ON = OCTAVE C1-C7','(SHIFT = OCTAVE -2 TO +2)','RANGE: OFF = FREE (DRUMS), THEN','A MELODY IN THE SCALE, RIGHT = FULL','(LIST.N: OFF = THE SAME NOTE)','LIST.N: TAKE THE NOTES OF ANOTHER','TRACK (SHIFT = MODE: A = ON THE','CLOCK, B = MOVES ON A HIT)','HARM: UNI 3RD 4TH 5TH 6TH OCT','-3RD -5TH -OCT ANSWER','PORTA: GLIDE BETWEEN NOTES','(SHIFT = ALL)','VAR.P: RANDOM PITCH PER HIT','VAR.M: MELODY CHANGES EACH LOOP','LENGTH: LANE LENGTH 1-128'],
    ['#PADS',ROW1,'ROW 2 (SHIFT = ALL TRACKS):','1 RND.M: NEW MELODY','2 RND.P: NEW PITCH (MELODY:','A NEW OCTAVE)',...ROW2_HELP,'ROW 4: MELODY VARIATIONS: DOWN,','UP, INVERT, REVERSE, SHUFFLE,','OCTAVE, SIMPLE, ANSWER:','ON / OFF, ONE AT A TIME'],
    ['#STEPS','THE NOTE LANE; HOLD STEP +','+ / - OR JOG: NOTE UP / DOWN','ACID: TAP = PLAIN > ACCENT >','SLIDE > BOTH']],
  'PITCH/PITCH 2':['PITCH 2',['#KNOBS','SCALE, ROOT: THIS TRACK, ONLY WHEN','MAIN (PERFORM 2) IS OFF, ELSE MAIN','(SHIFT = ALL TRACKS)','TUNE: SLOW WANDERING DETUNE','TURING: 0 = LOCKED, UP = NOTES','TURN INTO NEW RANDOM ONES','(SHIFT = LINK WITH TRIGGERS','TURING: ONE MACHINE)','ACCENT, SLIDE: ACID STEPS,','ONLY ON ACID','MODE: A = ON THE CLOCK, B = ON A HIT','OCTAVE: -2 TO +2 (SHIFT = ALL)']],
  'ENGINE/ENGINE':['ENGINE',['#KNOBS','THE SHAPE OF THE SOUND,','THE SAME PLACES ON EVERY ENGINE:','FILTER / CUTOFF, P.ENV, F.ENV','OR DRIVE, VAR.S, ATTACK DECAY','CURVE VAR.D, LEVEL','THUMP: KNOB 4 = ATTACK (FADE IN)','NEBULA: FILTER LOW < OPEN > HIGH','DRIVE ON DUST MATTER NEBULA','J60 SHARK HIVE: CUTOFF RESO','F.AMT (SHIFT = F.DEC); THEIR','DRIVE AND VAR.S ON ENGINE 2','DECAY 0 = OFF; FULL = DRONE MODE','CURVE: LOG < LIN > EXP (ACID,','MATTER: THE SHAPE OF THE DECAY)','VAR.D: RANDOM DECAY PER HIT, MIDDLE OFF','VAR.S: SOUND DRIFTS EACH LOOP,','PITCH NEVER; 0 = KEEP','SHIFT + KNOB: ALL TRACKS','ACID: SHIFT + CUTOFF = RESO','SHIFT + LEVEL = PAN','FM-PERC: SHIFT + P.ENV = P.DEC'],
    SND_PADS,REC_L],
  'ENGINE/WIRES':['WIRES',['#KNOBS','SNARE ONLY: THE SNARE WIRES','TYPE.W: 808 909 WHITE PINK','CLAP BLACK','COLOR RESO.W DEC.W','SNAP: HOLD OF THE WIRES','(CLAP: HOW LONG IT CLAPS)','MIX.W: BODY < > WIRES','SHIFT + KNOB: ALL SNARE TRACKS'],SND_PADS],
  'ENGINE/ENGINE 2':['ENGINE 2',['#KNOBS','THE ALGORITHM AND THE NATURE','OF THE SOUND: KNOB 1 = ALGO OR THE','MAIN KNOB OF THE ENGINE, THEN THE','SOUND, THE FILTER ENVELOPE','(ATK.F ENV.F AMT.F), NOISE, TYPE.N','SHIFT + KNOB: ALL TRACKS WITH','THE SAME ENGINE','MATTER: SHIFT + NOISE = TYPE.N','NEBULA: SHIFT + SIZE = TEX','J60, SHARK: CHOR.A = CHORUS AMOUNT','SHARK: KNOB 7 = CHORUS OFF I II I+II','WAVE KNOBS SHOW THE WAVEFORM','SAMPLE: ALGO START END SLICE','INDEX STRETCH TUNE.S MON.L; SHIFT:','TIME.M BITS RATE SYNC VAR.I','- DIR GAIN','SNARE: ALGO 808 909 XXX 000','KNOB 2: 909 BAL, XXX INDEX,','000 TYPE.B; DEC.B TUNE.R DEC.R','X.MOD (XXX 000) DRIVE MIX.R','808: NOISE DEC.N DEC.B TUNE.R','DEC.R DRIVE MIX.R','(808 NOISE: WHITE, HIGH-PASS)','LENGTH: FROM START, MOVES WITH IT','SLC.L: 1/128 .. 1 BAR, ALL','PITCH: KNOB 1 OF THE PITCH PAGE','RND.I (ROW 2 PAD 1): ANOTHER','SLICE (INDEX)','DIR: L.FWD L.REV L.PING = LOOP','THE WAVE: BOTTOM LINE; TOUCH','START END SLC.L INDEX: BIG','BITS RATE SYNC: FOR A NEW REC'],SND_PADS],
  'ENGINE/MOD 1':['ENGINE / MOD 1',['#KNOBS','PER LFO: S SPEED, W WAVE,','A AMOUNT, D DESTINATION','S: ON THE CLOCK, PAT .. 1/1 .. 1/256','SHIFT + S: FREE, 0.05 TO 100 HZ','THE LAST TURN PICKS SYNC OR HZ','W: SINE TRI SAW UP SAW DN','SQUARE S&H RANDOM'],MOD_D,
    ['#PADS',ROW1,'ROW 2 PAD 1: RND.S','ROW 4: SENDS'],['#KEYS','DEL: ALL MOD OFF THIS TRACK']],
  'ENGINE/MOD 3':['ENGINE / MOD 3',['#KNOBS','RND A AND RND B: RANDOM VALUES','S SPEED (ON THE CLOCK),','A AMOUNT (SHIFT = SMOOTH:','0 = STEPPED, RIGHT = GLIDES),','D DESTINATION'],MOD_D,['#PADS',ROW1,'ROW 2 PAD 1: RND.S','ROW 4: SENDS']],
  'ENGINE/MOD 2':['ENGINE / MOD 2',['#KNOBS','KNOBS 1-4: LFO 3, AS LFO 1 AND 2','KNOBS 5-8: THE MOD ENVELOPE,','ON EVERY HIT: ENV.AT ATTACK,','ENV.DC DECAY, ENV.A AMOUNT,','ENV.D DESTINATION'],MOD_D,['#PADS',ROW1,'ROW 2 PAD 1: RND.S','ROW 4: SENDS']],
  'ENGINE/SIDECHAIN':['ENGINE / SIDECHAIN',['#KNOBS','ANOTHER TRACK DUCKS THIS ONE','AMT.S: HOW DEEP','TIME: MIDDLE = FOLLOW THE SOURCE,','LEFT = SHORTER, RIGHT = LONGER','(SHIFT = FILT.S: LP / HP ON THE SOURCE)','SRC.S: WHICH TRACK DUCKS']],
  'ENGINE/CHANNEL':['ENGINE / CHANNEL',['#KNOBS','THE CHANNEL STRIP OF THE TRACK','EQ.L EQ.M EQ.H: -12..+12 DB','EQ.F: MID FREQUENCY','KNOB 5: FREE (SIDECHAIN HAS ITS OWN PAGE)','MONO.B: BASS TO MONO','(SHIFT = MONO.F, FREQUENCY)','SAT: AIRWINDOWS CHANNEL9 0-200%','(SHIFT = TYPE.S: NEVE API SSL','TEAC MACKIE)','COMP: SIMPLE COMPRESSOR','SHIFT + OTHER KNOBS: ALL TRACKS']],
  'ENGINE/FX SLOTS':['ENGINE / FX SLOTS',['#KNOBS','TOP ROW 1-4 = SLOT 1,','BOTTOM ROW 5-8 = SLOT 2','EFFECTS OF THIS TRACK ONLY','A NEW EFFECT STARTS IN THE MIDDLE','SLOT OFF: DELAY, RESO, GRAIN AND','SPRING RING OUT (TAIL)'],
    ['#PADS',ROW1,'ROW 2: EFFECT TYPE SLOT 1','ROW 3: EFFECT TYPE SLOT 2','PAD 8 = SPRING; THE LIT PAD','AGAIN = OFF','ROW 4: SENDS'],
    ['#TP.DLY (TAPE DELAY)','TIME ON THE CLOCK,','FDBK, FILTER (LP < OPEN > HP,','IN THE FEEDBACK), MIX','SHIFT + FDBK = WOW,','SHIFT + FILTER = SAT'],['#GRAIN (CLOUDS)','SIZE, DENS, PITCH, MIX','PITCH: LEFT HALF -12 TO +12 ST,','RIGHT HALF: EACH GRAIN A RANDOM','PITCH, UP TO +-12 ST FULLY RIGHT','DENS: LEFT = EVEN GRAINS,','MIDDLE = NONE, RIGHT = RANDOM','SHIFT: SIZE = POSITION,','DENS = TEXTURE (SHAPE, DIFFUSE),','PITCH = REVERB, MIX = FDBK,','RIGHT END = FREEZE','HIGH CPU: A WARNING, STILL PLACED'],['#SPRING','SPRING REVERB: SIZE, DECAY,','TONE, MIX; SHIFT + MIX = FDBK','(LONGER, LOUDER TAIL; FULLY OPEN','IT RINGS BY ITSELF, MUTE OR STOP','SILENCES IT); HIVE STARTS WITH IT','IN SLOT 1']],
  'PERF/PERFORM':['PERFORM',['#KNOBS','DENS: BREAK / FILL, MIDDLE = OFF','PROB: MASTER PROB, EVERY HIT OF','EVERY TRACK, 100% = ALL PLAY','CHAOS: VELOCITY, ROLLS (32NDS,','64THS), GLITCHES; PITCH ONLY A','FEW CENTS; ALL TRACKS, HOLD A','TRACK PAD = ONLY THAT TRACK','FILTER: LOW < OFF > HIGH','DELAY','WASH: OPEN AND PUSH SEND A','COMP: PUSH THE MASTER COMPRESSOR','MAKEUP: MASTER MAKE-UP GAIN,','LEFT = AUTO, WORKS WITH COMP','CPU: LOAD ON THE SCREEN'],
    PRF_PADS,['#STEPS','THE SEQUENCER OF THE SELECTED','TRACK, AS ON EVERY PAGE'],['#MASTER LENGTH','SHIFT + < > (OR SHIFT + ARROWS):','OFF 1/16 1/8 1/4 1/2, 1 2 4 8 16','BARS: ALL TRACKS RESTART TOGETHER']],
  'PERF/PERFORM 2':['PERFORM 2',['#KNOBS','SWING: EVERY SECOND 16TH LATER,','OFF (50%) TO 75%, ALL TRACKS','SCL.M, ROOT.M (KNOB 5, 6): MAIN KEY','OVER ALL TRACKS, LEFT = OFF: EACH','TRACK ITS OWN SCALE / ROOT (PITCH 2)'],
    PRF_PADS,['#STEPS','THE SEQUENCER, AS ON EVERY PAGE']],
  'PERF/SEND A':['PERF / SEND A',['#KNOBS','T1 SND, T1 PRE: THIS TRACK','ALL OTHER KNOBS: ALL TRACKS','PRE: BEFORE THE TRACK LEVEL','(LEVEL 0 = ONLY THE WET SOUND)','TYPE, 4 KNOBS, RETURN: SHARED','TYPES: ROOM HALL PLATE SPRING','SHIMMER CLOUDSEED DELAY TAPE','BBD PHASER FLANGE CHORUS LOOP','GRAIN','ROOM: SIZE DAMP TONE WIDTH,','SIZE AT THE TOP = FREEZE','HALL: BIG, WIDE, MOD = DETUNE','SHIMMER: PLATE + OCTAVE UP,','SHIMMER = HOW MUCH','CLOUDSEED: LUSH, LONG; TONE =','HIGH CUT','TAPE: SHIFT + FDBK = FILTER'],PRF_PADS,['#TIP','WASH ON PERFORM: ONLY SEND A']],
  'PERF/SEND B':['PERF / SEND B',['#KNOBS','SAME AS SEND A, ITS OWN TYPE'],PRF_PADS,['#TIP','WASH ON PERFORM: ONLY SEND A']],
  'PERF/COMP':['PERF / COMP',['#KNOBS','MASTER COMPRESSOR','TYPE: GLUE / PUNCH / SMASH','ATK (SHIFT = RELEASE), SAT, MIX','MAKE-UP GAIN IS AUTOMATIC'],PRF_PADS],
  'PERF/ALL ENGINE':['PERF / ALL ENGINE',['#KNOBS','ONE ENGINE VALUE, 8 TRACKS','SHIFT + KNOB: ALL TRACKS MOVE','BY THE SAME AMOUNT'],
    ['#PADS',ROW1,'ROW 2: PICK THE PARAMETER','ROW 3: RANDOM VALUE FOR THAT TRACK','(SHIFT = ALL TRACKS)','ROW 4 PAD 1: THE WHOLE PAGE AT','RANDOM, ALL TRACKS, SAFE RANGES']],
  'PERF/ALL TRIGGERS':['PERF / ALL TRIGGERS',['#KNOBS','ONE TRIGGERS VALUE, 8 TRACKS','SHIFT + KNOB: ALL TRACKS MOVE'],['#PADS',ROW1,'ROW 2: PICK THE PARAMETER','ROW 3: RANDOM VALUE FOR THAT TRACK','(SHIFT = ALL TRACKS)','ROW 4 PAD 1: THE WHOLE PAGE AT','RANDOM, ALL TRACKS, SAFE RANGES']]
};
var SH_COMMON=['ROW 1 PAD: MUTE ON / OFF','KNOBS WITHOUT A SHIFT JOB:','SAME VALUE ON ALL TRACKS','+ / -: TRACK LENGTH','DEL: INIT, ALL CLEAR (UNDO)'];
var HELP_SHIFT={
  'TRIGGERS/STUTTER':['SHIFT HELD',['#STUTTER','LFO KNOB: SPEED','OTHER KNOBS: ALL TRACKS AND','THE MASTER REPEAT','ROW 2-4 PADS: ALL TRACKS','ROW 1 PAD: MUTE ON / OFF']],
  'ENGINE/MOD 1':['SHIFT HELD',['#MOD 1','S KNOBS: FREE IN HZ (0.05-100 HZ)','KNOBS: FINE']],'ENGINE/MOD 3':['SHIFT HELD',['#MOD 3','A KNOBS: SMOOTH','KNOBS: FINE']],
  'ENGINE/FX SLOTS':['SHIFT HELD',['#GRAIN SLOT','SIZE: POSITION (HOW FAR BACK)','DENS: TEXTURE (SHAPE > DIFFUSE)','PITCH: REVERB','MIX: FEEDBACK > FREEZE','OTHER SLOT TYPES: NO CHANGE']],
  'PERF/ALL ENGINE':['SHIFT HELD',['#ALL','ROW 1 PAD: MUTE ON / OFF','ROW 3: ALL TRACKS','KNOBS: ALL TRACKS MOVE TOGETHER']],
  'PERF/ALL TRIGGERS':['SHIFT HELD',['#ALL','ROW 1 PAD: MUTE ON / OFF','ROW 3: ALL TRACKS','KNOBS: ALL TRACKS MOVE TOGETHER']],
  TRIGGERS:['SHIFT HELD',['#TRIGGERS','KNOBS: ALL TRACKS','ROW 2-4 PADS: ALL TRACKS',...SH_COMMON]],
  PITCH:['SHIFT HELD',['#PITCH','PITCH KNOB: OCTAVE','LIST.N KNOB: MODE A / B','TURING KNOB: LINK','ROW 2-3 PADS: ALL TRACKS',...SH_COMMON]],
  ENGINE:['SHIFT HELD',['#ENGINE','KNOBS: ALL TRACKS','LEVEL KNOB: PAN','ROW 2 + 4 PADS: ALL TRACKS',...SH_COMMON]],
  PERF:['SHIFT HELD',['#PERF','PERFORM: < > = MASTER LENGTH','ROW 2: ONLY A NEW PATTERN','ROW 3-4: ALL TRACKS','KNOBS: FINE','ROW 1 PAD: MUTE ON / OFF']]};
var HELP_ALWAYS=['#ALWAYS','MENU (KEY ,): ENGINE, PRESETS','KEY .: PRESETS','SHIFT + MENU: PRESETS','LEFT KEYS (KEYS 9 0 - =):','TRIGGERS PITCH ENGINE PERF','+ / -: PAGES OF THAT KEY','DOWN / UP: NEXT / PREVIOUS PAGE,','ON INTO THE NEXT KEY;','HOLD 1.5 S: JUMP KEY TO KEY','[ ]: STEP PAGES','LEFT / RIGHT: TRACK LENGTH','SHIFT + LEFT / RIGHT: NUDGE','SPACE: PLAY  M: MUTE','CAP (KEY K): LOOP THE LAST 1 > 2','> 4 > 8 BARS > OFF, AT ONCE','HOLD CAP: OFF AT ONCE','DEL: MOD OFF THIS TRACK','SHIFT + DEL: INIT (UNDO = BACK)'];
/* var: render() can run before this block on start-up, helpRender then waits */
var helpEl=document.getElementById('help'),helpKey='';
/* greedy wrap measured in font4x5 pixels */
function helpWrap(s,w,k){const out=[];let cur='';for(const word of s.split(' ')){const t=cur?cur+' '+word:word;
  if(cur&&tw(t,k)>w){out.push(cur);cur=word;}else cur=t;}if(cur)out.push(cur);return out;}
function helpRender(){}function _helpRenderWeb(){if(!HELP)return;
  let e=ui.menu==='main'?['MENU',['#PICK','JOG OR + / -, PRESS JOG (ENTER)','OPENS; < (ESC) BACK, MENU CLOSES','SHIFT + MENU: PRESETS AT ONCE']]:
    ui.menu==='presets'||ui.menu==='looper'?['MENU: PRESETS',['#USE','JOG: PICK A SLOT (64)','PRESS JOG (ENTER): LOAD','(EMPTY SLOT: SAVE)','A LOAD WAITS FOR THE NEXT BAR','UNDO TAKES IT BACK','01 INVERTED = THE ACTIVE PRESET','* = CHANGED SINCE LOAD OR SAVE'],
      ['#HOLD SHIFT: ACTIONS','JOG PICKS, PRESS JOG DOES IT','ON THE SLOT, LET GO = CANCEL','LOAD, PATTERNS ONLY, SOUNDS ONLY,','OVERWRITE (PRESS TWICE),','PRESET LOOPER, EXPORT, IMPORT,','CLEAN UP (PRESS TWICE),','DELETE (PRESS TWICE, UNDO BACK)'],
      ['#PRESET LOOPER','KNOB 1 FROM, 2 TO (LEFT = ALL)','3 BARS PER PRESET (1-16)','4 REPEAT 1-9X, RIGHT = ENDLESS','PRESS JOG: START / STOP','< STOPS IT, ON EVERY PAGE','AFTER THE LAST ROUND THE LAST','PRESET PLAYS ON','LOOP: THIS SCREEN','SHIFT + LOOP: START / STOP','A LOAD BY HAND STOPS IT'],['#KEPT IN',presets.where==='BROWSER'?'THIS BROWSER: EXPORT FOR A BACKUP':'YOUR ACCOUNT, ONLY YOU SEE THEM']]:
    ui.menu?['MENU: ENGINE',['#PICK','JOG, + / - OR UP / DOWN','YOU HEAR IT AT ONCE','SHIFT = ALL TRACKS','MENU, < OR ESC CLOSES'],
    ['#ENGINES','KICKS','THUMP: KICKS, 9 ALGORITHMS','(OMEGA): PURE STACK WAVE SKIN','SLAM BITS TRANS 909; 808 (PLAITS)','MODEL KNOBS 2-5','OF ENGINE 2 BELONG TO THE ALGO','PERCUSSION','FM-PERC: 2-OP FM DRUMS','SOPHIE: METALLIC FM PERCUSSION,','FUSE STACK SPLIT SHARD PIPE BOOM,','METAL, FDBK, CRUSH, DRIVE, OWN','FILTER (LP HP NOTCH DJ BP)','SNARE: BODY (808 909 FM SUB), RING','(THE SHELL), NOISE (808 909 WHITE','PINK); ALGO LOADS 808 909 707;','SHIFT ON ENGINE 2 = NOISE LAYER','HANDS: CLAPS, 1 SNAP .. 4 FLAM ..','40 APPLAUSE; GAP, ROOM; FILTER','(PAGE 1) = LOW < OPEN > HIGH','WT DRUM: A WAVETABLE HIT, A = THE','TRANSIENT, B = THE BODY; SCAN RUNS','THROUGH THE TABLE, X.MOD ONLY IN','THE ATTACK','SYNTHS','ACID: 303 BASS (OPEN303)','SLIDE / ACCENT ON PITCH 2','SHARK: MOOG-STYLE BASS, LADDER','FILTER, SAW > SHARK > SQUARE','> PULSE, SUB, DRIVE','SID: THE C64 CHIP (JSSID BY','HERMIT): 8 WAVES, PW / PWM, SUB,','6581 / 8580 FILTER, ADSR WITH','SUSTN, HOLD, ARP (PAGE 3)','J60: POLY TRIADS IN THE SCALE','WAVETABLE: TWO LAYERS A AND B,','EACH ITS OWN TABLE AND POS; FM,','RING, POS.M, FEEDBACK (SHIFT ON','ENGINE 2); TABLES: 4 BUILT IN,','BUFFER (THE LAST SAMPLE-BUTTON','TAKE), WAVS IN SAMPLES/WAVETABLES','AND SAMPLES','HIVE: A SWARM OF 8 VCOS (AFTER','THE QUADRANTID SWARM): ALGO ORGAN','STRING DRONE REED METAL CHIP GRAIN','NOISE; SPRING REVERB IN SLOT 1','FX','TANK: TWO CLOCKED FILTERS AFTER','THE SHERMAN FILTERBANK; EACH HIT','PINGS THEM OR BURSTS CLOCK NOISE;','RESO SINGS, HARM, GRIT, FDBK','(SHIFT: VOICES DETUNE FM AM','CORR FB.HZ); ALSO IN GRID FX','NOISE AND EXPERIMENTAL','DUST: CRACKLES, POPS, CHAOS','INTO RESONATORS','MATTER: WHISPER, CRACKLE, SCRAPE,','DRIFT RUMBLE DROP BREAK','NOISE BLACK = MATTER LITE','TEX: WAVETABLE TEXTURES,','MODE FM RING SYNC SWARM (WITH XMOD)','DECAY FULL = DRONE MODE','NEBULA: CLOUDS ON ANOTHER TRACK','SOURCE: A TRACK OR PING; THE HITS','OPEN IT, THE ENVELOPE IS THE VCA','ALGO: GRAIN, STRETCH, LOOP DELAY,','SPECTRAL','SOURCE LEVEL 0: ONLY THE NEBULA','SAMPLE','SAMPLE: RECORDS THE MOVE\'S INPUT','(MIC, OR LINE-IN WITH A CABLE);','ROW 3 PAD 1 = REC, AGAIN = STOP,','EACH REC OVERWRITES THE BUFFER','ALGO RADIO: A RANDOM WEB RADIO','STATION (MP3, HTTP); RND.R = NEW']]:ui.copyHeld?['COPY HELD',['#COPY','TAP THE SOURCE TRACK (ROW 1),','THEN ONE OR MORE TARGETS','OR A STEP, THEN TARGET STEPS:','TRIGGER, P-LOCKS AND NOTE','HOLD BOTH AT ONCE: SWAP','COPIES SOUND, PATTERN, MELODY,','FX AND MOD; MUTES STAY','UNDO TAKES IT BACK']]:ui.muteHeld?['M HELD',['#M ON','TRACK: MUTE ON / OFF','SHIFT + TRACK: SOLO, ONLY THIS ONE','AGAIN ON IT: ALL TRACKS PLAY','TAP M ALONE: M STAYS ON / OFF'],['#GROUP MUTE','HOLD SHIFT + M, PICK TRACKS:','THEY BLINK; LET GO OF SHIFT OR M:','THEY FLIP TOGETHER']]:
    linking()?['LINKING '+heldName(),['#LINK','STEP / KEY 1-5 TOGGLES','LFO1 LFO2 ENV RND A RND B','RELEASE THE KNOB WHEN DONE']]:
    ui.shift?HELP_SHIFT[catName()+'/'+cpage().name]||HELP_SHIFT[catName()]:HELP[catName()+'/'+cpage().name];
  if(!e)e=[catName()+' / '+cpage().name,['#INFO','NO NOTES YET']];
  const k=2,w=Math.max(60,helpEl.clientWidth-24),key=JSON.stringify(e)+w+ui.muteMode;if(key===helpKey)return;helpKey=key;
  helpEl.textContent='';const add=(s,c)=>{for(const l of helpWrap(s,w,k)){const d=document.createElement('span');if(c)d.className=c;pix(d,l,k);helpEl.appendChild(d);}};
  add(e[0]+(ui.muteMode&&!ui.muteHeld?' (M ON: TAP = MUTE)':''),'h');
  for(const sec of [...e.slice(1),HELP_ALWAYS])sec.forEach(l=>l[0]==='#'?add(l.slice(1),'s'):add(l));}
new ResizeObserver(()=>{helpKey='';helpRender();}).observe(helpEl);
/* hints under the device, in the same font */
[['SPACE','PLAY / STOP'],['SHIFT','HOLD FOR SHIFT'],['1-8','SELECT TRACK'],['DRAG / WHEEL','TURN KNOBS'],
 ['HOLD + - < >','REPEAT'],['9 0 - =','LEFT KEYS: TRIGGERS / PITCH / ENGINE / PERF'],['1-8','SELECT TRACK (M ON: MUTE)'],['SHIFT + 1-8','MUTE (M ON: SOLO, ONLY THIS ONE)'],['M','TAP = M ON / OFF, HOLD = M ON'],['SHIFT + M HELD + 1-8','GROUP MUTE, FLIPS WHEN LET GO'],['DOWN / UP','NEXT / PREV PAGE, HOLD 1.5 S = NEXT KEY'],[', / .','MENU / PRESETS'],['[ ]','STEP PAGES'],['LEFT / RIGHT','TRACK LENGTH'],['SHIFT + LEFT / RIGHT','NUDGE PATTERN'],['HOLD KNOB + 1-5','LINK LFO1 / LFO2 / ENV / RND A / RND B'],['L','LOOP: ALL PRESETS IN A ROW'],['DEL / BACKSPACE','MOD OFF THIS TRACK'],['SHIFT + DEL','INIT: ALL CLEAR, UNDO = BACK'],['C (HOLD) + 1-8','COPY: SOURCE, THEN TARGETS; BOTH HELD = SWAP'],['K','CAP: LAST 1 > 2 > 4 > 8 BARS > OFF, HOLD = OFF'],['R','REC: RECORD KNOBS, SHIFT = CLEAR'],['DEL + KNOB','CLEAR THAT RECORDING'],['U','UNDO, SHIFT = REDO'],['N V','NEW / VARY SOUND']].forEach(([k,v])=>{
  const h=document.createElement('span'),a=document.createElement('span'),b=document.createElement('span');a.className='k';
  h.append(a,b);document.getElementById('hints').appendChild(h);pix(a,k,2);pix(b,v,2);});
/* ---------- autosave: a reload (crash, new version) brings the last state back ----------
   Kept in this tab only (sessionStorage), so a fresh start in a new tab is still a new random kit */
var restoredState=false;const SAVE_KEY='efs-state-v2';let saved='';
function saveState(){try{const s=JSON.stringify({compV:2,keyV:1,sendV:SEND_V,tracks,perf,glob,sendShared,stutShared,glanes,fxLib,bpm,volume,mlen:ui.mlen||0,snaps:ui.snaps,act:ui.act,actH:ui.act!=null&&ui.actRef?ui.actH:null});
  if(s!==saved){sessionStorage.setItem(SAVE_KEY,s);saved=s;}}catch(e){}}
function loadState(){try{const s=sessionStorage.getItem(SAVE_KEY);if(!s)return false;const d=JSON.parse(s);stutMig(d);
  migTracks(d.tracks).forEach((x,k)=>{const t=tracks[k];const v=Object.assign({},t.v,x.v);Object.assign(t,x);t.v=v;});
  sendMig(d);globMig(d);perfMig(d);if(!d.compV&&d.glob)[3,4,5,8].forEach(k=>d.glob[k]=glob[k]); /* older states: the compressor starts from its defaults */
  [[perf,d.perf],[glob,d.glob],[stutShared,d.stutShared],[sendShared[0],d.sendShared&&d.sendShared[0]],[sendShared[1],d.sendShared&&d.sendShared[1]]].forEach(([a,b])=>b&&b.forEach((v,k)=>a[k]=v));
  if(d.bpm)bpm=d.bpm;if(d.mlen)ui.mlen=d.mlen;if(d.volume!=null)volume=d.volume;if(d.snaps)ui.snaps=d.snaps;if(d.glanes)glanes=d.glanes;if(Array.isArray(d.fxLib))fxLib=fxLibOf(d.fxLib);if(d.act!=null){ui.act=d.act;ui.pi=d.act;ui.actH=d.actH;ui.actRef=d.actH?'kept':null;}saved=s;restoredState=true;return true;}catch(e){return false;}}
if(loadState())toast('RESTORED, PRESS PLAY',3000);
setInterval(saveState,1000);window.addEventListener('pagehide',saveState);
render();

/* ---------- the Move layer: pads, knobs and buttons in, LEDs, screen and sound out ---------- */
function sync() { _syncDirty = true; }          /* the web app syncs after every change; here once per tick */

/* Move palette (Schwung constants): bright hue h = 1..25, dark = 63 + 2h, very dark = 64 + 2h */
const _HUE = { 'var(--track-1)': 2, 'var(--track-2)': 3, 'var(--track-3)': 7, 'var(--track-4)': 11, 'var(--track-5)': 14, 'var(--track-6)': 17, 'var(--track-7)': 19, 'var(--track-8)': 23, 'var(--rec)': 1, 'var(--snd4)': 9, 'var(--snd4c)': 5, 'var(--v1a)': 3, 'var(--v1b)': 4, 'var(--v2a)': 11, 'var(--v2b)': 13, 'var(--fillp)': 23 };   /* TRIGGERS row 2: VAR.1 + V1.INT, VAR.2 + V2.INT, FILL (Lef 25 nov) */   /* send pad 4: own colour, another when not the default (Lef 19 nov) */
const WHITE = 120, LGREY = 118, DGREY = 119, VDGREY = 124, BLACK = 0;
function _padCol(bg, op, extra) {
  if (!bg || bg === 'var(--raised)') return BLACK;
  op = op === '' || op == null ? 1 : +op;
  if (bg === 'var(--lit)') return op >= 0.6 ? WHITE : LGREY;
  if (bg === 'var(--ink-muted)') return op >= 0.9 ? LGREY : op >= 0.4 ? DGREY : VDGREY;
  const h = _HUE[bg]; if (!h) return op >= 0.6 ? LGREY : DGREY;
  if (extra === 'sel' || op >= 0.95) return h;
  return op >= 0.4 ? 63 + 2 * h : 64 + 2 * h;
}
/* LED state is sent on change, a few per tick, so the Move's MIDI buffer never overflows */
const _ledWant = new Map(), _ledHave = new Map();
function _led(kind, id, v) { _ledWant.set(kind + id, [kind, id, v]); }
function _ledFlush(max) {
  let n = 0;
  for (const [k, w] of _ledWant) {
    if (_ledHave.get(k) === w[2]) continue;
    try { move_midi_internal_send([w[0] === 'n' ? 0x09 : 0x0b, w[0] === 'n' ? 0x90 : 0xb0, w[1], w[2]]); } catch (e) {}
    _ledHave.set(k, w[2]); if (++n >= max) break;
  }
}
const _BTN = { CAP: 52, REC: 118, LOOP: 58, MUTE: 88, DEL: 119, COPY: 60, UNDO: 56, SHIFT: 49, BACK: 51, MENU: 50, PLAY: 85, RECB: 86, PREV: 62, NEXT: 63, PLUS: 55, MINUS: 54 };
const _CC2BTN = {}; for (const k in _BTN) _CC2BTN[_BTN[k]] = k;
const _RGB_BTN = new Set([118, 85, 86]);
function _leds() {
  const blink = Date.now() % 500 < 250;
  pads.forEach((row, r) => row.forEach((b, c) => {
    const s = b.style; let v = _padCol(s.background, s.opacity, s.outline ? 'sel' : '');
    if (r === 0 && s.outline && v !== BLACK && !_nosel) v = s.background === 'var(--lit)' ? (_HUE[TC(c)] || WHITE) : WHITE;   /* row 1: the selected track white, its own colour on a hit (Lef 13 / 22 nov) */
    if (r === 0 && +s.opacity < 0.4 && !b.cls.has('soloff')) v = VDGREY;  /* row 1: a muted track dim grey, whether it has notes or not */
    if (b.cls.has('blink') && !blink) v = BLACK;
    if (b.cls.has('soloff') && !blink) v = r === 0 ? 64 + 2 * (_HUE[TC(c)] || 1) : v;
    _led('n', 68 + (3 - r) * 8 + c, v);
  }));
  steps.forEach((b, i) => {
    const s = b.style, op = s.opacity === '' || s.opacity == null ? 1 : +s.opacity, tc = s['--tc'];
    let v = BLACK;
    if (b.cls.has('head')) v = WHITE;
    else if (b.cls.has('st')) v = _padCol(tc, op);
    else if (op >= 0.9 && tc && tc !== 'var(--lit)') v = VDGREY;
    _led('n', 16 + i, v);
  });
  for (const k in _BTN) { const b = fn[k]; if (!b) continue; const on = b.cls.has('on') || b.cls.has('held');
    _led('c', _BTN[k], _RGB_BTN.has(_BTN[k]) ? (on ? (k === 'PLAY' ? 11 : k === 'REC' || k === 'RECB' ? 1 : WHITE) : VDGREY) : (on ? 0x7c : 0x10)); }
  pills.forEach((b, i) => _led('c', 43 - i, b.cls.has('on') ? WHITE : VDGREY));
  leds.forEach((b, i) => _led('c', 71 + i, b.cls.has('rec') ? (blink ? WHITE : BLACK) : b.cls.has('on') ? WHITE : BLACK));   /* REC recording: blinks; modulation: steady */
}

/* ---------- no track selected (Lef 18 nov): a pad without a function takes the selection away. The white light goes out,
   the screen shows ---- for the track, and the knobs do nothing; only a SHIFT turn of a knob that sets all tracks works.
   A track pad (row 1) selects again. */
let _nosel = false;
const _padSig = () => { try { return snapAll() + '|' + ui.toast + '|' + ui.toastT + '|' + ui.menu + '|' + ui.cat + '|' + ui.cp + '|' + ui.repeat + '|' + ui.smr + '|' + ui.sel + '|' + ui.fwt + '|' + ui.fdir + '|' + JSON.stringify(ui.pv || null); } catch (e) { return String(Math.random()); } };
{ const turn0 = turn; turn = function (k, d) {
    if (_nosel && typeof k === 'number') { const s = kSpec(k), len = s && s.src && s.src[0] === 'track' && s.src[1] === 1 && s.src[2] === 6;
      if (!(ui.shift && s && (s.all || len) && !s.own)) return; }
    return turn0(k, d); }; }
{ const header0 = header; header = function (l, r) { if (_nosel && !ui.menu) l = String(l).replace(/^T\d\b/, '----'); return header0(l, r); }; }

/* ---------- input ---------- */
const _held = new Set();
function _press(b, down) { if (!b) return; if (down) b.fire('pointerdown'); else { b.fire('pointerup'); b.fire('click'); } }
function _knobTouch(k, on) {
  if (on) { ui.touched = k; ui.held = k; ui.heldM = heldMacro(k);
    if (ui.layer === 'track' && page().key === 'mod' && typeof k === 'number') { if (ui.shift && k >= 5) ui.modEnv = true; else { ui.modEnv = false; ui.modSrc = k >> 1; } }
    ui.toast = null; touchT = Infinity; render(); }
  else { ui.held = null; ui.heldM = null; touchT = performance.now(); if (ui.dp) destNow(); render(); }   /* a destination you turned to: let go = picked at once */
}
const _rel = v => v < 64 ? v : v - 128;
globalThis.onMidiMessageInternal = function (d) { _safe('input', () => _input(d)); };
function _input(d) {
  const st = d[0] & 0xf0, a = d[1], v = d[2];
  /* only a real action wakes the screensaver: a pad, step or button going down, or a turn; touches, releases and pressure don't */
  const real = (st === 0x90 && v > 0 && a >= 10) || (st === 0xb0 && ((a >= 71 && a <= 79) || a === 14 ? _rel(v) !== 0 : v >= 64));
  if (ui.saver) { if (real) { ui.lastIn = performance.now(); saverWake(); } return; }
  if (real || st === 0x90 || st === 0x80) ui.lastIn = performance.now();
  if (st === 0x90 || st === 0x80) {
    const on = st === 0x90 && v > 0;
    if (a >= 68 && a <= 99) { const i = a - 68, r = 3 - (i >> 3), c = i & 7, b = pads[r][c];
      if (r === 0) { if (on) _nosel = false; _press(b, on); return; }
      if (on) { const sig = _padSig(); _press(b, true); b._sig = sig; b._chg = _padSig() !== sig; }
      else { _press(b, false); if (b._sig != null && !b._chg && !ui.shift && _padSig() === b._sig) { _nosel = true; render(); } b._sig = null; }   /* a pad without a function: no track selected (Lef 18 nov) */
    }
    else if (a >= 16 && a <= 31) { const b = steps[a - 16]; if (on) b.fire('pointerdown'); else { b.fire('pointerup'); b.fire('click'); } }
    else if (a <= 7) _knobTouch(a, on && v >= 64);
    else if (a === 9 && !on) {}      /* jog touch */
    return;
  }
  if (st === 0xb0) {
    if (a >= 71 && a <= 78) { const dd = _rel(v); if (dd) turn(a - 71, dd); return; }
    if (a === 79) { const dd = _rel(v); if (dd) { volume = Math.max(0, Math.min(127, volume + dd)); _grp('V', 'V ' + _f(volume / 127)); ui.touched = 'vol'; touchT = performance.now(); _volDraw = true; } return; }   /* VOLUME: straight to the DSP, drawn once per tick (fast turns no longer queue up) */
    if (a === 14) { const dd = _rel(v); if (dd) turn('jog', dd); return; }
    if (a === 3) { if (v < 64) return; if (ui.menu) jogPress(); else { _press(fn.MENU, true); _press(fn.MENU, false); if (ui.menu === 'main') { const e = MENU_ITEMS.indexOf('ENGINE'); if (e >= 0) { ui.mi = e; jogPress(); } } } return; }   /* jog press: in a menu = choose, else straight to MENU > ENGINE of the selected track (Lef 13 nov) */
    if (a >= 40 && a <= 43) { if (v >= 64) _press(pills[43 - a], true); else _press(pills[43 - a], false); return; }
    if (a === 51) {                  /* Back: closes EFOS's own menu step by step; no menu open = park EFOS (Shift + Back = quit, by the host) */
      if (v < 64) return;
      if (ui.menu || ui.loop) { fn.BACK.click(); return; }   /* < stops the PRESET LOOPER first (Lef 19 nov) */
      try { if (typeof host_suspend_overtake === 'function') host_suspend_overtake(); } catch (e) {}
      return;
    }
    const k = _CC2BTN[a]; if (k) { const on = v >= 64; if (on === _held.has(a)) return; if (on) _held.add(a); else _held.delete(a); _press(fn[k], on); }
  }
}
/* MIDI CONTROLLER on USB-A (Lef 19 nov): MENU > MIDI > CONTROLLER. CC and notes go to ctlMidi(); SysEx comes in pieces
   and is put back together (F0 .. F7), only to hear the E16's ACK on ENTER REMOTE MODE (Schwung docs/E16_REMOTE.md) */
let _sx = null;
const _E16_ACK = [0xf0, 0x00, 0x21, 0x5b, 0x02, 0x01, 0x06, 0x53];
function _sxByte(b) {
  if (b === 0xf0) { _sx = [b]; return; }
  if (!_sx) return;
  if (b === 0xf7) { const m = _sx; _sx = null; if (m.length >= 8 && _E16_ACK.every((x, i) => m[i] === x)) { if (!ui.ctlE16) { ui.ctlE16 = true; toast('E16 CONNECTED', 1500); } _ctlSeen = Date.now(); } return; }
  if (b >= 0x80) { _sx = null; return; }
  if (_sx.length < 64) _sx.push(b);
}
globalThis.onMidiMessageExternal = function (d) { _safe('midi ext', () => {
  if (!d || !d.length) return;
  const s = d[0];
  if (s === 0xf0 || (_sx && s < 0x80) || (_sx && s === 0xf7)) { for (let i = 0; i < d.length; i++) { if (d[i] >= 0xf8) continue; _sxByte(d[i]); } return; }
  if (s >= 0xf0) return;                                    /* clock and the like: the DSP reads them */
  _sx = null; ctlMidi(s, d[1] | 0, d[2] | 0);
}); };
/* the handshake: DEVICE AUTO or E16 asks every 2 s while nothing answers, every 10 s once it did (a pulled cable = SEARCHING again) */
let _ctlAsk = 0, _ctlSeen = 0;
function _ctlHand() {
  const C = ctlSet(), now = Date.now();
  if (!(C.dev === 0 || C.dev === 2)) { ui.ctlE16 = false; return; }
  if (ui.ctlE16 && now - _ctlSeen > 25000) ui.ctlE16 = false;
  if (now - _ctlAsk < (ui.ctlE16 ? 10000 : 2000)) return;
  _ctlAsk = now;
  if (typeof move_midi_external_send === 'function') move_midi_external_send([0x04, 0xf0, 0x00, 0x21, 0x04, 0x5b, 0x02, 0x01, 0x07, 0x06, 0x55, 0xf7]);
}

/* ---------- the loop ---------- */
let _mis = 0, _wT = 0, _n = 0, _last = { g: -2, k: '' }, _lastSave = 0, _cpuT = 0, _batT = -1e9;
/* Battery: Linux power_supply, the first supply of type Battery with a capacity. None found: null (no battery on the screen). */
function _rd(f) { try { const h = _std.open(f, 'r'); if (!h) return null; const t = h.readAsString(); h.close(); return String(t).trim(); } catch (e) { return null; } }
/* the battery from what Move itself passes on (host_get_move_info), if it has a field for it: a level 0..1 or 0..100 */
function _moveBat() {
  const i = _moveInfo(); if (!i) return null; let p = null, chg = false;
  for (const k in i) { const v = i[k];
    if (/charg/i.test(k)) { if (v === true || v === 1 || /^(charging|full|1|true)$/i.test(String(v))) chg = true; continue; }
    if (/bat/i.test(k) && !/charg|volt|temp|health/i.test(k) && typeof v === 'number' && isFinite(v) && v >= 0) p = v <= 1 && !/percent/i.test(k) ? Math.round(v * 100) : Math.round(Math.min(100, v)); }
  return p == null ? null : { p, chg };
}
function _battery() {
  { const m = _moveBat(); if (m) return m; }
  const D = '/sys/class/power_supply'; let l = null; try { l = _os.readdir(D)[0]; } catch (e) {} if (!l) return null;
  let best = null;
  for (const n of l) { if (n[0] === '.') continue; const c = _rd(D + '/' + n + '/capacity'); if (c == null || isNaN(+c)) continue;
    const ty = _rd(D + '/' + n + '/type'), st = _rd(D + '/' + n + '/status') || '';
    const b = { p: Math.max(0, Math.min(100, Math.round(+c))), chg: /^(charging|full)$/i.test(st) };
    if (ty === 'Battery') return b; if (!best) best = b; }
  if (!best) for (const n of l) { if (n[0] === '.') continue; if (_rd(D + '/' + n + '/online') === '1' && /mains|usb|ac/i.test(_rd(D + '/' + n + '/type') || '')) return { p: null, chg: false, ac: true }; }   /* no battery level, but the adapter is in */
  return best;
}
/* MENU > VERSION (test, Lef 19 nov): which power / battery files does this Move have? Rows of [name, value] */
globalThis.efosPower = function () {
  const R = [], ls = d => { try { const r = _os.readdir(d); return r && r[0] ? r[0].filter(n => n[0] !== '.').sort() : null; } catch (e) { return null; } }, U = v => String(v == null ? '-' : v).toUpperCase().slice(0, 14);
  const D = '/sys/class/power_supply', ps = ls(D);
  if (!ps) R.push(['POWER_SUPPLY', 'NO FOLDER']); else if (!ps.length) R.push(['POWER_SUPPLY', 'EMPTY']);
  else for (const n of ps) { R.push([U(n), '']); for (const f of ['type', 'online', 'status', 'capacity', 'voltage_now', 'present']) { const v = _rd(D + '/' + n + '/' + f); if (v != null) R.push([' ' + U(f), U(v)]); } }
  for (const h of ls('/sys/class/hwmon') || []) R.push(['HWMON ' + U(h), U(_rd('/sys/class/hwmon/' + h + '/name'))]);
  for (const h of ls('/sys/bus/iio/devices') || []) R.push(['IIO ' + U(h), U(_rd('/sys/bus/iio/devices/' + h + '/name'))]);
  for (const c of ls('/sys/class') || []) if (/bat|pow|charg|fuel|adc|pmic|gauge|regul/i.test(c)) R.push(['CLASS', U(c)]);
  { const i = _moveInfo(); if (!i) R.push(['MOVE INFO', 'NONE']); else { R.push(['MOVE INFO', '']); for (const k in i) { const v = i[k]; R.push([' ' + U(k), U(typeof v === 'object' ? JSON.stringify(v) : v)]); } } }   /* what Move passes on: looking for its battery (Lef 25 nov) */
  R.unshift(['TICKS / S', String(_dg.tps)], ['PRESET LOAD', _dg.apply + ' MS'], ['SCREEN DRAW', _dg.draw + ' MS'], ['CHANGE > SCREEN', _dg.lag + ' MS']);   /* timing: where a song change waits (Lef 20 nov) */
  { let c = null; try { c = host_module_get_param('fxcpu'); } catch (e) {}   /* CPU of one slot of each effect (Lef 20 nov) */
    const a = c ? String(c).trim().split(/\s+/).map(Number) : [];
    if (a.length) { const F = [['FX CPU, 1 SLOT', '% CORE']]; FX_LIB.forEach(i => { if (a[i] != null) F.push([' ' + FX[i][0], (a[i] / 1000).toFixed(2) + '%']); }); R.splice(4, 0, ...F); } }
  return R;
};
function _poll() {
  let s = null; try { s = host_module_get_param('pos'); } catch (e) {}
  if (!s) return;
  const a = String(s).trim().split(/\s+/).map(Number); if (a.length < 31) return;
  const g = a[0], pos = a.slice(1, 9), loops = a.slice(9, 17), ppos = a.slice(17, 25), hits = a[25], gr = a[26] / 100, play = a[27], ext = a[28], ebpm = a[29] / 10, cpu = a[30] / 1000, fxn = a.length >= 39 ? a.slice(31, 39) : null;
  const cs = (ext ? 1 : 0) | (play ? 2 : 0);
  if (a.length >= 40 && a[39] !== _last.smr) { _last.smr = a[39]; fromCore({ smr: a[39] }); }   /* SAMPLE: tracks recording */
  if (a.length >= 41 && a[40] !== _last.sg) { _last.sg = a[40]; fromCore({ sg: a[40] }); }   /* GENERAL buffer */
  const fk = fxn ? fxn.join() : ''; if (fk !== _last.fk) { _last.fk = fk; fromCore({ fxn }); }
  if (g !== _last.g || hits || cs !== _last.cs) { _last.g = g; _last.cs = cs; fromCore({ g, pos, loops, ppos, hits, gr, cs, bn: ebpm }); }
  if (!ext && !!play !== !!ui.playing) { if (++_mis > 10) { _mis = 0; setPlaying(!!play, false); } } else _mis = 0;   /* PLAY's light always tells what the sound does */
  const now = Date.now();
  if (now - _wT > 90 && tracks[ui.sel] && tracks[ui.sel].eng === SAMPLE) { _wT = now; let w = null; try { w = host_module_get_param('wave' + ui.sel); } catch (e) {}   /* SAMPLE: the wave on the screen */
    if (w) { const q = String(w).trim().split(' '); if (q.length >= 6) { const pk = []; for (let i = 0; i < 128; i++) pk.push(Math.max(0, (q[5].charCodeAt(i) || 48) - 48));
      const k = q.slice(0, 5).join() + q[5]; if (k !== _last.w || ui.sel !== _last.wt) { _last.w = k; _last.wt = ui.sel; fromCore({ smw: { t: ui.sel, st: +q[0], fill: +q[1], ms: +q[2], tms: +q[3], pp: +q[4], pk } }); } } }
  }
  if (now - _cpuT > 500) { _cpuT = now; fromCore({ cpu });
    if (now - _batT > 10000) { _batT = now; const b = _battery(); if (JSON.stringify(b) !== _last.bat) { _last.bat = JSON.stringify(b); fromCore({ bat: b }); } }   /* MENU: battery, every 10 s */
    { let g = 0; try { g = typeof host_speaker_active === 'function' && host_speaker_active() && !(typeof host_line_in_connected === 'function' && host_line_in_connected()) ? 1 : 0; } catch (e) {}   /* speaker on + internal mic: no MIC monitor */
      if (g !== _last.smg) { _last.smg = g; _outQ.push('smg ' + g); fromCore({ smg: g }); } }
    { let r = null; try { r = host_module_get_param('radio'); } catch (e) {} if (r && String(r) !== _last.radio) { _last.radio = String(r); fromCore({ radio: _last.radio }); } }   /* RADIO state and station */
    if (ui.menu === 'midi') { let m = null; try { m = host_module_get_param('mco'); } catch (e) {} const q = m ? String(m).trim().split(/\s+/) : null;
      const v = !q ? 'NO DSP' : q[0] !== '1' ? 'NO HOST FN' : q[1] + ' OK ' + q[2] + ' X'; if (v !== ui.mco) { ui.mco = v; render(); } } }
}
function _send() {
  if (_syncDirty) { _syncDirty = false; try { syncNow(); } catch (e) { console.log('EFOS sync: ' + e + '\n' + (e && e.stack)); } }
  if (!_outQ.length) return;
  const s = _outQ.join('\n'); _outQ.length = 0;
  try { if (typeof host_module_set_param_blocking === 'function') host_module_set_param_blocking('cmd', s, 200); else host_module_set_param('cmd', s); } catch (e) { console.log('EFOS send: ' + e); }
}
/* Make room: when EFOS opens while Move's own set is playing on its own clock, Move's transport is stopped
   (a Play press sent to Move). When Move follows an external MIDI clock, it keeps running: EFOS follows it. */
function _moveInfo() { try { const i = typeof host_get_move_info === 'function' ? host_get_move_info() : null; return i && i.valid ? i : null; } catch (e) { return null; } }
/* Move's Play button is a toggle, and Move's status lags behind a press. So EFOS presses only when Move has said
   'playing' on two checks in a row, and only once until Move says 'stopped' again:
   a stale status can then never start Move's set instead of stopping it. */
let _stopT = 0, _stopN = 0, _seenPlay = 0;
function _stopMove() {
  const i = _moveInfo(); if (!i || i.midiClockSync === 1 || i.midiClockSync === true) { _seenPlay = 0; return false; }
  if (!i.valid || i.playing !== 1) { if (i.valid && i.playing === 0) _stopN = 0; _seenPlay = 0; return false; }   /* 255 = unknown: never press */
  if (++_seenPlay < 2 || _stopN >= 1 || (_stopT && Date.now() - _stopT < 4000)) return false;
  try { move_midi_inject_to_move([0x0b, 0xb0, 85, 127]); setTimeout(() => { try { move_midi_inject_to_move([0x0b, 0xb0, 85, 0]); } catch (e) {} }, 60); } catch (e) { return false; }
  _stopT = Date.now(); _stopN++; _seenPlay = 0; return true;
}
/* Clock: EFOS follows the clock Move passes on only when Move follows an external MIDI clock (MIDI sync).
   Move's own clock (its set, its tempo) is ignored, so EFOS's own TEMPO leads. Checked every second. */
let _ck = -1;
function _clockFollow() {
  const i = _moveInfo(); const on = !i || i.midiClockSync == null ? 1 : (i.midiClockSync === 1 || i.midiClockSync === true ? 1 : 0);
  if (on !== _ck) { _ck = on; _outQ.push('ck ' + on); }
}
globalThis.init = function () {
  try { host_set_refresh_rate(30); } catch (e) {}
  _ledHave.clear(); _sent.clear(); _syncDirty = true;
  ui.playing = false; _outQ.push('play 0');   /* a (re)loaded EFOS starts stopped */
  _ck = -1; _clockFollow(); _stopMove();
  _outQ.push('co ' + (set.clkOut ? 1 : 0));   /* MIDI clock out, as set in MENU > MIDI */
  try { saverStart('INTRO', true); } catch (e) {}   /* the start-up animation, once; any press or turn skips it */
};
globalThis.onResume = function () { _ledHave.clear(); _fbDirty = true; render(); };
globalThis.onUnload = function () { try { saveState(); sessionStorage.flush(); } catch (e) {} try { moveSend({ play: 0 }); _send(); } catch (e) {} };
/* live-safe: an error in one part is logged and the loop goes on (an error thrown out of tick() ends the module) */
const _safe = (name, f) => { try { f(); } catch (e) { console.log('EFOS ' + name + ': ' + e + '\n' + (e && e.stack)); } };
let _volDraw = false;
globalThis.tick = function () {
  _n++;
  _safe('timers', _runTimers);
  _safe('send', _send);
  if (_volDraw) { _volDraw = false; _safe('vol', render); }
  _safe('poll', _poll);   /* every tick: a track hit reaches its pad light without waiting (Lef 24 nov) */
  if (_n % 30 === 15) _safe('controller', _ctlHand);
  if (_n % 30 === 0) { _safe('clock', _clockFollow); _safe('stopmove', _stopMove); }   /* Move's own set never plays under EFOS */
  if (_n % 4 === 0 || ui.ledNow) { ui.ledNow = 0; _safe('leds', _leds); }   /* a hit or its end: the lights at once */
  _safe('ledflush', () => _ledFlush(16));
  if (_n % 4 === 2) _safe('screen', _flushScreen);
  const now = Date.now(); if (now - _lastSave > 10000) { _lastSave = now; _safe('save', () => sessionStorage.flush()); }
};

/* the Move leaves out what needs a browser's file picker or a mouse: MENU LOAD / SAVE / MOUSE-OVER, PRESETS EXPORT / IMPORT (Lef 20 nov) */
MENU_ITEMS = MENU_ALL.filter(n => n !== 'LOAD' && n !== 'SAVE' && n !== 'MOUSE-OVER');
PRE_HIDE = new Set([EXP_A, IMP_A]);

/* timing for MENU > VERSION (Lef 20 nov: the screen follows a preset change half a bar late): ticks per second, how long a
   preset load and a screen draw take, and how long from the load to the screen on the Move. A preset change also flushes
   the screen in the same tick instead of waiting for the next screen tick. */
const _dg = { tps: 0, apply: 0, draw: 0, lag: 0, n: 0, t0: Date.now(), at: 0 };
{ const tick0 = globalThis.tick; globalThis.tick = function () { _dg.n++; const now = Date.now(); if (now - _dg.t0 >= 1000) { _dg.tps = Math.round(_dg.n * 1000 / (now - _dg.t0)); _dg.n = 0; _dg.t0 = now; } tick0(); }; }
{ const pa0 = preApply; preApply = function (m, str, q) { const t = Date.now(); try { return pa0(m, str, q); } finally { _dg.apply = Date.now() - t; _dg.at = Date.now(); } }; }
{ const d0 = draw; draw = function () { const t = Date.now(); try { return d0(); } finally { _dg.draw = Date.now() - t; } }; }
{ const la0 = loopApply; loopApply = function () { const t = Date.now(); la0(); _safe('screen now', () => { _fbDirty = true; _flushScreen(); _dg.lag = Date.now() - t; }); }; }

/* ---------- SAMPLE: WAV files (Lef 18 nov) ----------
 * All file work happens here, in the UI process; the DSP (audio thread) only swaps a finished buffer in.
 *  - LOAD (ALGO FILE): a WAV from the Move's own sample folder, picked with the jog (efosFiles.list / load).
 *  - Every new sound in a track's buffer (a recording ends, an OVERDUB stops, a file loads) is written as a WAV to
 *    EFOS_DIR/recordings/<id>.wav and the track remembers <id> (t.smf, t.smn = the name shown). The autosave and every
 *    preset keep that id, so a preset loads its sample again, wherever the preset goes (CLEAN UP, UNDO, SOUNDS ONLY).
 *  - When a track's id differs from what its buffer holds (a preset or the autosave loaded), the WAV is read and sent.
 *  - At start, recordings no state and no preset uses any more are removed.
 * The samples travel to and from the DSP as base64 of 16-bit little-endian (see move/dsp/efos_plugin.c). */
const SM_LIB = '/data/UserData/UserLibrary/Samples', SM_RECS = EFOS_DIR + '/recordings';
const SM_CHUNK = 8192, SM_MAXLEN = 44100 * 16;
const _sm = { have: Array(8).fill(null), ver: Array(8).fill(-1), seen: Array(8).fill(0), job: null, missing: new Set(), gc: false, info: null };
const _B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', _B64R = new Int16Array(128).fill(-1);
for (let i = 0; i < 64; i++) _B64R[_B64.charCodeAt(i)] = i;
function _b64enc(u8, a, b) {
  let s = '', part = [];
  for (let i = a; i < b; i += 3) {
    const n = b - i, v = u8[i] << 16 | (n > 1 ? u8[i + 1] << 8 : 0) | (n > 2 ? u8[i + 2] : 0);
    part.push(_B64[v >> 18 & 63] + _B64[v >> 12 & 63] + (n > 1 ? _B64[v >> 6 & 63] : '=') + (n > 2 ? _B64[v & 63] : '='));
    if (part.length >= 4096) { s += part.join(''); part = []; }
  }
  return s + part.join('');
}
function _b64dec(str, out, o) {    /* into the Uint8Array out from o; returns the bytes written */
  let acc = 0, bits = 0, k = o;
  for (let i = 0; i < str.length; i++) { const v = _B64R[str.charCodeAt(i) & 127]; if (v < 0) continue; acc = (acc << 6 | v) & 0xffffff; bits += 6; if (bits >= 8) { bits -= 8; out[k++] = acc >> bits & 255; } }
  return k - o;
}
const _smLog = m => { try { console.log('EFOS sample: ' + m); } catch (e) {} };
const _smName = p => String(p).split('/').pop().replace(/\.wav$/i, '').toUpperCase().slice(0, 20);

/* ---------- files ---------- */
function _readFile(path) {
  const f = _std.open(path, 'rb'); if (!f) return null;
  try { f.seek(0, _std.SEEK_END); const n = f.tell(); f.seek(0, _std.SEEK_SET);
    if (!(n > 44) || n > 64 * 1024 * 1024) return null;
    const buf = new ArrayBuffer(n); const got = f.read(buf, 0, n); return got > 44 ? new DataView(buf, 0, got) : null; }
  finally { f.close(); }
}
/* any PCM WAV (8 / 16 / 24 / 32 bit, float 32, mono or more channels) -> mono 16 bit; a rate of 44.1 / 22.05 / 11.025 kHz
   stays as it is (RATE divider 1 / 2 / 4, as EFOS records), any other rate is resampled to 44.1 kHz; at most 16 s of buffer */
function _decodeWav(d) {
  const tag = o => String.fromCharCode(d.getUint8(o), d.getUint8(o + 1), d.getUint8(o + 2), d.getUint8(o + 3));
  if (tag(0) !== 'RIFF' || tag(8) !== 'WAVE') return null;
  let o = 12, fmt = null, data = null;
  while (o + 8 <= d.byteLength) {
    const id = tag(o), n = d.getUint32(o + 4, true), b = o + 8;
    if (id === 'fmt ') { let f = d.getUint16(b, true); if (f === 0xfffe && n >= 26) f = d.getUint16(b + 24, true);
      fmt = { f, ch: d.getUint16(b + 2, true), sr: d.getUint32(b + 4, true), align: d.getUint16(b + 12, true), bits: d.getUint16(b + 14, true) }; }
    else if (id === 'data') { data = { b, n: Math.min(n, d.byteLength - b) }; break; }
    o = b + n + (n & 1);
  }
  if (!fmt || !data || !fmt.ch || !fmt.sr || !fmt.align) return null;
  const by = fmt.bits >> 3, ch = fmt.ch, al = fmt.align, frames = Math.floor(data.n / al);
  if (!(fmt.f === 1 && by >= 1 && by <= 4) && !(fmt.f === 3 && by === 4)) return null;
  const rd = fmt.f === 3 ? (p => d.getFloat32(p, true))
    : by === 2 ? (p => d.getInt16(p, true) / 32768) : by === 1 ? (p => (d.getUint8(p) - 128) / 128)
    : by === 3 ? (p => ((d.getUint8(p + 2) << 24 | d.getUint8(p + 1) << 16 | d.getUint8(p) << 8) >> 8) / 8388608)
    : (p => d.getInt32(p, true) / 2147483648);
  const mono = k => { let s = 0; const p = data.b + k * al; for (let c = 0; c < ch; c++) s += rd(p + c * by); return s / ch; };
  const div = fmt.sr === 44100 ? 1 : fmt.sr === 22050 ? 2 : fmt.sr === 11025 ? 4 : 0;
  const step = div ? 1 : fmt.sr / 44100, len = Math.min(SM_MAXLEN, Math.floor(frames / step));
  const out = new Int16Array(len);
  for (let i = 0; i < len; i++) {
    let x; if (div) x = mono(i); else { const q = i * step, k = Math.floor(q), f = q - k; x = mono(k) + (k + 1 < frames ? (mono(k + 1) - mono(k)) * f : 0); }
    x = x > 1 ? 1 : x < -1 ? -1 : x; out[i] = Math.round(x * 32767);
  }
  return { pcm: out, div: div || 1 };
}
function _writeWav(path, pcm, div) {
  const n = pcm.length * 2, b = new ArrayBuffer(44 + n), d = new DataView(b), sr = Math.round(44100 / div);
  const put = (o, s) => { for (let i = 0; i < 4; i++) d.setUint8(o + i, s.charCodeAt(i)); };
  put(0, 'RIFF'); d.setUint32(4, 36 + n, true); put(8, 'WAVE'); put(12, 'fmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true);
  d.setUint32(24, sr, true); d.setUint32(28, sr * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); put(36, 'data'); d.setUint32(40, n, true);
  new Int16Array(b, 44).set(pcm);   /* the Move is little-endian, like WAV */
  try { host_ensure_dir(SM_RECS); } catch (e) {} try { _os.mkdir(SM_RECS); } catch (e) {}
  const tmp = path + '.part', f = _std.open(tmp, 'wb'); if (!f) return false;
  let ok = false; try { ok = f.write(b, 0, b.byteLength) === b.byteLength; } finally { f.close(); }
  if (ok) ok = _os.rename(tmp, path) === 0; else try { _os.remove(tmp); } catch (e) {}
  return ok;
}
const _isDir = p => { try { const [st, err] = _os.stat(p); return !err && (st.mode & _os.S_IFMT) === _os.S_IFDIR; } catch (e) { return false; } };

/* ---------- jobs: one at a time, a little per tick ---------- */
const _smSet = (k, v) => { try { return typeof host_module_set_param_blocking === 'function' ? host_module_set_param_blocking(k, v, 200) !== false : (host_module_set_param(k, v), true); } catch (e) { return false; } };
function _smSendStart(t, pcm, div, after) { _sm.job = { kind: 'send', t, pcm, div, off: 0, after, begun: _smSet('smb', `${t} ${pcm.length} ${div}`) }; }
function _smJob() {
  const J = _sm.job; if (!J) return;
  if (J.kind === 'send') {
    if (!J.begun) { J.begun = _smSet('smb', `${J.t} ${J.pcm.length} ${J.div}`); return; }
    const u8 = new Uint8Array(J.pcm.buffer, J.pcm.byteOffset, J.pcm.byteLength);
    for (let k = 0; k < 4 && J.off < J.pcm.length; k++) {
      const n = Math.min(SM_CHUNK, J.pcm.length - J.off);
      if (!_smSet('smd', J.off + ' ' + _b64enc(u8, J.off * 2, (J.off + n) * 2))) return;   /* busy: again next tick */
      J.off += n;
    }
    if (J.off < J.pcm.length) return;
    if (!_smSet('smc', '1')) return;
    _sm.job = { kind: 'wait', t: J.t, after: J.after, n: 0 };   /* the next 'smi' shows the new version */
    return;
  }
  if (J.kind === 'save') {
    const t = J.t;
    for (let k = 0; k < 4 && J.off < J.len; k++) {
      let s = null; try { s = host_module_get_param('smx' + t + ':' + J.off); } catch (e) {}
      if (!s) return;
      const got = _b64dec(String(s), J.u8, J.off * 2) >> 1; if (!got) { _sm.job = null; return; }
      J.off += got;
    }
    if (J.off < J.len) return;
    _sm.job = null;
    let v = null; try { v = String(host_module_get_param('smi')).trim().split(/\s+/).map(Number); } catch (e) {}
    if (!v || v[t * 4 + 2] !== J.ver || v[t * 4 + 3]) return;   /* the buffer changed while it was read: the new one is saved instead */
    if (!_writeWav(SM_RECS + '/' + J.id + '.wav', J.pcm, J.div)) { toast('SAMPLE NOT SAVED: DISK?', 2500); _smLog('write failed ' + J.id); }
  }
}
/* a new id for new content in track t's buffer; its old file goes when nothing refers to it any more */
function _smNewId(t) { const d = new Date(), p = n => String(n).padStart(2, '0');
  return `T${t + 1}-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}-${Math.floor(Math.random() * 1296).toString(36)}`; }
function _smRefs() {
  const a = [JSON.stringify(tracks)];
  try { Object.values(presets.cache || {}).forEach(s => a.push(String(s))); } catch (e) {}
  try { (ui.undos || []).forEach(s => a.push(s)); (ui.redos || []).forEach(s => a.push(s)); } catch (e) {}
  try { if (ui.preDel && ui.preDel.state) a.push(ui.preDel.state); if (ui.pending) a.push(ui.pending.str); if (ui.loop) a.push(...ui.loop.str); } catch (e) {}
  return a.join('\n');
}
function _smDrop(id) { if (!id || _smRefs().indexOf('"' + id + '"') >= 0) return; try { _os.remove(SM_RECS + '/' + id + '.wav'); } catch (e) {} }
/* at start: recordings nothing refers to are removed (presets and the autosave are read by then) */
function _smGc() {
  if (Object.keys(presets.cache || {}).length < presets.names.filter(Boolean).length) { _smLog('presets not all read: no clean-up'); return; }   /* never remove what a preset might use */
  let names = []; try { const [l, err] = _os.readdir(SM_RECS); if (!err) names = l; } catch (e) {}
  const refs = _smRefs(); let n = 0;
  for (const f of names) { const m = /^(.+)\.wav(\.part)?$/.exec(f); if (!m) continue; if (!m[2] && refs.indexOf('"' + m[1] + '"') >= 0) continue; try { _os.remove(SM_RECS + '/' + f); n++; } catch (e) {} }
  if (n) _smLog('removed ' + n + ' unused recordings');
}
function _smPoll() {
  if (!_sm.gc) { _sm.gc = true; _safe('sample gc', _smGc); }
  let s = null; try { s = host_module_get_param('smi'); } catch (e) {}
  if (!s) return;
  const a = String(s).trim().split(/\s+/).map(Number); if (a.length < 32) return;
  const now = Date.now(), J = _sm.job;
  for (let t = 0; t < 8; t++) {
    const len = a[t * 4], div = a[t * 4 + 1], ver = a[t * 4 + 2], rec = a[t * 4 + 3];
    if (_sm.ver[t] < 0) { _sm.ver[t] = ver; continue; }
    if (ver === _sm.ver[t]) continue;
    if (J && J.kind === 'wait' && J.t === t) {             /* a load arrived */
      _sm.ver[t] = ver; _sm.job = null;
      if (J.after.id) { _sm.have[t] = J.after.id; continue; }   /* from recordings: nothing new to save */
      if (J.after.clear) { _sm.have[t] = null; continue; }      /* INIT emptied it */
    }
    else if (rec || (J && J.t === t)) continue;            /* still recording, or busy with this track */
    else if (!_sm.seen[t]) { _sm.seen[t] = now; continue; }
    else if (now - _sm.seen[t] < 800) continue;            /* REC from an LFO: wait until it settles */
    _sm.seen[t] = 0; _sm.ver[t] = ver;
    const tr = tracks[t], old = tr.smf, id = _smNewId(t);    /* new content: a new recording id, saved as a WAV */
    tr.smf = id; tr.smn = J && J.kind === 'wait' && J.t === t && J.after.name ? J.after.name : null; _sm.have[t] = id;
    _smDrop(old);
    if (len > 0 && (!_sm.job || _sm.job.kind !== 'send')) { const pcm = new Int16Array(len); _sm.job = { kind: 'save', t, id, ver, len, div, off: 0, pcm, u8: new Uint8Array(pcm.buffer) }; }
    render(); return;
  }
  if (_sm.job) return;
  if (ui.smClear && ui.smClear.size) { const t = ui.smClear.values().next().value; ui.smClear.delete(t); if (_sm.have[t] || a[t * 4] > 0) { _smSendStart(t, new Int16Array(0), 1, { clear: true }); return; } }   /* INIT: an empty buffer */
  for (let t = 0; t < 8; t++) {                            /* a preset, UNDO or the autosave asks for another sample: load it */
    const id = tracks[t] && tracks[t].smf;
    if (!id || id === _sm.have[t] || _sm.missing.has(id) || a[t * 4 + 3]) continue;
    const d = _readFile(SM_RECS + '/' + id + '.wav'), w = d && _decodeWav(d);
    if (!w) { _sm.missing.add(id); toast('T' + (t + 1) + ' SAMPLE NOT FOUND', 2500); _smLog('missing ' + id); continue; }
    _smSendStart(t, w.pcm, w.div, { id }); return;
  }
}
globalThis.efosFiles = {
  list(rel) {
    const dir = SM_LIB + (rel ? '/' + rel : '');
    let names = []; try { const [l, err] = _os.readdir(dir); if (!err) names = l; } catch (e) {}
    const dirs = [], wavs = [];
    for (const n of names) { if (!n || n[0] === '.') continue; if (/\.wav$/i.test(n)) wavs.push({ n }); else if (_isDir(dir + '/' + n)) dirs.push({ n, dir: true }); }
    const by = (x, y) => x.n.toLowerCase() < y.n.toLowerCase() ? -1 : x.n.toLowerCase() > y.n.toLowerCase() ? 1 : 0;
    return dirs.sort(by).concat(wavs.sort(by)).slice(0, 2000);
  },
  load(t, rel) {
    if (_sm.job) { toast('BUSY, TRY AGAIN', 1500); return; }
    const d = _readFile(SM_LIB + '/' + rel), w = d && _decodeWav(d);
    if (!w || !w.pcm.length) { toast('NOT A WAV EFOS CAN READ', 2500); return; }
    _smSendStart(t, w.pcm, w.div, { name: _smName(rel) });
    toast('LOADED: ' + _smName(rel) + ((w.pcm.length >= SM_MAXLEN) ? ' (FIRST 16 S)' : ''), 2500);
  },
};
/* MENU > BUFFER (Lef 22 nov): keep a recording as a WAV in Samples/Recordings, where LOAD.A / LOAD.B and FILE find it */
const SM_KEEP = SM_LIB + '/Recordings';
const _keepPath = n => SM_KEEP + '/' + n + '.wav';
const _keepFree = n => { let m = n, k = 2; while (_readable(_keepPath(m))) m = n + ' ' + k++; return m; };
const _readable = p => { try { const [st, err] = _os.stat(p); return !err; } catch (e) { return false; } };
function _keepWrite(name, bytes) {
  try { host_ensure_dir(SM_KEEP); } catch (e) {} try { _os.mkdir(SM_KEEP); } catch (e) {}
  const p = _keepPath(name), tmp = p + '.part', f = _std.open(tmp, 'wb'); if (!f) return false;
  let ok = false; try { ok = f.write(bytes, 0, bytes.byteLength) === bytes.byteLength; } finally { f.close(); }
  if (ok) ok = _os.rename(tmp, p) === 0; else try { _os.remove(tmp); } catch (e) {}
  if (ok && globalThis.efosWt) globalThis.efosWt.nameOf('Recordings/' + name + '.wav');   /* in the wavetable list at once */
  return ok;
}
function _keepWav(pcm, div) {
  const n = pcm.length * 2, b = new ArrayBuffer(44 + n), d = new DataView(b), sr = Math.round(44100 / div);
  const put = (o, s) => { for (let i = 0; i < 4; i++) d.setUint8(o + i, s.charCodeAt(i)); };
  put(0, 'RIFF'); d.setUint32(4, 36 + n, true); put(8, 'WAVE'); put(12, 'fmt '); d.setUint32(16, 16, true); d.setUint16(20, 1, true); d.setUint16(22, 1, true);
  d.setUint32(24, sr, true); d.setUint32(28, sr * 2, true); d.setUint16(32, 2, true); d.setUint16(34, 16, true); put(36, 'data'); d.setUint32(40, n, true);
  new Int16Array(b, 44).set(pcm); return b;
}
function _keepJob() {   /* the Sample-button take, read from the core a little per tick */
  const J = _sm.keep; if (!J) return;
  for (let k = 0; k < 4 && J.off < J.len; k++) {
    let s = null; try { s = host_module_get_param('smx8:' + J.off); } catch (e) {}
    if (!s) return;
    const got = _b64dec(String(s), J.u8, J.off * 2) >> 1; if (!got) { _sm.keep = null; toast('NOT SAVED: TAKE CHANGED', 2500); return; }
    J.off += got;
  }
  if (J.off < J.len) return;
  _sm.keep = null;
  if (_keepWrite(J.name, _keepWav(J.pcm, 1))) bigMsg('SAVED', [J.name, '', 'IN SAMPLES/RECORDINGS'], 1800); else toast('NOT SAVED: DISK?', 2500);
  render();
}
globalThis.efosRecs = {
  list() {
    let names = []; try { const [l, err] = _os.readdir(SM_KEEP); if (!err) names = l; } catch (e) {}
    return names.filter(n => /\.wav$/i.test(n) && n[0] !== '.').map(n => n.replace(/\.wav$/i, '')).sort((x, y) => x.toLowerCase() < y.toLowerCase() ? -1 : 1);
  },
  save(src, name) {   /* src 'gen' = the Sample-button take, or a track number */
    if (_sm.keep) { toast('BUSY, TRY AGAIN', 1500); return false; }
    name = _keepFree(name);
    if (src === 'gen') {
      let len = 0; try { len = +String(host_module_get_param('smg')).trim() || 0; } catch (e) {}
      if (len < 64) { toast('NO SAMPLE BUTTON TAKE', 2000); return false; }
      const pcm = new Int16Array(len); _sm.keep = { name, len, off: 0, pcm, u8: new Uint8Array(pcm.buffer) }; toast('SAVING ' + name, 3000); return true;
    }
    const id = tracks[src] && tracks[src].smf, d = id && _readFile(SM_RECS + '/' + id + '.wav');
    if (!d) { toast('T' + (src + 1) + ': STILL SAVING, TRY AGAIN', 2000); return false; }
    if (_keepWrite(name, d.buffer.slice(d.byteOffset, d.byteOffset + d.byteLength))) { bigMsg('SAVED', [name, '', 'IN SAMPLES/RECORDINGS'], 1800); return true; }
    toast('NOT SAVED: DISK?', 2500); return false;
  },
  rename(a, b) {
    if (a === b) return true; b = _keepFree(b);
    const ok = _os.rename(_keepPath(a), _keepPath(b)) === 0;
    if (ok && globalThis.efosWt) globalThis.efosWt.moved('Recordings/' + a + '.wav', 'Recordings/' + b + '.wav');
    return ok ? b : null;
  },
  del(n) { let ok = false; try { ok = _os.remove(_keepPath(n)) === 0; } catch (e) {} if (ok && globalThis.efosWt) globalThis.efosWt.gone('Recordings/' + n + '.wav'); return ok; },
};
let _smN = 0;
const _tickSm = globalThis.tick;
globalThis.tick = function () { _tickSm(); if (++_smN % 3 === 1) _safe('sample', _smPoll); _safe('sample job', _smJob); _safe('keep', _keepJob); };

/* ---------- WAVETABLE / WT DRUM: WAV files as tables (Lef 20 nov) ----------
 * File work only here, in the UI process (Schwung rule); the DSP gets finished frames (move/dsp/efos_plugin.c wtb / wtd / wte / wtx).
 *  - At start the whole list is read: first the Wavetables folder, then every other WAV of the Samples folder (subfolders too).
 *  - A table is loaded only when a track picks it (RAM): into a free core slot (4..18) and a free part of the core's 1024-frame pool;
 *    when there is no room, the table that was used longest ago and that no track uses goes.
 *  - Frames are 2048 samples (Serum); a 'clm ' chunk (<!>N) gives another frame size, each frame is then resampled to 2048.
 *    Shorter than 2048 (or up to 4096 and not a multiple of 2048) = a single cycle, resampled to one frame of 2048. At most 256 frames.
 *  - Until a table is in the core, the track plays SIN>SAW. */
const WT_DIR = SM_LIB + '/Wavetables', WT_FN = 2048, WT_POOL = 1024, WT_MAXFR = 256, WT_WAIT = 300;
/* have: name -> {slot, off, frames, used}; req: name -> time it was asked for. A table loads only when a track still uses it
   WT_WAIT ms after it was asked for, so turning TBL past names loads nothing on the way (Lef 20 nov) */
const _wt = { path: new Map(), have: new Map(), req: new Map(), job: null, listed: false, bad: new Set() };
function _wtList() {
  const out = [], seen = new Set();
  const add = (name, path) => { let n = name, k = 2; while (seen.has(n) || WT_BUILT.includes(n) || n === WT_BUF) n = name.slice(0, 17) + '~' + k++; seen.add(n); out.push(n); _wt.path.set(n, path); };
  const walk = (dir, depth, skip) => {
    if (out.length >= 2000) return;
    let names = []; try { const [l, err] = _os.readdir(dir); if (!err) names = l; } catch (e) {}
    names = names.filter(n => n && n[0] !== '.').sort((x, y) => x.toLowerCase() < y.toLowerCase() ? -1 : 1);
    for (const n of names) if (/\.wav$/i.test(n) && out.length < 2000) add(_smName(n), dir + '/' + n);
    if (depth < 4) for (const n of names) if (!/\.wav$/i.test(n) && dir + '/' + n !== skip && _isDir(dir + '/' + n)) walk(dir + '/' + n, depth + 1, skip);
  };
  walk(WT_DIR, 0, null);                 /* the Wavetables folder first */
  walk(SM_LIB, 0, WT_DIR);               /* then any WAV of the Samples folder (Lef 20 nov) */
  return out;
}
/* the frame size from Serum's 'clm ' chunk ("<!>2048 ..."), or 0 */
function _wtClm(d) {
  const tag = o => String.fromCharCode(d.getUint8(o), d.getUint8(o + 1), d.getUint8(o + 2), d.getUint8(o + 3));
  let o = 12;
  while (o + 8 <= d.byteLength) {
    const id = tag(o), n = d.getUint32(o + 4, true), b = o + 8;
    if (id === 'clm ') { let s = ''; for (let i = 0; i < Math.min(n, 32) && b + i < d.byteLength; i++) s += String.fromCharCode(d.getUint8(b + i)); const m = /<!>\s*(\d+)/.exec(s); return m ? +m[1] : 0; }
    if (id === 'data') return 0;
    o = b + n + (n & 1);
  }
  return 0;
}
/* a WAV -> Int16Array of frames x 2048, or null */
function _wtFrames(path) {
  const d = _readFile(path), w = d && _decodeWav(d); if (!w || w.pcm.length < 16) return null;
  const x = w.pcm, L = x.length, clm = _wtClm(d);
  let fs = clm >= 16 && clm <= 65536 ? clm : WT_FN, nf;
  if (!clm && (L < WT_FN || (L <= 2 * WT_FN && L % WT_FN))) { fs = L; nf = 1; }   /* a single cycle */
  else nf = Math.min(WT_MAXFR, Math.floor(L / fs));
  if (nf < 1) { fs = L; nf = 1; }
  const out = new Int16Array(nf * WT_FN);
  for (let f = 0; f < nf; f++) {
    const b = f * fs;
    if (fs === WT_FN) { out.set(x.subarray(b, b + WT_FN), f * WT_FN); continue; }
    for (let i = 0; i < WT_FN; i++) { const q = i * fs / WT_FN, k = Math.floor(q), u = q - k, a = x[b + k], c = x[b + (k + 1) % fs]; out[f * WT_FN + i] = Math.round(a + (c - a) * u); }
  }
  return { pcm: out, frames: nf };
}
const _wtInUse = () => { const s = new Set(); try { tracks.forEach(t => { if (wtE(t)) wtn(t).forEach(n => s.add(n)); }); } catch (e) {} return s; };
/* a free slot and a free part of the pool for n frames; evicts tables no track uses, the oldest first */
function _wtPlace(n) {
  const use = _wtInUse();
  for (;;) {
    const taken = [..._wt.have.values()], slots = new Set(taken.map(h => h.slot));
    let slot = -1; for (let s = 4; s < WT_SLOTS - 1; s++) if (!slots.has(s)) { slot = s; break; }
    let off = -1;
    if (slot >= 0) { const r = taken.map(h => [h.off, h.off + h.frames]).sort((a, b) => a[0] - b[0]); let p = 0;
      for (const [a, b] of r) { if (a - p >= n) break; p = Math.max(p, b); } if (WT_POOL - p >= n) off = p; }
    if (slot >= 0 && off >= 0) return { slot, off };
    let old = null; for (const [k, h] of _wt.have) if (!use.has(k) && (!old || h.used < _wt.have.get(old).used)) old = k;
    if (!old) return null;
    _smSet('wtx', String(_wt.have.get(old).slot)); _wt.have.delete(old);
  }
}
function _wtListOnce() { if (!_wt.listed) { _wt.listed = true; _safe('wt list', () => { wtFiles = _wtList(); _smLog(wtFiles.length + ' wavetable files'); }); } }
function _wtJob() {
  _wtListOnce();
  let J = _wt.job;
  if (J && !_wtInUse().has(J.name)) { _wt.job = J = null; }   /* no track wants it any more: stop, its slot stays free */
  if (!J) {
    const use = _wtInUse(), now = Date.now(); let name = null;
    for (const [n, at] of _wt.req) {
      if (!use.has(n) || _wt.have.has(n) || _wt.bad.has(n)) { _wt.req.delete(n); continue; }
      if (now - at >= WT_WAIT) { name = n; break; }
    }
    if (!name) return;
    _wt.req.delete(name);
    const path = _wt.path.get(name), w = path && _wtFrames(path);
    if (!w) { _wt.bad.add(name); toast('NOT A WAV EFOS CAN READ', 2000); return; }
    const at = _wtPlace(w.frames);
    if (!at) { _wt.bad.add(name); toast('WAVETABLE MEMORY FULL', 2500); return; }
    _wt.job = { name, pcm: w.pcm, frames: w.frames, slot: at.slot, off: at.off, pos: 0, begun: _smSet('wtb', `${at.slot} ${w.frames} ${at.off}`) };
    return;
  }
  if (!J.begun) { J.begun = _smSet('wtb', `${J.slot} ${J.frames} ${J.off}`); return; }
  const u8 = new Uint8Array(J.pcm.buffer, J.pcm.byteOffset, J.pcm.byteLength);
  for (let k = 0; k < 4 && J.pos < J.pcm.length; k++) {
    const n = Math.min(SM_CHUNK, J.pcm.length - J.pos);
    if (!_smSet('wtd', J.pos + ' ' + _b64enc(u8, J.pos * 2, (J.pos + n) * 2))) return;
    J.pos += n;
  }
  if (J.pos < J.pcm.length) return;
  if (!_smSet('wte', '1')) return;
  _wt.have.set(J.name, { slot: J.slot, off: J.off, frames: J.frames, used: Date.now() });
  _wt.job = null; sync();
}
const _wtSlotBase = wtSlotFor;
wtSlotFor = n => {
  if (WT_BUILT.includes(n) || n === WT_BUF) return _wtSlotBase(n);
  const h = _wt.have.get(n); if (h) { h.used = Date.now(); return h.slot; }
  if (_wt.path.has(n) && !_wt.bad.has(n) && !_wt.req.has(n) && !(_wt.job && _wt.job.name === n)) _wt.req.set(n, Date.now());
  return 0;
};
/* for LOAD.A / LOAD.B: the path of a table under the Samples folder, the list name of a file (added when it is past the first 2000),
   and "load this one now" */
globalThis.efosWt = {
  pathOf(n) { _wtListOnce(); const p = _wt.path.get(n); return p && p.startsWith(SM_LIB + '/') ? p.slice(SM_LIB.length + 1) : null; },
  nameOf(rel) {
    _wtListOnce(); const full = SM_LIB + '/' + rel;
    for (const [k, p] of _wt.path) if (p === full) return k;
    const base = _smName(rel.split('/').pop()); let n = base, k = 2;
    while (_wt.path.has(n) || WT_BUILT.includes(n) || n === WT_BUF) n = base.slice(0, 17) + '~' + k++;
    _wt.path.set(n, full); wtFiles.push(n); return n;
  },
  moved(a, b) {   /* a file in Recordings was renamed: the list shows the new name, a track on the old name keeps playing it */
    _wtListOnce(); const fa = SM_LIB + '/' + a, fb = SM_LIB + '/' + b;
    for (const [k, p] of _wt.path) if (p === fa) { _wt.path.set(k, fb); const i = wtFiles.indexOf(k); if (i >= 0) wtFiles.splice(i, 1); }
    const base = _smName(b.split('/').pop()); let n = base, k = 2;
    while (_wt.path.has(n) || WT_BUILT.includes(n) || n === WT_BUF) n = base.slice(0, 17) + '~' + k++;
    _wt.path.set(n, fb); wtFiles.push(n);
  },
  gone(rel) { _wtListOnce(); const f = SM_LIB + '/' + rel; for (const [k, p] of _wt.path) if (p === f) { const i = wtFiles.indexOf(k); if (i >= 0) wtFiles.splice(i, 1); } },
  now(n) { if (!_wt.have.has(n) && !(_wt.job && _wt.job.name === n)) { _wt.bad.delete(n); _wt.req.set(n, 0); } },
};
const _tickWt = globalThis.tick;
globalThis.tick = function () { _tickWt(); if (!_sm.job) _safe('wavetable', _wtJob); };

/* ---------- MIRROR SCREEN (Lef 19 nov): a QR code with the address of Schwung's mirror page ----------
   The address uses the Move's own IP (Android phones often can't find move.local); without one it falls back to move.local.
   The QR encoder (byte mode, ECC L, versions 1..6) follows Project Nayuki's QR Code generator library (MIT,
   Copyright (c) Project Nayuki, https://www.nayuki.io/page/qr-code-generator-library). */
function _mirIp() {
  /* /proc/net/fib_trie lists every local address as "|-- a.b.c.d" followed by "/32 host LOCAL" */
  let txt = null;
  try { const f = _std.open('/proc/net/fib_trie', 'r'); if (f) { txt = f.readAsString(); f.close(); } } catch (e) {}
  if (!txt) return null;
  const L = txt.split('\n'), out = [];
  for (let i = 1; i < L.length; i++) if (/\/32 host LOCAL/.test(L[i])) {
    const m = /\|--\s*(\d+\.\d+\.\d+\.\d+)/.exec(L[i - 1]);
    if (m && !/^127\./.test(m[1]) && !/^169\.254\./.test(m[1]) && out.indexOf(m[1]) < 0) out.push(m[1]);
  }
  /* the address on the network of the default route (the wifi), read from /proc/net/route: an iPhone hotspot is 172.20.10.x,
     while 172.16.254.x is the Move's own USB link to a computer, never the phone's network (Lef 19 nov) */
  const ip2n = a => a.split('.').reduce((n, x) => n * 256 + (+x), 0);
  let rt = null;
  try { const f = _std.open('/proc/net/route', 'r'); if (f) { rt = f.readAsString(); f.close(); } } catch (e) {}
  if (rt) {
    const rows = rt.split('\n').slice(1).map(l => l.trim().split(/\s+/)).filter(r => r.length >= 8);
    const hx = h => { const v = parseInt(h, 16) >>> 0; return ((v & 255) * 16777216) + (((v >>> 8) & 255) << 16) + (((v >>> 16) & 255) << 8) + (v >>> 24); };   /* little-endian hex */
    const def = rows.find(r => r[1] === '00000000' && r[7] === '00000000');
    if (def) for (const r of rows) if (r[0] === def[0] && r[7] !== '00000000') {
      const net = hx(r[1]), mask = hx(r[7]), hit = out.find(a => ((ip2n(a) & mask) >>> 0) === ((net & mask) >>> 0));
      if (hit) return hit;
    }
  }
  const lan = out.filter(a => !/^172\.16\.254\./.test(a));
  const priv = lan.find(a => /^192\.168\./.test(a)) || lan.find(a => /^172\.20\.10\./.test(a)) || lan.find(a => /^10\./.test(a)) || lan.find(a => /^172\.(1[6-9]|2\d|3[01])\./.test(a));
  return priv || lan[0] || null;
}

const _QR_ECC = [-1, 7, 10, 15, 20, 26, 18];        /* ECC L: error-correction codewords per block, versions 1..6 */
const _QR_BLK = [-1, 1, 1, 1, 1, 1, 2];             /* ECC L: number of blocks */
function _qrMul(x, y) { let z = 0; for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z & 0xFF; }
function _qrDivisor(deg) { const r = new Array(deg).fill(0); r[deg - 1] = 1; let root = 1;
  for (let i = 0; i < deg; i++) { for (let j = 0; j < deg; j++) { r[j] = _qrMul(r[j], root); if (j + 1 < deg) r[j] ^= r[j + 1]; } root = _qrMul(root, 0x02); }
  return r; }
function _qrRem(data, div) { const r = div.map(() => 0);
  for (const b of data) { const f = b ^ r.shift(); r.push(0); div.forEach((c, i) => { r[i] ^= _qrMul(c, f); }); }
  return r; }
function _qrRaw(v) { let r = (16 * v + 128) * v + 64; if (v >= 2) { const n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; } return r; }
/* returns {size, dark(x, y)} or null when the text is too long */
function _qrMake(text) {
  const bytes = []; for (let i = 0; i < text.length; i++) bytes.push(text.charCodeAt(i) & 0xFF);
  let ver = 1, cap = 0;
  for (; ver <= 6; ver++) { cap = Math.floor(_qrRaw(ver) / 8) - _QR_ECC[ver] * _QR_BLK[ver]; if (4 + 8 + bytes.length * 8 <= cap * 8) break; }
  if (ver > 6) return null;
  /* data bits: mode 0100, 8-bit count, the bytes, terminator, pad */
  const bits = [], put = (v, n) => { for (let i = n - 1; i >= 0; i--) bits.push((v >>> i) & 1); };
  put(4, 4); put(bytes.length, 8); bytes.forEach(b => put(b, 8));
  put(0, Math.min(4, cap * 8 - bits.length)); put(0, (8 - bits.length % 8) % 8);
  const data = []; for (let i = 0; i < bits.length; i += 8) { let b = 0; for (let j = 0; j < 8; j++) b = (b << 1) | bits[i + j]; data.push(b); }
  for (let p = 0xEC; data.length < cap; p ^= 0xEC ^ 0x11) data.push(p);
  /* error correction per block, then interleave */
  const nb = _QR_BLK[ver], ecl = _QR_ECC[ver], raw = Math.floor(_qrRaw(ver) / 8), nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
  const div = _qrDivisor(ecl), blocks = [];
  for (let i = 0, k = 0; i < nb; i++) { const d = data.slice(k, k + shortLen - ecl + (i < nShort ? 0 : 1)); k += d.length;
    const e = _qrRem(d, div); if (i < nShort) d.push(0); blocks.push(d.concat(e)); }
  const cw = [];
  for (let i = 0; i < blocks[0].length; i++) blocks.forEach((b, j) => { if (i !== shortLen - ecl || j >= nShort) cw.push(b[i]); });
  /* the grid */
  const size = ver * 4 + 17, mod = [], fn = [];
  for (let y = 0; y < size; y++) { mod.push(new Array(size).fill(false)); fn.push(new Array(size).fill(false)); }
  const setF = (x, y, d) => { mod[y][x] = d; fn[y][x] = true; };
  for (let i = 0; i < size; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
  [[3, 3], [size - 4, 3], [3, size - 4]].forEach(([cx, cy]) => {
    for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) { const x = cx + dx, y = cy + dy, dist = Math.max(Math.abs(dx), Math.abs(dy));
      if (x >= 0 && x < size && y >= 0 && y < size) setF(x, y, dist !== 2 && dist !== 4); } });
  if (ver >= 2) { const p = size - 7;   /* versions 2..6 have one alignment pattern */
    for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) setF(p + dx, p + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1); }
  const format = mask => { const d = (1 << 3) | mask; let r = d; for (let i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537);
    const b = ((d << 10) | r) ^ 0x5412, bit = i => ((b >>> i) & 1) !== 0;   /* ECC L = format bits 01 */
    for (let i = 0; i <= 5; i++) setF(8, i, bit(i));
    setF(8, 7, bit(6)); setF(8, 8, bit(7)); setF(7, 8, bit(8));
    for (let i = 9; i < 15; i++) setF(14 - i, 8, bit(i));
    for (let i = 0; i < 8; i++) setF(size - 1 - i, 8, bit(i));
    for (let i = 8; i < 15; i++) setF(8, size - 15 + i, bit(i));
    setF(8, size - 8, true); };
  format(0);   /* reserves the format areas before the data goes in */
  let i = 0;
  for (let right = size - 1; right >= 1; right -= 2) { if (right === 6) right = 5;
    for (let v = 0; v < size; v++) for (let j = 0; j < 2; j++) { const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - v : v;
      if (!fn[y][x] && i < cw.length * 8) { mod[y][x] = ((cw[i >>> 3] >>> (7 - (i & 7))) & 1) !== 0; i++; } } }
  const MASK = [(x, y) => (x + y) % 2 === 0, (x, y) => y % 2 === 0, (x, y) => x % 3 === 0, (x, y) => (x + y) % 3 === 0,
    (x, y) => (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0, (x, y) => x * y % 2 + x * y % 3 === 0,
    (x, y) => (x * y % 2 + x * y % 3) % 2 === 0, (x, y) => ((x + y) % 2 + x * y % 3) % 2 === 0];
  const apply = m => { for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!fn[y][x] && MASK[m](x, y)) mod[y][x] = !mod[y][x]; };
  /* the mask with the lowest penalty (runs, 2x2 blocks, dark balance) */
  const score = () => { let p = 0, dark = 0;
    for (let a = 0; a < size; a++) { let rx = 1, ry = 1;
      for (let b = 1; b < size; b++) {
        if (mod[a][b] === mod[a][b - 1]) { rx++; if (rx === 5) p += 3; else if (rx > 5) p++; } else rx = 1;
        if (mod[b][a] === mod[b - 1][a]) { ry++; if (ry === 5) p += 3; else if (ry > 5) p++; } else ry = 1; } }
    for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) { const c = mod[y][x]; if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3; }
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (mod[y][x]) dark++;
    return p + Math.floor(Math.abs(dark * 20 - size * size * 10) / (size * size)) * 10; };
  let best = 0, bestP = Infinity;
  for (let m = 0; m < 8; m++) { apply(m); format(m); const s = score(); if (s < bestP) { bestP = s; best = m; } apply(m); }
  apply(best); format(best);
  return { size, ver, dark: (x, y) => mod[y][x] };
}
/* turns Schwung's Mirror Display on when it is off (Lef 19 nov); display_mirror_get/set are Schwung's shadow-UI bindings
   (docs/API.md); without them nothing happens. Returns true when it was switched on now. */
function _mirOn() {
  try { if (typeof display_mirror_set === 'function') {
    const on = typeof display_mirror_get === 'function' ? !!display_mirror_get() : false;
    if (!on) { display_mirror_set(1); return true; } } } catch (e) {}
  return false;
}
globalThis.efosMirror = {
  on: _mirOn,
  /* our own page (move/web/efos-mirror.html, shipped in the module folder), served by Schwung's manager at module-assets (Lef 19 nov) */
  url() { const ip = _mirIp(); return 'http://' + (ip || 'move.local') + ':7700/api/remote-ui/module-assets/efos/efos-mirror.html'; },
  ip: _mirIp,
  qr: _qrMake
};
